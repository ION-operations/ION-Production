# dAimon And Multi-Database Strategy

## Principle

ION should not choose one database as universal truth.

Different carrier domains can use different data planes:

- Supabase/Postgres for realtime operational cockpit;
- MongoDB/Atlas for dAimon/Gemini document traces;
- Git for source history;
- local files for receipts and packets;
- vector stores for retrieval;
- object storage for artifacts.

## dAimon Relationship

dAimon was an early Google/Gemini carrier lane.

Keep dAimon's own trace store if it is already MongoDB/Atlas-oriented.

Bridge it into ION:

```text
dAimon trace
→ dAimon receipt
→ ION normalized event
→ Supabase mirror
→ cockpit dAimon lane
```

## Multi-DB Law

ION defines meaning and settlement.

Databases are adapters.

Each data-plane adapter must declare:

- what it stores;
- what it may write;
- what authority it has;
- what it mirrors;
- what it cannot claim;
- how its records tie back to ION receipts.
