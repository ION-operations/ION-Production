# Relationships To Other Systems

## Codex CLI / App

Codex is the local execution carrier.

Supabase should mirror:

- Codex session starts;
- Codex session resumes;
- packets assigned to Codex;
- tool/command summaries;
- tests run;
- commits created;
- branch capsule syncs;
- blockers.

Codex should not require Supabase to function. It writes local receipts first.

## ION MCP / Actions

ION MCP can expose read-only Supabase status later, but first ION MCP should remain the bounded live interface to local ION.

Potential tools:

- `ion_supabase_runtime_status`
- `ion_supabase_event_query`
- `ion_supabase_drift_summary`
- `ion_supabase_schema_status`

Write tools should come later and only mirror local receipts.

## Cockpit UI

Cockpit reads Supabase for:

- realtime event stream;
- agent/session list;
- service health;
- drift findings;
- git/commit timeline;
- settlement queue;
- dAimon lane events.

Cockpit also links back to ION source receipts/files.

## dAimon / Google / Gemini

dAimon may continue using MongoDB/Atlas or Google traces for its own lineage.

ION should create an adapter:

```text
dAimon receipt / trace
→ normalized ION event
→ Supabase mirror
→ cockpit lane
```

Do not collapse dAimon into Supabase. Supabase indexes it for visibility.

## GitHub / GitLab

GitHub/GitLab are source/review carriers.

Supabase mirrors:

- commit created;
- push completed;
- PR opened/updated;
- CI result;
- issue linked to packet.

Git remains source truth.

## Slack

Slack is the human/agent communication rail.

Supabase mirrors:

- Slack alert sent;
- approval requested;
- human decision received;
- branch return posted.

Slack message is witness, not settlement.

## Google Drive

Drive can mirror repo/context for GPT/PRO visibility.

Supabase mirrors:

- export created;
- mirror refresh attempted;
- Drive publish failed/passed;
- manifest hash.

Drive is not the runtime data plane.
