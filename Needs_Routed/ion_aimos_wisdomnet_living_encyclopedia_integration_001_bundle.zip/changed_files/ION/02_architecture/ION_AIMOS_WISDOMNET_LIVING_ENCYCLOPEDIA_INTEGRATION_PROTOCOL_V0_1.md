# ION AIMOS / WisdomNET / Living Encyclopedia Integration Protocol v0.1

Status: candidate integration protocol  
Packet: `PCKT-ION-AIMOS-WISDOMNET-LIVING-ENCYCLOPEDIA-INTEGRATION-001`  
Authority posture: candidate doctrine / implementation scaffold; not accepted state by itself

## 1. Purpose

This protocol reconciles four related ION lines without collapsing them into one another:

```text
ION = current inheritance, authority, receipt, template, and settlement law
AIMOS / AIM-ION = lineage witness for north-star, master-index, context architecture, SDK, and variable-density documentation organs
WisdomNET = structural evolution layer for reusable workflow/template/domain patterns
Living Encyclopedia = generated documentation surface compiled from lawful ION movement
```

This protocol does **not** promote AIMOS/AIM-ION into current ION law. It defines how AIMOS lineage can be audited, how WisdomNET can receive structural signals, and how the Living Encyclopedia can compile candidate documentation from lawful operations.

## 2. Core law

```text
AIMOS preserves navigational depth.
WisdomNET evolves workflow structure.
ION governs inheritance.
The Living Encyclopedia compiles from lawful movement.
```

AIMOS/AIM-ION materials enter as `LINEAGE_WITNESS` unless a settlement packet promotes a specific organ. WisdomNET receives structural metadata only; it is not a global memory dump. The Living Encyclopedia compiler emits candidate documentation surfaces, not accepted doctrine.

## 3. Source posture

Minimum source posture classes:

| Class | Meaning |
| --- | --- |
| `CURRENT_ION_LAW` | Current settled ION source, receipt, protocol, or test-backed implementation. |
| `CANDIDATE_ION_SURFACE` | Candidate packet, diff, branch return, or draft not settled. |
| `AIMOS_LINEAGE_WITNESS` | AIMOS/AIM-ION material preserving lineage or design organs. |
| `WISDOMNET_STRUCTURAL_SIGNAL` | Anonymized structural signal for template/domain/workflow evolution. |
| `ATLAS_REFERENCE` | Comparative systems reference, not ION law. |
| `DAIMON_LINEAGE` | Google/Gemini carrier lineage and product lane evidence. |
| `USER_REPORTED` | User statement requiring later proof if state-bearing. |
| `INFERENCE` | Model-derived conclusion requiring evidence before inheritance. |

## 4. Documentation delta contract

Every material ION operation should be able to emit a documentation delta. The first version requires these fields:

```yaml
schema_id: ion.documentation_delta.v0_1
packet_id:
branch_id:
operation_result:
context_delta:
template_delta:
doctrine_delta:
documentation_delta:
wisdomnet_signal:
atlas_signal:
source_posture:
non_claims:
```

Deltas are not accepted documentation. They are candidate inputs to the compiler.

## 5. WisdomNET firewall

WisdomNET exports structure, not user content.

Allowed structural signal examples:

```text
template_gap_detected
proof_failure_class
domain_fission_pressure
settlement_outcome_pattern
carrier_route_pattern
context_package_shape
recovery_tax_measure
```

Forbidden by default:

```text
private source code
secret-bearing context
customer documents
raw receipts with sensitive substance
private transcripts
unredacted user data
```

The compiler must reject any delta whose WisdomNET signal claims private content export.

## 6. Variable-density documentation

The Living Encyclopedia compiler should eventually render multiple densities from one lawful substrate:

| Density | Name | Use |
| --- | --- | --- |
| `D0` | one-line signal | cockpit badge / event feed |
| `D1` | operator note | immediate next-action context |
| `D2` | branch summary | agent handoff / branch review |
| `D3` | domain package | Codex/Sev implementation context |
| `D4` | explainer section | human-readable ION explainer |
| `D5` | north-star chapter | global canon / product doctrine |
| `D6` | trace bundle | replay/audit/provenance |

The MVP may compile D0-D3 summaries first and preserve D4-D6 patch fragments as candidate.

## 7. Compiler behavior

The compiler:

1. loads candidate documentation deltas,
2. validates required fields and source posture,
3. rejects private WisdomNET export,
4. groups deltas by branch/domain/packet,
5. renders candidate summaries,
6. emits a candidate settlement request,
7. leaves accepted-state decisions to settlement.

The compiler must not directly edit the main explainer or global canon without a settlement packet.

## 8. Relationship to existing ION organs

This protocol extends existing ION organs rather than replacing them:

```text
Living Encyclopedia maintenance -> receives compiler outputs
Template governance -> emits template_delta and template_gap signals
Context graph -> receives context_delta
Receipts and settlement -> decide inheritance
ATLAS -> receives atlas_signal / OS-pattern reference
WisdomNET -> receives structural_signal only
AIMOS lineage -> supplies north-star / variable-density witness
```

## 9. Non-claims

This protocol does not claim:

```text
AIMOS is current ION law
WisdomNET may ingest private project content
compiler output is accepted doctrine
main explainer edits are automatic
Supabase or cockpit mirrors are authoritative state
```

## 10. Next implementation packets

```text
PCKT-ION-LIVING-ENCYCLOPEDIA-COMPILER-001
PCKT-ION-VARIABLE-DENSITY-DOCUMENTATION-001
PCKT-ION-WISDOMNET-STRUCTURAL-SIGNAL-REGISTRY-001
PCKT-ION-AIMOS-LINEAGE-ANCHOR-LEDGER-001
PCKT-ION-WISDOMNET-SUPABASE-EVENT-MIRROR-001
```
