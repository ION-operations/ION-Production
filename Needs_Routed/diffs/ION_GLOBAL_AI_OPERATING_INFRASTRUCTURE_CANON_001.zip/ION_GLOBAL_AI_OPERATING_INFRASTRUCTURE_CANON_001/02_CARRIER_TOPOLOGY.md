# 02 — Carrier Topology

ION treats each external system as a carrier with source posture, authority, tools, and return contracts.

## Carrier classes

| Carrier | Role | Truth level |
| --- | --- | --- |
| Local Git repo | source code truth | canonical code source |
| ION files/receipts/settlement | state truth | canonical governance state |
| Codex CLI/App | local execution engine | bounded worker / local carrier |
| GPT-001 / ChatGPT Browser | orchestration + MCP/Actions carrier | live coordination / bounded tools |
| Sev / GPT PRO | senior review / architecture / settlement analysis | branch return / review carrier |
| Google Drive | project visibility mirror | readable context distribution |
| Supabase | realtime operational index / cockpit backend | queryable mirror, not truth |
| Slack | human/agent comms rail | conversation witness, not state truth |
| GitHub / GitLab | source reference/review plane | remote source reference |
| dAimon / Gemini / Google Agent Builder | Google carrier lane | external agent lineage/proof surface |
| Browser extension | approval/cockpit relay | user-facing local carrier |
| Local daemon / MCP / Action Gateway | bounded control plane | live operational surface |

## Universal carrier mount fields

```yaml
agent_tag:
carrier:
carrier_instance_id:
context_instance_id:
branch_id:
parent_context_id:
current_packet:
loaded_refs:
authority:
write_scope:
source_posture:
return_target:
settlement_required:
accepted_state_authority: false
```

## Carrier law

Every carrier must be able to answer:

```text
What did I mount?
What can I prove?
What am I allowed to do?
What did I touch?
Where does my return go?
```
