# Implementation Plan — ION Living Encyclopedia Compiler 001

## Phase 0 — Audit

Inspect existing repo surfaces for:
- living encyclopedia doctrine;
- context graph and graph node model;
- template registries;
- receipt and settlement surfaces;
- WisdomNET and ATLAS references;
- current state-surface sync mechanisms.

Goal: avoid inventing over existing ION.

## Phase 1 — Define documentation delta objects

Add template/schema files under:

```text
ION/07_templates/documentation_delta/
```

Minimum object families:

```text
documentation_delta
context_delta
doctrine_delta
template_delta
wisdomnet_signal
atlas_signal
cockpit_note
```

## Phase 2 — Registry

Add:

```text
ION/03_registry/ion_documentation_surfaces.yaml
ION/03_registry/ion_template_delta_registry.yaml
```

The documentation surfaces registry defines where compiled outputs go.  
The template delta registry defines which template families owe which deltas.

## Phase 3 — Compiler helper

Add:

```text
ION/04_packages/kernel/ion_living_encyclopedia_compiler.py
```

Minimum CLI commands:

```bash
python3 -m kernel.ion_living_encyclopedia_compiler --ion-root . --validate <delta.json>
python3 -m kernel.ion_living_encyclopedia_compiler --ion-root . --compile --json
```

The compiler must:
- read inbox delta files;
- validate;
- group by target surface;
- compile drafts;
- write a compile report;
- write a candidate settlement request;
- never update accepted surfaces directly.

## Phase 4 — Candidate folders

Add:

```text
ION/05_context/current/living_encyclopedia/inbox/
ION/05_context/current/living_encyclopedia/compiled/
ION/05_context/current/living_encyclopedia/reports/
ION/05_context/current/living_encyclopedia/settlement_requests/
```

## Phase 5 — Tests

Add targeted pytest coverage for:
- validation;
- compile behavior;
- accepted-state protection;
- WisdomNET/ATLAS preservation;
- hidden reasoning guard;
- report generation.

## Phase 6 — First sample delta

Create a small candidate sample delta that expresses the recent doctrine insight:

```text
Templates generate future context.
Receipts generate future doctrine.
Living encyclopedia compiles from lawful operations.
```

But do not land it into accepted doctrine.

## Phase 7 — Commit

Recommended commit message:

```text
PCKT: add living encyclopedia compiler foundation
```

Do not push until reviewed.
