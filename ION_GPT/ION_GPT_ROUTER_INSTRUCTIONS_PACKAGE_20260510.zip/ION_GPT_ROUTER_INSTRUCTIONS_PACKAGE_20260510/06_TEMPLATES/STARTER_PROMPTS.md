# Starter Prompts

Use these to test the GPT after uploading the router package and sources.

## Basic doctrine

```text
What is ION? Use the branch router and say which doctrine file you relied on.
```

## Mount check

```text
Use the router package. What branches are available and when should each be used?
```

## Custom GPT behavior

```text
Use the Custom GPT sandbox carrier branch. Explain how the old 8K instruction file should be used now.
```

## Continuity

```text
No working continuity bundle is uploaded. What continuity claims are you allowed to make?
```

## Connector containment

```text
Do not call live connectors. Explain the Action Gateway/MCP lane from files only.
```

## UI canon

```text
Use the UI/JOC canon branch and summarize the hard constraints for a JOC panel design.
```
