"""ION Living Encyclopedia compiler helpers.

This module is intentionally small. It validates documentation deltas emitted by
material ION operations and renders candidate summaries. It does not edit the
main encyclopedia, promote AIMOS lineage to current law, or export private
content to WisdomNET.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


DOCUMENTATION_DELTA_SCHEMA_ID = "ion.documentation_delta.v0_1"

REQUIRED_DELTA_FIELDS = [
    "schema_id",
    "packet_id",
    "branch_id",
    "operation_result",
    "context_delta",
    "template_delta",
    "doctrine_delta",
    "documentation_delta",
    "wisdomnet_signal",
    "atlas_signal",
    "source_posture",
    "non_claims",
]

VALID_SOURCE_POSTURES = {
    "CURRENT_ION_LAW",
    "CANDIDATE_ION_SURFACE",
    "AIMOS_LINEAGE_WITNESS",
    "WISDOMNET_STRUCTURAL_SIGNAL",
    "ATLAS_REFERENCE",
    "DAIMON_LINEAGE",
    "USER_REPORTED",
    "INFERENCE",
}

DENSITY_KEYS = [
    "D0_signal",
    "D1_operator_note",
    "D2_branch_summary",
    "D3_domain_summary",
    "D4_explainer_patch",
    "D5_north_star_patch",
    "D6_trace_refs",
]


@dataclass(frozen=True)
class DeltaValidation:
    accepted: bool
    findings: list[str]

    def to_dict(self) -> dict[str, Any]:
        return {"accepted": self.accepted, "findings": list(self.findings)}


def validate_documentation_delta(delta: dict[str, Any]) -> dict[str, Any]:
    """Validate a candidate documentation delta.

    The function is deliberately conservative. It validates structure and
    private-content firewall claims only; it does not decide whether doctrine
    should land.
    """

    findings: list[str] = []

    if not isinstance(delta, dict):
        return {"accepted": False, "findings": ["delta_not_object"]}

    for field in REQUIRED_DELTA_FIELDS:
        if field not in delta:
            findings.append(f"missing_field:{field}")

    if delta.get("schema_id") != DOCUMENTATION_DELTA_SCHEMA_ID:
        findings.append("schema_id_mismatch")

    source_posture = delta.get("source_posture", [])
    if not isinstance(source_posture, list) or not source_posture:
        findings.append("source_posture_missing_or_empty")
    else:
        for posture in source_posture:
            if posture not in VALID_SOURCE_POSTURES:
                findings.append(f"unknown_source_posture:{posture}")

    doctrine_delta = delta.get("doctrine_delta", {})
    if isinstance(doctrine_delta, dict):
        if doctrine_delta.get("settlement_required") is not True:
            findings.append("doctrine_delta_settlement_required_not_true")
    else:
        findings.append("doctrine_delta_not_object")

    wisdomnet_signal = delta.get("wisdomnet_signal", {})
    if isinstance(wisdomnet_signal, dict):
        if wisdomnet_signal.get("private_content_exported") is True:
            findings.append("wisdomnet_private_content_exported")
    else:
        findings.append("wisdomnet_signal_not_object")

    documentation_delta = delta.get("documentation_delta", {})
    if isinstance(documentation_delta, dict):
        for key in DENSITY_KEYS[:4]:
            if key not in documentation_delta:
                findings.append(f"missing_documentation_density:{key}")
    else:
        findings.append("documentation_delta_not_object")

    return {"accepted": not findings, "findings": findings}


def render_density_summary(delta: dict[str, Any], density: str = "D2") -> str:
    """Render one documentation density from a valid or candidate delta."""

    doc = delta.get("documentation_delta", {})
    packet_id = delta.get("packet_id", "UNKNOWN_PACKET")
    branch_id = delta.get("branch_id", "UNKNOWN_BRANCH")

    if density == "D0":
        return str(doc.get("D0_signal", "")).strip()
    if density == "D1":
        return str(doc.get("D1_operator_note", "")).strip()
    if density == "D2":
        return "\n".join(
            line
            for line in [
                f"packet_id: {packet_id}",
                f"branch_id: {branch_id}",
                str(doc.get("D2_branch_summary", "")).strip(),
            ]
            if line
        )
    if density == "D3":
        return "\n".join(
            line
            for line in [
                f"# Domain Summary — {packet_id}",
                "",
                str(doc.get("D3_domain_summary", "")).strip(),
            ]
            if line is not None
        )
    raise ValueError(f"unsupported_density:{density}")


def compile_candidate_report(deltas: list[dict[str, Any]]) -> dict[str, Any]:
    """Compile a candidate report from documentation deltas."""

    report: dict[str, Any] = {
        "schema_id": "ion.living_encyclopedia.candidate_report.v0_1",
        "accepted_state_claim": False,
        "delta_count": len(deltas),
        "accepted_delta_count": 0,
        "blocked_delta_count": 0,
        "findings": [],
        "summaries": [],
        "wisdomnet_signals": [],
        "atlas_signals": [],
    }

    for index, delta in enumerate(deltas):
        validation = validate_documentation_delta(delta)
        packet_id = delta.get("packet_id", f"delta_{index}")
        if validation["accepted"]:
            report["accepted_delta_count"] += 1
            report["summaries"].append(
                {
                    "packet_id": packet_id,
                    "branch_id": delta.get("branch_id"),
                    "D0": render_density_summary(delta, "D0"),
                    "D1": render_density_summary(delta, "D1"),
                    "D2": render_density_summary(delta, "D2"),
                }
            )
            report["wisdomnet_signals"].append(delta.get("wisdomnet_signal", {}))
            report["atlas_signals"].append(delta.get("atlas_signal", {}))
        else:
            report["blocked_delta_count"] += 1
            report["findings"].append({"packet_id": packet_id, "findings": validation["findings"]})

    return report


def load_delta_file(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Validate and compile ION documentation deltas.")
    parser.add_argument("delta_files", nargs="*", help="JSON documentation delta files")
    parser.add_argument("--json", action="store_true", help="print JSON report")
    args = parser.parse_args(argv)

    deltas = [load_delta_file(Path(p)) for p in args.delta_files]
    report = compile_candidate_report(deltas)
    if args.json:
        print(json.dumps(report, indent=2, sort_keys=True))
    else:
        print(f"delta_count: {report['delta_count']}")
        print(f"accepted_delta_count: {report['accepted_delta_count']}")
        print(f"blocked_delta_count: {report['blocked_delta_count']}")
    return 0 if report["blocked_delta_count"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
