# Next Packet: ION_UI_PACKET_002_EDGE_DRAWER_TIMELINE

**Status:** Candidate packet  
**Authority ceiling:** Design/template work only; no registry mutation; no live connector claim.  
**Parent package:** `ION_UI_DOMAIN_CONTEXT_PACKAGE_V0_1_1`  
**Created:** 2026-05-10T16:01:44.062850Z

## Objective

Create concrete implementation templates/primitives for:

1. `IonEdgeButton` / `IonEdgeIconButton`
2. `IonDualRailDrawerShell`
3. `IonBottomTimelineInspector`

## Required Context

- `ION_UI_EDGE_DRAWER_TIMELINE_PATCH_V0_1_1.md`
- `_ui_canon_bundle/uishader.txt`
- `_ui_canon_bundle/OPUS1_JOC_UI_DESIGN.md`
- `_ui_canon_bundle/CANON_JOC_UI_ARCHITECTURE.md`
- `_ui_canon_bundle/OPUS_VISUAL_SETTINGS_CANON.md`
- `_ui_canon_bundle/ULTIMATE_OPUS_VISUAL_INTERFACE_CANON.md`

## Return Contract

- Component-level spec
- State model
- Interaction map
- Responsive behavior
- Accessibility checklist
- Visual proof checklist
- Non-claims / unresolved design decisions

## Proof Required

- Four-side edge-frame state matrix
- Drawer split-zone behavior matrix
- Left/right drawer duty separation
- Bottom timeline collapsed/expanded state proof
- Visual observation packet before acceptance
