# Variable-Density Documentation Model

## Source lineage

AIMOS/AIM-ION appears to preserve variable-density planning as a serious documentation and context-management organ.

ION should integrate that idea directly.

## Density levels

```text
D0 — one-line signal
D1 — current operator note
D2 — branch summary
D3 — domain context package
D4 — main explainer section
D5 — full north-star chapter
D6 — source/receipt trace bundle
```

## Use cases

```text
GPT quick mount:
  D1/D2

Codex implementation:
  D2/D3/D6 when needed

Sev / PRO architecture review:
  D3/D4/D5

Living encyclopedia update:
  D4/D5 generated from D0-D3 + receipts

Cockpit:
  D0/D1 with drill-down to D6
```

## Rule

```text
ION should not have one documentation size.
ION should compile context at the density needed by the carrier and task.
```

## Implementation impact

The living encyclopedia compiler should store source deltas once and render multiple documentation densities from the same governed material.
