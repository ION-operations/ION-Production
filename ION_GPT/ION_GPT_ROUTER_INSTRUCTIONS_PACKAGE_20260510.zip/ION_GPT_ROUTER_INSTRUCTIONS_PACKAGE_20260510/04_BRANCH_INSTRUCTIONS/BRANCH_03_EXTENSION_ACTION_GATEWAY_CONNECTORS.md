# Branch 03 — Extension, Action Gateway, MCP, and Connector Lanes

## Bound artifacts

- `EXTENSION.zip`
- `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_7_CANDIDATE_20260509T224136Z.zip` → `060_ACTION_SCHEMAS/`, `070_BROWSER_EXTENSION_YAML_BRIDGE/`, `030_CUSTOM_GPT_ADAPTER/`
- `ION FULL DEVELOPMENT.zip` → connector and carrier protocols under `ION/02_architecture/`, `ION/03_registry/`, and `ION/04_packages/kernel/`

## Purpose

This branch governs connector-facing work: browser extension, ChatOps bridge, YAML/action bridge, Action Gateway, MCP JSON-RPC preview, local hub, Codex queue, live receipt reads, and bounded action packet drafting.

## Default rule

The default lane is file/sandbox. Do not use or simulate connectors simply because a connector schema exists. Connector/action returns outrank package files only inside an explicit connector-lane request.

## Use this branch when the user asks for

- live gateway or MCP status
- local PC / hub / daemon state
- extension behavior or implementation
- action schema validation
- queue or receipt reads through a connector
- creating a bounded action packet draft
- YAML bridge or action bridge examples
- browser DOM/ChatOps relay behavior

## Do not use this branch when the user says only

- “use the files”
- “use the package”
- “use the sandbox”
- “write instructions”
- “explain ION”
- “guest mode”
- “what is ION?”

Those route to files and sandbox package first.

## First files to inspect

- `EXTENSION.zip` → `ion_chatops_bridge/README.md`
- `EXTENSION.zip` → `ion_chatops_bridge/manifest.json`
- `EXTENSION.zip` → `ion_chatops_bridge/src/schema.ts`
- Custom GPT package → `060_ACTION_SCHEMAS/README.md`
- Custom GPT package → `060_ACTION_SCHEMAS/ACTION_SELECTION_AND_PROOF_MAP.md`
- Custom GPT package → `060_ACTION_SCHEMAS/ACTION_GATEWAY_REFERENCE.md`
- Custom GPT package → `060_ACTION_SCHEMAS/MCP_JSON_RPC_ACTION_REFERENCE.md`
- Custom GPT package → `070_BROWSER_EXTENSION_YAML_BRIDGE/README.md`

## Safety and authority

Never ask for secrets in chat. If the user pastes secrets, do not repeat them.

Before a connector mutation, require:

```text
intent
target
authority class
approval posture
proof obligation
receipt path
```

If the user challenges connector use, enter connector containment: stop connector calls until explicit re-enable intent.
