# ION Actions + MCP Connector Context Package v0.1

Generated: 2026-05-11T18:50:00Z
Carrier: ChatGPT Browser / ION-through-Custom-GPT
Posture: CANDIDATE CONTEXT PACKAGE — not settled ION state
Authority: Read/status cartography + validation-only mutation probes
Production authority: false
Live execution authority: false
Secrets authority: false

## 0. Package purpose

This package starts the comprehensive ION action-surface cartography workstream.

Goal:

```text
Build the ION Actions/MCP/Browser/Queue connector stack up to a level where ChatGPT Browser can safely operate like an IDE-grade local development agent, but only through ION protocols: bounded actions, proof gates, branch capsules, receipts, settlement, and explicit authority ceilings.
```

This package is deliberately not a “raw tool access” request. The target is:

```text
IDE-agent capability
+ local PC reach
+ no arbitrary shell by default
+ no credential access
+ no unreceipted state mutation
+ no direct acceptance of model output
+ no production/live authority unless separately granted and proven
```

## 1. Doctrine anchor

ION doctrine says AI output is not state. In practice, every action result, code patch, plan, queue request, or connector observation remains candidate until it is grounded in context, proof, acceptance, receipt, and continuity export.

The current connector cartography confirms that this doctrine is already reflected in the tool surfaces: most mutation-capable tools require explicit confirmation, idempotency, or approval; live execution and production authority remain false.

## 2. Live surfaces tested in this pass

### 2.1 Action Gateway

Observed health:

```json
{
  "gateway": "ion_custom_gpt_action_gateway",
  "status": "draft_non_production",
  "public_transport": "cloudflare_tunnel",
  "verdict": "ION_CUSTOM_GPT_ACTION_GATEWAY_READY",
  "production_authority": false,
  "live_execution_authority": false
}
```

Policy highlights:

```json
{
  "auth_required": true,
  "auth_scheme": "bearer",
  "max_body_bytes": 262144,
  "require_idempotency_key_for_mutation": true,
  "supported_mvp_intents": [
    "register_artifact",
    "write_file_draft",
    "create_codex_work_packet",
    "create_github_issue_draft"
  ],
  "hard_gated_intents": [
    "delete_file",
    "overwrite_protected_file",
    "push_main",
    "access_credential",
    "production_deploy",
    "broad_shell"
  ]
}
```

### 2.2 MCP preview

Observed health:

```json
{
  "verdict": "ION_CHATGPT_BROWSER_HTTP_MCP_PREVIEW_READY",
  "version_line": "V121_CHATGPT_BROWSER_HTTP_MCP_PREVIEW",
  "connector_state": "LOCAL_HTTP_PREVIEW_NOT_PUBLIC_CONNECTOR",
  "endpoint_path": "/mcp",
  "default_bind_host": "127.0.0.1",
  "default_port": 8765,
  "write_confirmation_required": true,
  "write_confirmation_token": "ION_BOUNDED_WRITE_CONFIRMED",
  "production_authority": false,
  "live_execution_authority": false
}
```

Forbidden MCP classes:

```text
arbitrary_file_write
arbitrary_shell
browser_computer_control
credential_access
direct_accept_unproofed_worker_output
direct_delete
git_push
production_deployment
provider_api_calls
unbounded_local_filesystem_access
```

### 2.3 ChatOps context pack

Observed root:

```text
/home/sev/ION - Production/ION_CODEX FULL
```

Observed current posture:

```json
{
  "carrier": "chatgpt_browser",
  "callsign": "Sev",
  "human_sovereign": "Braden",
  "ion_status": "ION_STATUS_READY",
  "agent_queue_request_count": 50,
  "queued_request_count": 9,
  "sandbox_return_count": 0
}
```

### 2.4 Browser carrier queue

Observed:

```json
{
  "queue_path": "ION/05_context/current/action_gateway/runtime/browser_queue.json",
  "pending_count": 2,
  "queued": 1,
  "needs_operator": 1,
  "max_queue_length": 25,
  "max_autoplay_turns": 10,
  "paused": false,
  "killed": false,
  "production_authority": false,
  "live_execution_authority": false
}
```

Two packet examples:

1. `BQ-e80d77cedffc2f39`: harmless echo/status packet, queued, no approval required.
2. `B01_RUNTIME_CONNECTORS_ACTIVATION_20260510`: read-only branch packet, needs operator approval.

### 2.5 Codex queue / daemon surface

Observed:

```json
{
  "automation_surface": "ion_codex_queue_process_once",
  "autorun_loop_state": "NOT_STARTED_PROCESS_ONCE_AVAILABLE",
  "active_process_running": false,
  "verdict": "ION_CODEX_QUEUE_RUNNER_READY"
}
```

Recent proof examples:

```text
B01_CODEX_RUNNER_TIMEOUT_POLICY_001
→ RETURN_RECORDED_PROOF_ACCEPTED
→ context proof accepted
→ template-action proof accepted
→ workload diff accepted

B01_B04_EXTENSION_QUEUE_PROTOCOL_CONTEXT_PACKAGE_001
→ RETURN_RECORDED_PROOF_BLOCKED
→ context proof rejected
→ template-action proof accepted
```

This is important: the local worker can run, return code 0, and still be blocked by ION proof gates. That is the right behavior.

## 3. Validation probes performed

All probes in this section were validation-only and did not mutate repo state.

### 3.1 Invalid schema probe

Intent: `create_codex_work_packet`

Input schema used:

```text
ion.action.v1
```

Result:

```json
{
  "verdict": "ION_CUSTOM_GPT_ACTION_GATEWAY_BLOCKED",
  "refusal_class": "SCHEMA_INVALID",
  "finding": "schema_must_be_ion_chatops_action_v1",
  "validated_without_mutation": true
}
```

Finding:

```text
Action Gateway envelope can be accepted while ChatOps validation rejects the action schema.
Correct schema for ChatOps MVP actions is ion.chatops.action.v1.
```

### 3.2 Valid create_codex_work_packet probe

Intent: `create_codex_work_packet`

Input schema:

```text
ion.chatops.action.v1
```

Result:

```json
{
  "verdict": "ION_CUSTOM_GPT_ACTION_GATEWAY_READY",
  "chatops_validation.accepted": true,
  "risk_class": "approval_required_mutation",
  "validated_without_mutation": true
}
```

Secondary finding:

```json
{
  "assistant_work_route.verdict": "ION_ASSISTANT_WORK_ROUTE_COMPILER_CANDIDATE_UNAVAILABLE",
  "findings": [
    "pyyaml_unavailable",
    "route_registry_missing_or_invalid",
    "lifecycle_registry_missing_or_invalid"
  ]
}
```

Meaning:

```text
The gateway can validate the packet, but assistant-work route compilation is degraded because route/lifecycle registries are missing or invalid and PyYAML is unavailable.
```

### 3.3 Valid register_artifact probe

Intent: `register_artifact`

Result:

```json
{
  "chatops_validation.accepted": true,
  "risk_class": "receipt_only",
  "validated_without_mutation": true
}
```

Finding:

```text
register_artifact is a lower-risk receipt-only lane when used correctly.
```

### 3.4 Valid write_file_draft probe

Intent: `write_file_draft`

Result:

```json
{
  "chatops_validation.accepted": true,
  "risk_class": "approval_required_mutation",
  "validated_without_mutation": true
}
```

Finding:

```text
write_file_draft validates but is still an approval-required mutation.
```

### 3.5 GitHub issue draft schema probe

Intent: `create_github_issue_draft`

Result:

```json
{
  "verdict": "ION_CUSTOM_GPT_ACTION_GATEWAY_BLOCKED",
  "refusal_class": "SCHEMA_INVALID",
  "findings": [
    "github_owner_required",
    "github_repo_required",
    "github_title_required",
    "github_body_required"
  ],
  "validated_without_mutation": true
}
```

A second attempt that placed `github_*` fields inside the visible `target` object still failed. Finding:

```text
The public Custom GPT action schema currently exposes target.path/name and content.text/format, but ChatOps expects GitHub-specific fields. The gateway/Custom GPT schema and ChatOps validator are mismatched for create_github_issue_draft.
```

## 4. MCP tool inventory summary

Observed MCP tools: 44.

### 4.1 Read/status tools

```text
ion_agent_list
ion_agent_queue
ion_agent_result
ion_agent_spawn_plan
ion_agent_status
ion_artifact_manifest
ion_carrier_message_poll
ion_carrier_onboarding_packet
ion_cockpit_view
ion_codex_capsule_chat_status
ion_codex_capsule_message_poll
ion_codex_queue_autorun_status
ion_codex_work_queue
ion_codex_worker_live_status
ion_context_compile
ion_context_plan
ion_current_operating_packet
ion_daemon_status
ion_file_read
ion_file_search
ion_git_status_summary
ion_read_active_packet
ion_receipt_hydrate
ion_receipt_search
ion_registry_read
ion_status
ion_swarm_status
ion_template_read
ion_tool_manifest
ion_tree_list
```

### 4.2 Bounded queue/write tools

```text
ion_agent_cancel
ion_agent_invoke
ion_artifact_upload_chunk
ion_artifact_upload_commit
ion_artifact_upload_init
ion_carrier_message_ack
ion_carrier_message_send
ion_codex_capsule_message_send
ion_codex_capsule_sync_to_queue
ion_codex_queue_process_once
ion_codex_runner_reconcile
ion_create_containment_receipt
ion_file_put_text
ion_queue_operator_message
ion_record_chatgpt_decision
ion_request_codex_work_packet
ion_submit_task_return
ion_swarm_step_once
```

Shared property:

```text
Mutation-capable MCP tools require ION_BOUNDED_WRITE_CONFIRMED and remain under production/live authority false.
```

## 5. Response-size and pagination findings

Some tools returned too much data for the connector surface.

Observed:

```text
ion_cockpit_view -> ResponseTooLargeError
ion_context_plan -> succeeded but content was truncated; content_bytes ≈ 53186
ion_codex_work_queue with high limit -> earlier response too large; lower limit worked
```

Required evolution:

```text
Every large status view needs:
- summary=true option
- cursor/page token
- limit/offset
- severity filters
- path-only mode
- JSONL event slices
- "latest only" mode
```

Without this, IDE-grade use will hit response limits before it hits authority limits.

## 6. Current blockers and gaps

### 6.1 Assistant-work route compiler degraded

Finding:

```text
ION_ASSISTANT_WORK_ROUTE_COMPILER_CANDIDATE_UNAVAILABLE
```

Observed causes:

```text
pyyaml_unavailable
route_registry_missing_or_invalid: ION/05_context/current/ai_assistant_work/registries/AI_ASSISTANT_WORK_ROUTE_REGISTRY_CANDIDATE_V0_1.yaml
lifecycle_registry_missing_or_invalid: ION/05_context/current/ai_assistant_work/candidate_lifecycle/CANDIDATE_DOMAIN_LIFECYCLE_REGISTRY_V0_1.yaml
```

Impact:

```text
The gateway can validate individual packets, but automated assistant-work routing cannot yet be trusted as a settled route compiler.
```

### 6.2 GitHub issue draft schema mismatch

Impact:

```text
create_github_issue_draft is listed as a supported MVP intent but cannot currently validate through the exposed Custom GPT schema surface.
```

### 6.3 Cockpit/status payloads too large

Impact:

```text
The cockpit already contains enough runtime state to exceed response limits. It needs a compressed status API before ChatGPT can use it as an IDE-grade dashboard.
```

### 6.4 Browser queue has human-gated packet pending

Impact:

```text
B01_RUNTIME_CONNECTORS_ACTIVATION_20260510 is queued but needs operator approval. The queue and receipts prove the surface exists; it is not an autoplay lane.
```

### 6.5 No live execution authority

This is not a defect. It is a safety boundary. But it means IDE-equivalent ability must be built as:

```text
bounded local action packets
+ operator approval when required
+ proof-return intake
+ branch capsule guard
+ settlement
```

not as direct shell/control.

## 7. Target architecture: IDE-equivalent without raw IDE risk

The desired target is not "ChatGPT gets raw PC control."

The desired target is:

```text
ChatGPT Browser
  -> Action Gateway / MCP Preview
    -> bounded typed actions
      -> branch capsule identity
        -> material-work guard
          -> local worker / Codex / daemon
            -> diff + tests + proof
              -> receipt + settlement
```

### 7.1 Capability layers needed

1. **Read/status parity**
   - file tree/list/search/read
   - git status summary
   - queue state
   - worker telemetry
   - artifact manifest
   - receipt search/hydration
   - cockpit summary

2. **Draft/write parity**
   - write-file draft
   - apply patch draft
   - create work packet
   - create issue draft
   - upload artifact
   - branch capsule creation
   - settlement request generation

3. **Execution parity**
   - bounded Codex work packet start
   - targeted test execution through worker
   - queue runner reconciliation
   - worker cancellation
   - retry from proof failure
   - no broad shell

4. **IDE feedback parity**
   - streaming or chunked worker output
   - compact diagnostics
   - test result panel
   - diff preview
   - stale active-run detector
   - receipt/proof result panel

5. **Governance parity**
   - branch capsule per conversation/agent/task
   - write-scope claims
   - material-work guard
   - settlement intake
   - no direct shared context writes
   - C-number assignment only by settler

## 8. Recommended next packets

### Packet A: ACTION_SURFACE_CONTEXT_PACKAGE_001

Purpose:

```text
Land this context package in the local repo as candidate documentation and machine-readable registry.
```

Required outputs:

```text
ION/05_context/current/action_surface_cartography/ION_ACTIONS_CONNECTOR_CONTEXT_PACKAGE_V0_1.md
ION/05_context/current/action_surface_cartography/ACTION_SURFACE_TEST_LOG_V0_1.json
ION/05_context/current/action_surface_cartography/ACTION_SURFACE_LIMITS_AND_VARIABLES_V0_1.json
ION/05_context/current/action_surface_cartography/ACTION_SURFACE_ROADMAP_V0_1.md
ION/05_context/current/context_settlement/inbox/SETTLE_ACTION_SURFACE_CONTEXT_PACKAGE_001_20260511.json
```

### Packet B: ACTION_GATEWAY_SCHEMA_ALIGNMENT_001

Purpose:

```text
Fix schema mismatch for create_github_issue_draft and document exact required fields in the Custom GPT action schema.
```

### Packet C: MCP_STATUS_PAGINATION_001

Purpose:

```text
Add summary/pagination/filter parameters to ion_cockpit_view, ion_context_plan, ion_codex_work_queue, and related large status surfaces.
```

### Packet D: ASSISTANT_WORK_ROUTE_COMPILER_REPAIR_001

Purpose:

```text
Repair pyyaml dependency/availability and restore missing route/lifecycle registries or make JSON fallback canonical.
```

### Packet E: IDE_EQUIVALENT_SAFE_LOCAL_OPS_001

Purpose:

```text
Create the high-level local-ops capability matrix mapping IDE-agent actions to ION-safe typed actions, proof gates, authority tiers, and UI requirements.
```

## 9. Non-claims

This package does not claim:

```text
production readiness
live execution authority
public connector deployment
GitHub mutation success
browser computer control
arbitrary shell access
credential access
settled ION state
that all actions were executed
that mutation tests were performed
```

This package does claim:

```text
read/status surfaces were inspected
validation-only Action Gateway probes were performed
MCP tool inventory was collected
several limits and schema gaps were identified
a safe roadmap toward IDE-equivalent local operations is now defined
```

## 10. Immediate next lawful move

Create a bounded local Codex packet to materialize this package into the repo under:

```text
ION/05_context/current/action_surface_cartography/
```

with no production authority, no live execution authority, no secrets, no git push, no direct shared context mutation, and a settlement inbox packet.
