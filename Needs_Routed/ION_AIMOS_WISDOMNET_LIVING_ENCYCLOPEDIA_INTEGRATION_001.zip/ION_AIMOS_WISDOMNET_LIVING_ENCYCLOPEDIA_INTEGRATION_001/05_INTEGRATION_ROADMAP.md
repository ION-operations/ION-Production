# Integration Roadmap

## Packet 1 — AIMOS lineage reconciliation

```text
PCKT-ION-AIMOS-LINEAGE-RECONCILIATION-001
```

Outputs:

- AIMOS source posture
- AIMOS anchor ledger
- AIMOS-to-current-ION integration matrix
- variable-density planning map
- north-star inheritance map
- template-evolution inheritance map

## Packet 2 — WisdomNET structural signal canon

```text
PCKT-ION-WISDOMNET-STRUCTURAL-EVOLUTION-CANON-001
```

Outputs:

- WisdomNET role definition
- private-content firewall
- structural metadata schema
- relationship to templates/domains/receipts
- Supabase event mirror plan
- cockpit signal requirements

## Packet 3 — Living encyclopedia compiler MVP

```text
PCKT-ION-LIVING-ENCYCLOPEDIA-COMPILER-001
```

Outputs:

- compiler protocol
- documentation delta schema
- documentation surface registry
- compiler helper
- tests
- generated candidate summary report

## Packet 4 — Variable-density rendering

```text
PCKT-ION-VARIABLE-DENSITY-DOCUMENTATION-001
```

Outputs:

- density-level renderer
- D0-D6 rendering rules
- branch/domain/current-state outputs
- cockpit drilldown model

## Packet 5 — Supabase/WisdomNET event mirror

```text
PCKT-ION-WISDOMNET-SUPABASE-EVENT-MIRROR-001
```

Outputs:

- `wisdomnet_structural_signals` schema
- `documentation_deltas` schema
- event ingest adapter
- cockpit query model
