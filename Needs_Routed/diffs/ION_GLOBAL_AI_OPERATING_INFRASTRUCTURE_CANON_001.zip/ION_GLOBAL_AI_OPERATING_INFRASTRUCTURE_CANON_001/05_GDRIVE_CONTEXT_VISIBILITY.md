# 05 — Google Drive Context Visibility

The immediate practical goal is to stop manual ZIP uploads.

## Operational decision

Use Google Drive as a full project mirror / readable context surface for GPT/PRO agents.

```text
Live local repo:
  /home/sev/ION - Production/ION_CODEX FULL

Google Drive mirror:
  ION_REPO_MIRROR/ION_CODEX_FULL
```

Codex and ION work in the live local repo. GPT carriers read the Drive mirror.

## Mirror guidance

The Drive mirror should be close to the full repo. It may exclude obvious generated/bulk folders if needed:

```text
.git/
.venv/
node_modules/
__pycache__/
.pytest_cache/
tmp/
large raw logs
```

But it should not become an over-curated export that loses project context.

## GPT mount file

The mirror should include:

```text
ION_REPO_MIRROR/START_HERE_FOR_GPT.md
ION_REPO_MIRROR/GIT_BRANCH.txt
ION_REPO_MIRROR/GIT_LOG.txt
ION_REPO_MIRROR/GIT_STATUS.txt
ION_REPO_MIRROR/TREE_SNAPSHOT.txt
ION_REPO_MIRROR/LAST_MIRROR_SYNC.txt
```

## Mount receipt from Drive

A GPT mounting from Drive should report:

```yaml
source_type: google_drive_repo_mirror
mirror_root:
last_sync:
git_branch:
latest_commit:
loaded_refs:
source_posture:
accepted_state_authority: false
```

## Why this matters

Manual ZIP upload is a failure mode. A Drive mirror turns project visibility into infrastructure.
