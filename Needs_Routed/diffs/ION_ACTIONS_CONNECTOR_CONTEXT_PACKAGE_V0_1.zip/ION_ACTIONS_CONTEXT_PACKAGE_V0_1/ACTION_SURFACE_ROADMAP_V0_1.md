# Action Surface Roadmap v0.1

## North star

Make ChatGPT Browser locally useful at an IDE-agent level while preserving ION safety:

```text
read broadly where allowed
write only through branch-scoped drafts or bounded packets
execute only typed worker actions
accept nothing without proof gates
settle shared state only through settlement
```

## Milestone 1 — Observability parity

- Summarized cockpit endpoint
- Paginated context plan
- Queue slices with cursor
- Worker telemetry slices
- Receipt hydration summaries

## Milestone 2 — Draft parity

- write_file_draft happy path
- register_artifact happy path
- create_github_issue_draft schema alignment
- branch capsule creation helper
- settlement request generator

## Milestone 3 — Worker parity

- selected queue item start
- live worker status stream or chunks
- targeted test command through typed templates
- worker cancellation and retry
- proof-repair auto-packet suggestions

## Milestone 4 — Local IDE safe-ops parity

- file read/search/tree
- diff preview
- patch draft
- test run
- queue/run/proof loop
- cockpit panel
- no raw shell
- no credentials
- no git push by default

## Milestone 5 — Settlement and context continuity

- branch capsule enforced for every agent/conversation/task
- material-work guard required
- settlement intake required
- shared context only mutated by settler
- C-number assignment serialized
