# SEV Supabase Connector Readiness Report — 2026-05-13

## Read-only connector proof

Supabase connector is available to this ChatGPT lane in read-only/discovery mode.

Observed project:

```text
project_id/ref: mtqsnfiixpakrhwomere
name: ION-operations's Project
region: us-west-1
status: ACTIVE_HEALTHY
postgres: 17.6.1.121 / postgres_engine 17 / ga
created_at: 2026-05-13T00:55:35.847151Z
```

Observed `ion_ops` tables:

```text
ion_ops.automation_events          RLS enabled, 2 rows
ion_ops.carrier_mount_receipts     RLS enabled, 2 rows
ion_ops.service_health_snapshots   RLS enabled, 3 rows
```

Observed migrations:

```text
001 initial_ion_ops
002 dev_private_cockpit_read_policies
003 ion_ops_authority_and_rpc
004 ion_ops_api_grants
005 ion_ops_cockpit_readmodel_fixes
```

## Security advisor findings

Supabase security advisor returned these current findings:

```text
ERROR security_definer_view: ion_ops.v_latest_service_health
ERROR security_definer_view: ion_ops.v_current_carrier_mounts
WARN  function_search_path_mutable: ion_ops.set_updated_at
WARN  anon_security_definer_function_executable: public.rls_auto_enable
WARN  authenticated_security_definer_function_executable: public.rls_auto_enable
```

The uploaded current repo already contains candidate migration/protocol files addressing these findings:

```text
ION/02_architecture/ION_SUPABASE_LIVE_ADVISORY_HARDENING_PROTOCOL_V0_1.md
supabase/migrations/006_ion_ops_live_advisory_hardening.sql
supabase/tests/validate_ion_ops_live_advisory_hardening_sql.py
```

## Local static validation

Ran inside extracted uploaded repo:

```bash
python3 supabase/tests/validate_ion_ops_live_advisory_hardening_sql.py
PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest -q supabase/tests/validate_ion_ops_live_advisory_hardening_sql.py
```

Result:

```text
5 passed in 0.12s
```

## Throttled call

Performance advisor call returned `429 ThrottlerException: Too Many Requests`. No performance posture claim is made.

## Recommended packet

```text
PCKT-ION-SUPABASE-LIVE-ADVISORY-HARDENING-006
```

Action:

```text
Review candidate migration 006 locally, validate static tests, then apply only with explicit Braden/operator approval against project mtqsnfiixpakrhwomere or an explicitly selected Supabase branch.
```

## Non-claims

```text
No migration applied.
No SQL mutation performed.
No service_role key requested or exposed.
No production authority claimed.
No accepted ION state claimed.
No performance advisor posture claimed due throttle.
```
