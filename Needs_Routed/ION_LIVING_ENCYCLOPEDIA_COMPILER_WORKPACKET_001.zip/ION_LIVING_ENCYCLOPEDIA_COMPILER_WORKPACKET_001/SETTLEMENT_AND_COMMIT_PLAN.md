# Settlement And Commit Plan

## Commit posture

Do not commit automatically.

Recommended commit after review:

```text
PCKT: add living encyclopedia compiler foundation
```

## Stage only

Expected staged families:

```text
ION/02_architecture/ION_LIVING_ENCYCLOPEDIA_COMPILER_PROTOCOL_V0_1.md
ION/03_registry/ion_documentation_surfaces.yaml
ION/03_registry/ion_template_delta_registry.yaml
ION/04_packages/kernel/ion_living_encyclopedia_compiler.py
ION/05_context/current/living_encyclopedia/
ION/07_templates/documentation_delta/
ION/tests/test_kernel_ion_living_encyclopedia_compiler.py
```

Do not stage:
- unrelated runtime state;
- patch receipts;
- unrelated diffs/workpackets;
- branch-capsule files unless part of prior reviewed commit;
- carrier mount/persona files unless part of prior reviewed commit;
- selected-start extension patch.

## Settlement path

This packet should create candidate surfaces only.

Expected settlement request:
`ION/05_context/current/living_encyclopedia/settlement_requests/SETTLE_LIVING_ENCYCLOPEDIA_COMPILER_001.json`

## Post-commit next packet

```text
PCKT-ION-TEMPLATE-DELTA-RETROFIT-001
```

Goal:
Retrofit major packet templates to require documentation/context/WisdomNET/ATLAS deltas.
