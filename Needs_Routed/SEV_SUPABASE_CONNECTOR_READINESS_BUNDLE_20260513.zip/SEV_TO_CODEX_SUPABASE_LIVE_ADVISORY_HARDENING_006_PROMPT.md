# Codex Prompt — PCKT-ION-SUPABASE-LIVE-ADVISORY-HARDENING-006

You are CODEX_LOCAL_ION_MASON.

## Goal

Validate and prepare the repo-managed Supabase live advisory hardening packet. Do not apply migrations unless Braden/operator explicitly approves in the local lane.

## Context proof expected

Confirm active root contains:

```text
pyproject.toml
ION/REPO_AUTHORITY.md
supabase/migrations/006_ion_ops_live_advisory_hardening.sql
supabase/tests/validate_ion_ops_live_advisory_hardening_sql.py
ION/02_architecture/ION_SUPABASE_LIVE_ADVISORY_HARDENING_PROTOCOL_V0_1.md
```

## Live advisory evidence from Sev read-only connector

Project:

```text
project_ref: mtqsnfiixpakrhwomere
name: ION-operations's Project
region: us-west-1
status: ACTIVE_HEALTHY
postgres: 17.6.1.121
```

Tables:

```text
ion_ops.automation_events          RLS enabled, rows observed: 2
ion_ops.carrier_mount_receipts     RLS enabled, rows observed: 2
ion_ops.service_health_snapshots   RLS enabled, rows observed: 3
```

Migrations observed:

```text
001 initial_ion_ops
002 dev_private_cockpit_read_policies
003 ion_ops_authority_and_rpc
004 ion_ops_api_grants
005 ion_ops_cockpit_readmodel_fixes
```

Security advisor findings observed:

```text
ERROR security_definer_view: ion_ops.v_latest_service_health
ERROR security_definer_view: ion_ops.v_current_carrier_mounts
WARN  function_search_path_mutable: ion_ops.set_updated_at
WARN  anon_security_definer_function_executable: public.rls_auto_enable
WARN  authenticated_security_definer_function_executable: public.rls_auto_enable
```

Performance advisor call was throttled with 429. Do not claim performance posture unless rechecked locally.

## Required validation

Run:

```bash
python3 supabase/tests/validate_ion_ops_live_advisory_hardening_sql.py

PYTHONDONTWRITEBYTECODE=1 \
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 \
python3 -m pytest -q supabase/tests/validate_ion_ops_live_advisory_hardening_sql.py
```

Also run the current repo's smallest meaningful Supabase validation if present.

## Apply gate

Do not apply migration 006 unless Braden/operator explicitly approves and confirms:

```text
project_ref mtqsnfiixpakrhwomere or selected branch target
migration 006 reviewed
rollback/repair path understood
no service_role key in chat
no accepted ION state claim
no production authority claim
```

## Return format

```text
### CONTEXT PROOF
### TEMPLATE ACTION PROOF
### VALIDATION
### LIVE ADVISORY POSTURE
### MIGRATION 006 REVIEW
### APPLY GATE STATUS
### NEXT COMMANDS
### NON-CLAIMS
```

## Non-claims required

```text
No migration applied unless explicitly approved.
No service_role key requested or exposed.
No accepted ION state claimed.
No production authority claimed.
No raw Codex context promoted.
```
