# PCKT-ION-JOC-LIVING-GRAPH-BROWSER-PROOF-INTERACTION-003

Generated: 2026-05-12T06:07:46+00:00

## Proof posture

Candidate patch package only. This packet does not claim accepted ION state, production deployment, live telemetry, live browser execution, browser screenshot proof, Git push, queue-worker execution, or Action/MCP mutation.

## Objective

Continue the ION JOC Living Operational Graph evolution after packets 001 and 002 by making the graph workbench operable and browser-proof-ready:

- project district polygons/minimap data from the graph layout fixture;
- expose focus lenses and local-only command deck;
- expose selected-object relationships, children, neighbors, routes, events, proof refs, and receipt refs;
- add JOC/browser proof fixture markers to the React workbench;
- add a local browser proof fixture manifest/handoff generator without executing a browser;
- extend static proof gates so browser-proof readiness is visible before screenshot capture.

## Required base patch chain

Apply in order:

```bash
git apply ion_joc_living_graph_view_model_panel_001.diff
git apply ion_joc_living_graph_source_mount_visual_proof_002.diff
git apply ion_joc_living_graph_browser_proof_interaction_003.diff
```

## Patch 003 files

```text
ION/04_packages/kernel/ion_living_graph_browser_proof_plan.py
ION/04_packages/kernel/ion_living_graph_view_model.py
ION/04_packages/kernel/ion_living_graph_visual_proof.py
ION/08_ui/joc_cockpit_shell/LivingGraphWorkbenchPanel.tsx
ION/08_ui/joc_cockpit_shell/ion-runtime-cockpit.css
ION/08_ui/joc_cockpit_shell/ionRuntimeCockpitTypes.ts
ION/tests/test_kernel_ion_living_graph_view_model.py
```

Patch stat:

```text
7 files changed, 1294 insertions(+), 40 deletions(-)
```

## What changed

### View model

`kernel.ion_living_graph_view_model` now projects:

```text
domain_districts
screen polygons
screen centroids
focus_lenses
command_deck
browser_proof_contract
selected_relationships
timeline.all_events
browser proof fixture count
focus lens count
command count
district count
```

It also changes the CLI `--write` mode to print a compact summary instead of dumping the full model to stdout, avoiding large-output instability.

### Browser proof handoff

Added:

```text
kernel.ion_living_graph_browser_proof_plan
```

It writes candidate-only local proof artifacts:

```text
ION/05_context/current/living_graph/BROWSER_PROOF_FIXTURE_MANIFEST_CANDIDATE.json
ION/05_context/current/living_graph/BROWSER_PROOF_HANDOFF_CANDIDATE.json
```

It does **not** execute a browser. It produces an explicit local/loopback-only fixture plan for a later visual harness.

### React workbench

`LivingGraphWorkbenchPanel.tsx` now includes:

```text
search/filter input
focus lens buttons
local-only command deck
district polygons
viewport HUD
minimap
relationship inspector
events inspector
proof inspector
raw compact tab
keyboard shortcuts: /, C, R, T, P
data-joc-zone markers
data-proof-fixture markers
```

### Static proof

`kernel.ion_living_graph_visual_proof` now checks:

```text
district_projection_present
focus_lenses_present
command_deck_present
browser_fixture_contract_present
required data-joc-zone / data-proof-fixture markers
```

## Validation

```text
py_compile: passed
pytest: 18 passed
static visual proof: candidate_visual_static_pass
browser proof handoff: candidate_browser_proof_handoff_ready
direct Vite build: passed, 68 modules transformed
```

`tsc --noEmit` still fails on older non-patch issues:

```text
ContextPackageInspectorPanel.tsx unknown -> ReactNode
DocsProjectsPackagesPanel.tsx implicit return type cycle
vite.config.ts moduleResolution / @vitejs/plugin-react resolution
```

The patch-local TypeScript issue in `LivingGraphWorkbenchPanel.tsx` was fixed before final validation.

## Generated proof artifacts

```text
ACTIVE_LIVING_GRAPH_VIEW_MODEL_003.json
ACTIVE_LIVING_GRAPH_VISUAL_PROOF_003.json
ACTIVE_LIVING_GRAPH_STATIC_PROOF_003.svg
BROWSER_PROOF_FIXTURE_MANIFEST_CANDIDATE_003.json
BROWSER_PROOF_HANDOFF_CANDIDATE_003.json
VALIDATION_REPORT_ION_JOC_LIVING_GRAPH_BROWSER_PROOF_INTERACTION_003.json
```

Key model metrics:

```json
{
  "browser_proof_fixture_count": 8,
  "command_count": 6,
  "district_count": 8,
  "domain_count": 8,
  "edge_count": 72,
  "event_count": 66,
  "focus_lens_count": 5,
  "live_telemetry_connected": false,
  "node_count": 64,
  "proof_required_route_count": 48,
  "risk_node_count": 1,
  "selected_relationship_count": 10,
  "timeline_track_count": 6,
  "visible_edge_count": 72,
  "visible_node_count": 64
}
```

Browser handoff gates:

```json
{
  "fixture_manifest_ready": true,
  "graph_shell_zones_fixture_present": true,
  "honesty_badge_fixture_present": true,
  "local_loopback_only": true,
  "minimap_fixture_present": true,
  "no_browser_execution_claim": true,
  "relationship_inspector_fixture_present": true
}
```

## Local validation commands

```bash
PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH=ION/04_packages \
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 \
python3 -m pytest -q \
  ION/tests/test_kernel_ion_living_graph_view_model.py \
  ION/tests/test_kernel_ion_cockpit_view_model.py \
  ION/tests/test_kernel_ion_local_cockpit_app.py

PYTHONPATH=ION/04_packages \
python3 -m kernel.ion_living_graph_visual_proof --root . --write

PYTHONPATH=ION/04_packages \
python3 -m kernel.ion_living_graph_browser_proof_plan --root . --write

cd ION/08_ui/joc_cockpit_shell
node node_modules/vite/bin/vite.js build
```

## Next lawful packet

```text
PCKT-ION-JOC-LIVING-GRAPH-BROWSER-CAPTURE-004
```

Recommended scope:

1. launch the local JOC shell on loopback;
2. open `http://127.0.0.1:8788/#graph`;
3. capture screenshot, DOM snapshot, console summary, and accessibility tree;
4. attach artifacts to the local visual harness / browser execution receipt lane;
5. run the fixture manifest from packet 003;
6. produce a candidate visual closure receipt;
7. do not claim accepted UI state until operator/Nemesis review settles it.

## Non-claims

```text
no accepted UI state
no production deployment
no git push
no live telemetry claim
no live browser execution
no browser screenshot proof
no Action/MCP mutation
no queue workers
no runtime mutation
```
