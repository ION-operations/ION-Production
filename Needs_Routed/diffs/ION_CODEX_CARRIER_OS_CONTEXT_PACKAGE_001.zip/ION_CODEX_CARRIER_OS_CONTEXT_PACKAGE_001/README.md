# ION Codex Carrier Operating System Context Package 001

Status: **candidate context package, not accepted state**  
Generated: 2026-05-12T14:37:47Z  
Active packet: `PCKT-ION-CODEX-CARRIER-OPERATING-SYSTEM-CARTOGRAPHY-001`  
Source snapshot: `ION_CODEX FULL2.zip`  
Snapshot SHA-256: `134338fbcde8f0a47106da735e7afb75add2311b7b0a99534606a67389dfdae2`

## Purpose

This package starts the lead branch for making Codex CLI/App a first-class ION carrier domain and ION operating cockpit substrate. It documents what is already present in the uploaded ION repo snapshot, how Codex native capabilities should map into ION law, what UI/cockpit surfaces are needed, and which implementation packets should come next.

## Core premise

Codex should not be treated as a generic terminal worker. It should become a governed ION carrier with:

- persistent Codex sessions mapped to ION branch capsules,
- Codex memories treated as working recall, not accepted state,
- hooks/slash commands/subagents aligned to ION domains,
- durable branch-capsule/receipt/settlement outputs,
- a cockpit that visualizes automations, agents, context, proof, drift, Git, and settlement.

## Source posture

This package uses:

1. the uploaded repo snapshot `ION_CODEX FULL2.zip`,
2. official Codex documentation as external feature reference,
3. prior ION lead-dev intake and branch maps as candidate evidence,
4. recent live read-only MCP smoke results from the current conversation.

It does **not** claim that every local unpushed file on the user PC matches the uploaded snapshot. It does **not** mutate state, start workers, or accept any candidate as settled.

## Package files

- `MANIFEST.json` — package manifest and source posture.
- `KEY_SURFACES.json` — hashes and metadata for high-value ION/Codex files in the snapshot.
- `REPO_CODEX_SURFACE_INDEX.json` — large source index for Codex/agent/MCP/UI/Git-related surfaces.
- `REPO_CODEX_SURFACE_INDEX_COMPACT.json` — compact version of the same index.
- `CURRENT_ION_CODEX_INFRASTRUCTURE.md` — current infrastructure map.
- `CODEX_NATIVE_CAPABILITY_MAP.md` — native Codex features and how ION should use them.
- `ION_CODEX_CARRIER_DOMAIN_MODEL.md` — proposed carrier domain model.
- `ION_CODEX_COCKPIT_REQUIREMENTS.md` — UI/cockpit and automation visualization requirements.
- `DRIFT_CONSISTENCY_PROOF_DASHBOARDS.md` — consistency, drift, proof, and stale-state dashboard design.
- `NEXT_IMPLEMENTATION_PACKETS.md` — recommended implementation sequence.
- `CODEX_LOCAL_AUDIT_PROMPT.md` — prompt for local Codex to perform the next read-only cartography pass.

## Immediate recommendation

The next work should be a **read-only local Codex cartography pass** using `CODEX_LOCAL_AUDIT_PROMPT.md`, then a small documentation/index commit, then implementation packets for Codex session registry, memory/capsule sync, hooks/slash commands, subagent registry, and cockpit graph surfaces.

Do not resume broad live Action/MCP mutation or worker spawning for this branch until the Codex carrier domain map is grounded and the branch-capsule consolidation state is reconciled.
