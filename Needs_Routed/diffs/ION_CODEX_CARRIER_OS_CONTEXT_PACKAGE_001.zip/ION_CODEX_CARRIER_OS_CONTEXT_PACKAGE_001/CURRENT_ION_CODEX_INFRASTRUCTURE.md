# Current ION Codex Infrastructure Map

Generated: 2026-05-12T14:37:47Z

## Snapshot caveat

This file is based on `ION_CODEX FULL2.zip`. The live local repo has continued to change through Codex after this snapshot. Treat this as a source-law and structure map, not absolute live truth.

## High-level inventory counts

```json
{
  "codex_project_config": {
    "file_count": 5,
    "bytes": 21151
  },
  "ion_codex_kernel": {
    "file_count": 18,
    "bytes": 439530
  },
  "agent_kernel": {
    "file_count": 9,
    "bytes": 174963
  },
  "mcp_action_connector": {
    "file_count": 5,
    "bytes": 421361
  },
  "codex_context_state": {
    "file_count": 846,
    "bytes": 26280332
  },
  "agent_branches": {
    "file_count": 5,
    "bytes": 6478
  },
  "git_orchestration": {
    "file_count": 34,
    "bytes": 284708
  },
  "ui_cockpit": {
    "file_count": 2498,
    "bytes": 75147096
  },
  "diffs_workpackets": {
    "file_count": 79,
    "bytes": 49010029
  },
  "doctrine_architecture": {
    "file_count": 58,
    "bytes": 205562
  }
}
```

## Core project Codex mount surfaces

### `.codex/config.toml`

The project-level Codex config exists and is explicitly ION-aware. It sets workspace-write sandboxing, `on-request` approval, Codex hooks, active root guidance, and an `ion_local` MCP server entry.

Key effects:
- Codex is pointed at the active ION root.
- Codex is told to use `codex_solo/HOT_CONTEXT.md` as natural boot context.
- Codex hooks are enabled.
- The SessionStart hook is configured.

### `.codex/hooks/ion_session_start_context.py`

The SessionStart hook is read-only and calls `kernel.ion_codex_solo_context.build_codex_solo_boot_context`. This means Codex already has a deterministic ION context injection path. The future Codex carrier domain should extend this hook into branch identity and rolling-context sync, not replace it.

### `ION/05_context/current/codex_solo/`

This is a substantial current Codex Solo continuity substrate:
- `CAPSULE.md`
- `MINI.md`
- `HOT_CONTEXT.md`
- `STATUS.json`
- `ROUTE.json`
- `CONTEXT_PACKAGES.json`
- `LONG_HORIZON.json`
- `history/`

This is already close to a durable Codex carrier memory layer. It should become a parent context surface for named Codex branch sessions, not the only state for all Codex work.

### `ION/05_context/current/codex_capsule_chat/`

This is a local Codex Capsule Chat / cockpit-adjacent lane with many files. It should be audited as a UI+state surface for the future ION Codex Cockpit.

### `ION/05_context/current/chatgpt_connector/`

This is currently the most developed carrier bridge area. It contains:
- Codex work requests,
- queue runs,
- task returns,
- artifact uploads/receipts,
- patch receipts,
- runtime ledgers,
- carrier messages,
- agent invocations,
- logs and queue state.

This area already embodies the bridge between ChatGPT Browser, local Codex, receipts, and proof gates.

## Kernel modules already present

Important Codex and carrier modules in the snapshot include:

- `ion_codex_solo_context.py`: builds Codex Solo capsule context and records pre/post context entries.
- `ion_codex_chat_engine.py`: classifies Codex chat turns and response modes.
- `ion_codex_queue_runner.py`: bounded local Codex worker runner for queued work packets.
- `ion_codex_chat_response_carrier.py`: response-only Codex carrier, separate from implementation work.
- `ion_dual_codex_chat.py`: Codex Capsule Chat state/projection.
- `ion_codex_cli_carrier_audit.py`: audits Codex CLI carrier mount surfaces.
- `ion_agent_invocation_broker.py`: compiles role/context evidence into bounded Codex work requests.
- `ion_chatgpt_browser_mcp_connector_contract.py`: bounded MCP connector contract.
- `ion_chatgpt_browser_mcp_http_preview.py`: local MCP HTTP preview.
- `ion_local_cockpit_app.py`: local cockpit web app.

## Existing agent/domain surfaces

The snapshot already has:
- `.cursor/agents/` with ION role-like agent files.
- `ION/03_registry/agent_roster_registry.yaml`.
- `ION/03_registry/ion_bounded_agent_role_registry.yaml`.
- `ION/03_registry/ion_skill_registry.yaml`.
- `ION/05_context/current/agent_context_branches/` with a provisional registry and templates.

The future Codex carrier domain should reconcile with these, not invent a parallel agent registry from scratch.

## Existing Git/GitHub orchestration

The snapshot contains a developed Git orchestration lane:

- `ION/05_context/current/git_orchestration/`
- `ION/02_architecture/ION_GITHUB_DATA_PLANE_PROTOCOL.md`
- `ION/02_architecture/ION_GITHUB_WORK_DAEMON_PROTOCOL.md`
- `ION/docs/GITHUB_BRANCHING_AND_LIVE_STATE_POLICY.md`
- `ion_github_data_plane_audit.py`
- `ion_github_commit_proposal_receipt.py`

This means a Git specialist should be an evolution/mount of existing Git orchestration, not a newly invented role.

## Existing UI/cockpit surfaces

The snapshot contains a large UI tree under `ION/08_ui/joc_cockpit_shell/` and many Python UI/cockpit modules. The Codex Carrier OS must align with JOC/OPUS UI canon and local cockpit architecture.

## Key gaps

1. Codex sessions are not yet first-class ION session records.
2. Codex memories are not mapped to ION branch capsules.
3. Codex subagents are not mapped to ION agent/domain branches.
4. Codex hooks are not yet used as a full ION enforcement/sync layer.
5. There is no consolidated Codex Carrier Domain registry.
6. The cockpit does not yet show complete agent/session/context/memory/proof/drift/Git/settlement graphs.
7. Duplicate audit still needs compact/summary mode.
8. Some candidate branch-capsule code has landed in live local work, but the uploaded snapshot predates that consolidation.
