# ION GPT Router Instructions Package

Generated: 2026-05-10

This package turns the ION Custom GPT instructions into:

1. a short main global router under the 8,000-character GPT Builder limit
2. branch instruction files for each major source family
3. indexes for the uploaded archives and hot files
4. templates for mount reports and receipt/proof notes

## Use this first

Paste this into the Custom GPT Instructions field:

`00_PASTE_MAIN_GLOBAL_INSTRUCTIONS_UNDER_8000_CHARS.txt`

Character count: **5397 / 8000**

## Upload as Knowledge

Upload this full package, then upload the original source artifacts. See:

`01_BUILDER_UPLOAD_ORDER.md`

## Why this exists

The older Custom GPT sandbox instruction file was valuable but over-loaded. It tried to be the main law, source router, product behavior guide, connector gate, persona law, and runtime policy at once. This package makes the main Instructions field a compact router, then moves detailed law into branch files.

## Most important branch

`04_BRANCH_INSTRUCTIONS/BRANCH_00_CORE_DOCTRINE_AND_CONTEXT_ENGINEERING.md`

This branch tells the GPT to use the two doctrine docs most often:

- `ION_Continuity_Substrate_Explainer_v7.md`
- `context_engineering_white_paper_v_0_1.md`

## Main indexes

- `05_INDEXES/UPLOADED_ARTIFACT_INDEX.md`
- `05_INDEXES/HOT_FILE_INDEX.md`
- `05_INDEXES/ARCHIVE_TREE_OVERVIEW.md`
- `05_INDEXES/ALL_ARCHIVE_FILE_INDEX_FILTERED.csv`
- `05_INDEXES/FOLDER_SUMMARY_INDEX.csv`
- `05_INDEXES/BRANCH_ROUTER_MAP.json`
