# ION Supabase Adapter Design

## Local Module

Proposed file:

```text
ION/04_packages/kernel/ion_supabase_operating_runtime.py
```

Initial commands:

```bash
python3 -m kernel.ion_supabase_operating_runtime --status --json
python3 -m kernel.ion_supabase_operating_runtime --dry-run-events --json
python3 -m kernel.ion_supabase_operating_runtime --mirror-event <event.json> --json
```

## Config

```text
ION/03_registry/ion_supabase_operating_runtime_registry.yaml
```

Fields:

- project_ref (optional, redacted if secret-bearing)
- enabled
- write_enabled
- read_only_mode
- allowed_event_families
- table_map
- RLS posture
- MCP posture

## Credentials

Do not store credentials in repo.

Use env vars or local secret manager:

- `ION_SUPABASE_URL`
- `ION_SUPABASE_SERVICE_ROLE_KEY` (only local/admin, never exposed)
- `ION_SUPABASE_ANON_KEY` for read-only UI as appropriate

## Fail Closed

If credentials absent:

- status returns `SUPABASE_NOT_CONFIGURED`
- dry-run remains available
- no writes attempted

## Local Receipt First

All mirror operations require:

- source_path
- source_sha256 or explicit no_hash reason
- source_posture
- accepted_state_claim=false unless settlement source supplied
