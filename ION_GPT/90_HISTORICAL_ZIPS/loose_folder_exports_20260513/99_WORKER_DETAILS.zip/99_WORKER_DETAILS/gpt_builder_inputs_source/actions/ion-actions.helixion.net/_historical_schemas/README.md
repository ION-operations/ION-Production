# Historical Schemas

Old or candidate schemas can be placed here for evidence and comparison.

Do not paste files from this folder into GPT Builder unless a new Action Release bundle explicitly promotes one.

Current active schema remains:

```text
../SCHEMA_TO_PASTE.yaml
```
