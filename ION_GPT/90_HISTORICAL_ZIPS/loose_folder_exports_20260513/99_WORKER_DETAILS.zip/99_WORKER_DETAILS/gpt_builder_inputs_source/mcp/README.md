# MCP Inputs

MCP is separate from GPT Builder Actions.

Current MCP public URL:

```text
https://ion.helixion.net/mcp
```

Current Custom GPT Action URL:

```text
https://ion-actions.helixion.net
```

Use the Action folder for GPT Builder Actions. Use this MCP folder only for MCP/client/app connector setup or diagnostics.
