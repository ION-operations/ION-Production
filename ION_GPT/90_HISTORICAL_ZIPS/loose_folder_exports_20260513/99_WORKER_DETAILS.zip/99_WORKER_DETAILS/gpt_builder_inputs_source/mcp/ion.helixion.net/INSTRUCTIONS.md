# ION MCP Surface

This is the ION MCP preview/connector surface.

## URL

```text
https://ion.helixion.net/mcp
```

## Local service

```text
127.0.0.1:8765
```

## Important distinction

This is not the Custom GPT Builder Action schema.

For GPT Builder Actions, use:

```text
ION_GPT/gpt_builder_inputs/actions/ion-actions.helixion.net/SCHEMA_TO_PASTE.yaml
```

## Can the Custom GPT reach MCP through Actions?

Partly, yes, if the Action Gateway exposes a safe endpoint that reads from MCP/local state or mirrors MCP-derived status.

But raw MCP is not the same as GPT Builder Actions:

- Actions use OpenAPI over HTTPS.
- MCP uses MCP protocol/JSON-RPC style tool surfaces.
- The Action Gateway is the safe bridge for Custom GPT Actions.

## Current posture

Do not install this as an Action schema. This is a connector/client surface reference.
