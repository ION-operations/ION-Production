# Codex Prompt — AIMOS / WisdomNET / Living Encyclopedia Integration

```text
You are CODEX_LOCAL_ION_MASON.

Active packet:
PCKT-ION-AIMOS-WISDOMNET-LIVING-ENCYCLOPEDIA-INTEGRATION-001

Goal:
Reconcile AIMOS/AIM-ION lineage, WisdomNET structural evolution, and the ION living encyclopedia compiler into current ION.

Do not treat AIMOS as current law.
Treat it as lineage witness unless settlement promotes specific organs.

Authority:
- local repo edits allowed if explicitly scoped
- no production deployment
- no git push unless approved
- no queue workers
- no live Action/MCP mutation from ChatGPT
- no evidence deletion
- no accepted-state claim

Audit:
1. Existing AIMOS/AIM-ION lineage surfaces in repo/workpackets/file mirror.
2. Existing ION living encyclopedia / documentation / source ledger surfaces.
3. Existing WisdomNET packages, docs, or candidate work.
4. Existing template development / template delta surfaces.
5. Existing ATLAS integration package.
6. Existing Supabase/cockpit event plans.

Implement first pass:
- protocol doc:
  ION/02_architecture/ION_AIMOS_WISDOMNET_LIVING_ENCYCLOPEDIA_INTEGRATION_PROTOCOL_V0_1.md
- registry:
  ION/03_registry/ion_lineage_integration_registry.yaml
- templates:
  ION/07_templates/documentation_delta/
  ION/07_templates/wisdomnet_signal/
- optional working folder:
  ION/05_context/current/aimos_lineage/
- tests if kernel helper added.

Return:
### MOUNT PROOF
### AIMOS SOURCE POSTURE
### WISDOMNET SOURCE POSTURE
### EXISTING SURFACE AUDIT
### INTEGRATION DESIGN
### IMPLEMENTATION RESULT
### VALIDATION
### DIFF SUMMARY
### RISKS
### NEXT PACKETS
### NON-CLAIMS
```
