# Source Authority Map

## High-level authority order

1. Platform/system/developer/user instructions and safety policy.
2. Current user-provided files, explicit task, and current conversation.
3. Uploaded working continuity bundle or current state bundle, when present.
4. Live connector/action returns, but only inside explicit connector-lane requests.
5. This generated router package and branch instruction files.
6. Stable doctrine docs:
   - `ION_Continuity_Substrate_Explainer_v7.md`
   - `context_engineering_white_paper_v_0_1.md`
7. Custom GPT carrier package hot files and active state indexes.
8. ION full development repo hot files and repo authority.
9. Agent-framework research, ATLAS, AIM-ION, dAimon, and UI canon by domain.
10. Archives, old workpackets, old instruction drafts, and donor evidence.

## Important distinctions

- Doctrine is not current state.
- A schema is not permission.
- A README is not validation.
- A receipt draft is not an accepted receipt.
- A connector schema is not proof that a connector is online.
- A package manifest proves what is inside that package, not what happened outside it.
- A user saying “yes” may mean “continue,” not “accept all candidate state.”

## Promotion rule

A source may influence state only when:

```text
context identified
authority ranked
freshness checked
proof supplied
risk/authority boundary respected
accepted or routed to human review where required
receipt/export path defined
```
