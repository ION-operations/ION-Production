# Next Packets

## Immediate

### PCKT-ION-FULL-GDRIVE-REPO-MIRROR-001

Make full repo mirror visible to GPT/PRO through Google Drive. Stop manual ZIP loop.

### PCKT-ION-BRANCH-CAPSULE-COMMIT-REVIEW-006

Commit branch-capsule consolidation carefully.

### PCKT-ION-CARRIER-MOUNT-PERSONA-COMMIT-REVIEW-001

Commit carrier mount/persona presentation carefully after branch-capsule commit.

## Architecture / cartography

### PCKT-ION-CODEX-CARRIER-OPERATING-SYSTEM-CARTOGRAPHY-001

Map Codex CLI/App as first-class ION carrier.

### PCKT-ION-ATLAS-OPERATING-NETWORK-INTEGRATION-001

Use ATLAS to audit ION OS-class dimensions.

### PCKT-ION-SUPABASE-CARRIER-CARTOGRAPHY-001

Audit Supabase availability, MCP, schema needs, and cockpit role.

### PCKT-ION-CHATGPT-APP-CARRIER-CARTOGRAPHY-001

Map ChatGPT apps/connectors into ION carriers.

## Runtime build

### PCKT-ION-SUPABASE-OPERATING-RUNTIME-SCHEMA-001

Create first schema: automation_events, carrier_mount_receipts, service_health_snapshots.

### PCKT-ION-SUPABASE-EVENT-MIRROR-001

Mirror selected ION events to Supabase after local receipts.

### PCKT-ION-COCKPIT-OPERATING-UI-SPEC-001

Turn cockpit vision into UI implementation spec.

### PCKT-ION-COCKPIT-MVP-001

Build first dashboard: services, agents, packets, events, drift, receipts.

## External lanes

### PCKT-ION-DAIMON-GOOGLE-LANE-INTEGRATION-001

Project dAimon receipts/traces into ION cockpit.

### PCKT-ION-SLACK-CARRIER-BUS-001

Create Slack comms/notifications carrier lane.

### PCKT-ION-GITHUB-GITLAB-CARRIER-RECONCILE-001

Reconcile GitHub/GitLab apps, Git orchestration, and source review flows.

## ATLAS expansion

### PCKT-ATLAS-CODEX-CLI-APP-PACKAGE-001

Create ATLAS package for Codex CLI/App.

### PCKT-ATLAS-SUPABASE-PLATFORM-PACKAGE-001

Create ATLAS package for Supabase platform.

### PCKT-ATLAS-ION-SYSTEM-PACKAGE-001

Create ATLAS package for ION as a system.
