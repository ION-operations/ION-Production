# Recent Changes and Verified State

## Context

The recent workstream began after live ChatGPT/MCP mutation calls produced delayed/no-receipt duplicate B00 work packets. The project then pivoted into a bootstrap repair chain to make future Action/MCP editing safe.

## Pushed ION commits

Known pushed ION commits on `feature/codex-capsule-chat-active-root`:

```text
7d89d81 B00: repair ChatGPT carrier idempotency and bounded patch tooling
45d896c B00: supersede duplicate spawn-contract queue packets
3ba0d84 PCKT: record ION local port routing truth
4527c6e B00: preserve bounded patch confirmation through MCP adapter
```

## Pushed dAimon commit

Known pushed dAimon commit on `main`:

```text
32c4d30 PCKT: move dAimon Gemini bridge to 8795
```

## Local service routing after repair

Current verified local routing after refresh:

```text
8765 = ION MCP preview
8777 = ION Action Gateway
8788 = ION local cockpit
8795 = dAimon Gemini bridge
8796 = reserved dAimon secondary
```

Verified from Codex local report and ChatGPT MCP health:

```text
ION MCP preview health: ION_CHATGPT_BROWSER_HTTP_MCP_PREVIEW_READY
Action Gateway health: ION_CUSTOM_GPT_ACTION_GATEWAY_READY
Local cockpit health: ION_LOCAL_COCKPIT_APP_READY
dAimon Gemini websocket: passed
MCP tools/list: passed
```

## B00 duplicate cleanup

The duplicate B00 no-receipt packet contamination was cleaned by preservation/supersession, not deletion.

Result:

```text
status: DUPLICATES_SUPERSEDED_NOT_DELETED
superseded_count: 153
B00 status counts:
  QUEUED_FOR_CODEX_CARRIER: 1
  SUPERSEDED_DUPLICATE: 153
proof-blocked B00 task return preserved: true
```

## MCP bounded patch lane smoke

MCP smoke sequence:

1. MCP health passed.
2. `ion_status` returned `ION_STATUS_READY`.
3. `ion_bounded_patch_preview` succeeded on an allowed policy file.
4. `ion_bounded_patch_preview` correctly refused out-of-scope `ION/docs/...`.
5. Initial `ion_bounded_patch_apply` found an adapter bug: confirmation was stripped before forwarding.
6. Fix `4527c6e` was applied/pushed.
7. MCP preview restarted.
8. `ion_bounded_patch_apply` succeeded with `ION_BOUNDED_WRITE_CONFIRMED`.
9. Smoke edit was verified.
10. Smoke edit was reverted through the same bounded patch lane.
11. Final file hash returned to the original.
12. Patch receipts remain as local runtime/candidate evidence.

Conclusion:

```text
MCP preview restored.
Bounded patch preview works.
Bounded patch apply works.
Path allowlist works.
Receipts are written.
Production/live authority remains false.
```

## Branch capsule consolidation

Codex reported local completion of:

```text
PCKT-ION-BRANCH-CAPSULE-CONSOLIDATION-006
```

Reported result:

- Existing branch-capsule candidate diffs were not blindly applied.
- Consolidated runtime helper, protocols, registry, tests, branch-local candidate record, settlement request.
- Validation: branch capsule tests and Codex solo context tests passed (`21 passed`).
- No push was reported for this consolidation at the time this addendum was created.
- Treat this as Codex-reported/local-candidate until git commit/push proof is provided.

## Remaining dirty/candidate state

Known remaining excluded local state:

- dirty runtime/state files
- local patch receipts
- untracked candidate diffs/workpackets
- branch-capsule candidate artifacts if not committed
- dAimon unrelated dirty docs/sample/orchestration files

These should not be broad-staged.
