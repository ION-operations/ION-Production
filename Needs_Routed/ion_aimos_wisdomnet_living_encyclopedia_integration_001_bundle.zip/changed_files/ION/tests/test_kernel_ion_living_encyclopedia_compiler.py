import json
from pathlib import Path

from kernel.ion_living_encyclopedia_compiler import (
    compile_candidate_report,
    render_density_summary,
    validate_documentation_delta,
)


def _valid_delta():
    return {
        "schema_id": "ion.documentation_delta.v0_1",
        "packet_id": "PCKT-TEST",
        "branch_id": "branch_test",
        "operation_result": {
            "what_happened": "implemented a candidate test surface",
            "proof": ["pytest passed"],
            "touched_surfaces": ["ION/tests/test_kernel_ion_living_encyclopedia_compiler.py"],
            "validation": ["unit"],
        },
        "context_delta": {
            "new_context_nodes": ["node:test"],
            "changed_context_nodes": [],
            "stale_context_nodes": [],
            "future_inheritance": "candidate only",
        },
        "template_delta": {
            "template_used": "ION_DOCUMENTATION_DELTA_TEMPLATE_V0_1",
            "template_gap": "",
            "template_improvement_signal": "",
        },
        "doctrine_delta": {
            "candidate_claim": "documentation deltas can compile summaries",
            "affected_sections": ["Living Encyclopedia"],
            "confidence": "medium",
            "settlement_required": True,
        },
        "documentation_delta": {
            "D0_signal": "test signal",
            "D1_operator_note": "test operator note",
            "D2_branch_summary": "test branch summary",
            "D3_domain_summary": "test domain summary",
            "D4_explainer_patch": "",
            "D5_north_star_patch": "",
            "D6_trace_refs": [],
        },
        "wisdomnet_signal": {
            "signal_class": "template_gap_detected",
            "structural_pattern": "documentation_delta",
            "workflow_pattern": "compile_from_receipts",
            "failure_class": "",
            "domain_pattern": "living_encyclopedia",
            "private_content_exported": False,
        },
        "atlas_signal": {
            "os_dimension": "documentation_subsystem",
            "comparative_reference": "operating manuals",
            "platform_pattern": "generated docs from events",
        },
        "source_posture": ["CANDIDATE_ION_SURFACE", "AIMOS_LINEAGE_WITNESS"],
        "non_claims": ["not accepted state"],
    }


def test_valid_documentation_delta_passes():
    result = validate_documentation_delta(_valid_delta())
    assert result["accepted"] is True
    assert result["findings"] == []


def test_missing_context_instance_style_required_fields_blocks():
    delta = _valid_delta()
    delta.pop("packet_id")
    result = validate_documentation_delta(delta)
    assert result["accepted"] is False
    assert "missing_field:packet_id" in result["findings"]


def test_wisdomnet_private_content_export_blocks():
    delta = _valid_delta()
    delta["wisdomnet_signal"]["private_content_exported"] = True
    result = validate_documentation_delta(delta)
    assert result["accepted"] is False
    assert "wisdomnet_private_content_exported" in result["findings"]


def test_doctrine_delta_requires_settlement():
    delta = _valid_delta()
    delta["doctrine_delta"]["settlement_required"] = False
    result = validate_documentation_delta(delta)
    assert result["accepted"] is False
    assert "doctrine_delta_settlement_required_not_true" in result["findings"]


def test_render_density_summary():
    delta = _valid_delta()
    assert render_density_summary(delta, "D0") == "test signal"
    assert "PCKT-TEST" in render_density_summary(delta, "D2")


def test_compile_candidate_report_groups_signals():
    report = compile_candidate_report([_valid_delta()])
    assert report["accepted_state_claim"] is False
    assert report["accepted_delta_count"] == 1
    assert report["blocked_delta_count"] == 0
    assert report["summaries"][0]["D0"] == "test signal"


def test_compile_candidate_report_records_blocked_delta():
    bad = _valid_delta()
    bad["source_posture"] = ["UNKNOWN"]
    report = compile_candidate_report([bad])
    assert report["accepted_delta_count"] == 0
    assert report["blocked_delta_count"] == 1
    assert report["findings"][0]["packet_id"] == "PCKT-TEST"
