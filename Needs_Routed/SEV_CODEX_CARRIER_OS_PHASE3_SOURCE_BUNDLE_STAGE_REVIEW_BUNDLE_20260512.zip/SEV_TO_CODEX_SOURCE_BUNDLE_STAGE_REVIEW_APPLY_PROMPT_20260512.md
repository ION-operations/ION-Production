You are CODEX-001 operating in the local ION root.

Packet:

```text
PCKT-ION-CODEX-SOURCE-BUNDLE-STAGE-REVIEW-003
```

Mission:
Apply Sev's Phase 3 source-bundle stage-review patch after Phase 2, validate it, generate the local source-bundle stage review artifacts, and return proof. Do not stage, commit, push, restart services, promote raw Codex context, or claim accepted ION state.

Expected local root:

```text
/home/sev/ION - Production/ION_CODEX FULL
```

Input patch:

```text
SEV_CODEX_CARRIER_OS_PHASE3_SOURCE_BUNDLE_STAGE_REVIEW_INCREMENTAL_20260512.patch
```

Required commands:

```bash
git apply SEV_CODEX_CARRIER_OS_PHASE3_SOURCE_BUNDLE_STAGE_REVIEW_INCREMENTAL_20260512.patch

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=ION/04_packages PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest \
  ION/tests/test_kernel_ion_codex_source_bundle_stage_review.py \
  ION/tests/test_kernel_ion_codex_commit_boundary_audit.py \
  ION/tests/test_kernel_ion_codex_carrier_os.py \
  ION/tests/test_kernel_ion_mcp_local_bridge.py -q

git diff --check

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=ION/04_packages python3 -S -m kernel.ion_codex_source_bundle_stage_review \
  --ion-root . \
  --write \
  --confirmation ION_CODEX_SOURCE_BUNDLE_STAGE_REVIEW_WRITE_CONFIRMED \
  --json

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=ION/04_packages python3 -S -m kernel.ion_codex_carrier_os write \
  --ion-root . \
  --confirmation ION_CODEX_CARRIER_OS_WRITE_CONFIRMED \
  --json
```

Return:

```text
CONTEXT PROOF
TEMPLATE ACTION PROOF
GENERATED REFS
SOURCE BUNDLE REVIEW RESULT
EXCLUDED BUNDLE SUMMARY
VALIDATION
BLOCKERS
NON-CLAIMS
```

Generated refs expected:

```text
ION/05_context/current/codex_carrier/commit_boundary/CODEX_SOURCE_BUNDLE_STAGE_REVIEW.json
ION/05_context/current/codex_carrier/commit_boundary/CODEX_SOURCE_BUNDLE_STAGE_MANIFEST.candidate.json
ION/05_context/current/codex_carrier/CODEX_CARRIER_OS_SOURCE_MAP.json
ION/05_context/current/codex_carrier/CODEX_SLASH_COMMAND_REGISTRY.json
```

Non-claims required:

```text
no accepted ION state
no production authority
no live execution authority
no secrets authority
no git staging
no git commit
no git push
no GitHub mutation
no raw Codex memory/session promotion
```
