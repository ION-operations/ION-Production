# Branch 01 — Custom GPT Sandbox Carrier Package

## Bound artifact

`ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_7_CANDIDATE_20260509T224136Z.zip`

## Purpose

This is the operational Custom GPT sandbox package candidate. It contains the older near-8K instruction kernel, sandbox mount order, active state indexes, action schemas, product docs, starter data, extension/YAML bridge references, validation reports, and embedded ION source.

Use this branch to run or explain the GPT sandbox carrier lane. The old 8K kernel is no longer the whole main instruction. It is now a branch-level source for sandbox behavior.

## First files to inspect

Use `05_INDEXES/HOT_FILE_INDEX.md` for exact paths. The usual hot route is:

1. `START_HERE.md`
2. `001_GPT_INSTRUCTIONS_PASTE_8K.md`
3. `003_PACKAGE_AUTHORITY_AND_LIMITS.md`
4. `ION/REPO_AUTHORITY.md`
5. `ION/02_architecture/ION_MOUNT_CONTRACT.md`
6. `ION/03_registry/gpt_sandbox_carrier_profile.yaml`
7. `ION/07_templates/carriers/GPT_SANDBOX_CARRIER_SESSION_PACKET.md`
8. `020_ACTIVE_STATE_INDEX/ACTIVE_STATE_SUMMARY.md`
9. `020_ACTIVE_STATE_INDEX/ACTIVE_DOMAIN_AGENT_INDEX.json`
10. `090_VALIDATION/V2_6_VALIDATION_REPORT.md`

## Use this branch for

- Custom GPT product behavior
- first-run sandbox mount
- `/guest-mode`, `/what is ION?`, sign-in/sign-up routing boundaries
- old 8K kernel interpretation
- package source priority
- sandbox-only vs connector lane distinction
- active state index and product starter data
- action schema references as docs, not automatic permission
- explaining what the mounted package is allowed to prove

## Do not use this branch for

- claiming live local hub status
- claiming that MCP, Gateway, GitHub, Codex, daemon, or extension are connected
- asking the user for secrets in chat
- overriding current user-provided bundles or task-specific files
- treating the old 8K instruction as the new global instruction

## Authority notes

- `START_HERE.md` is the mount route.
- `001_GPT_INSTRUCTIONS_PASTE_8K.md` is high-value behavior reference, but it was trying to do too much inside the 8K limit. The new main Instructions field should route here rather than duplicate it.
- `020_ACTIVE_STATE_INDEX/` is useful for package state, but it is not proof of current user project state unless the user mounted that package for the current session.
- `060_ACTION_SCHEMAS/` defines action surfaces and proof maps. Schemas are not permission.
- `070_BROWSER_EXTENSION_YAML_BRIDGE/` is bridge reference, not proof that the extension is installed or live.

## Branch output rule

When answering from this branch, distinguish:

```text
package mounted
sandbox route known
active package state found
connector reachable
local state read
external action performed
accepted state
```

Never collapse these into one claim.
