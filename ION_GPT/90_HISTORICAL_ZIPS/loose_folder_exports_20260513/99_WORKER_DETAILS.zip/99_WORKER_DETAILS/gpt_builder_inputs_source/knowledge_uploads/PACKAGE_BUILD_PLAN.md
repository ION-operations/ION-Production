# ION Custom GPT Upload Package Build Plan

Use this builder to create the focused zip packages listed in `UPLOAD_STRATEGY.md`.

## Plan only

```bash
PYTHONPATH=ION_Developement/ION/04_packages python3 -m kernel.ion_custom_gpt_upload_set_builder \
  --workspace-root . \
  --package all \
  --plan \
  --json
```

## Build all focused packages

```bash
PYTHONPATH=ION_Developement/ION/04_packages python3 -m kernel.ion_custom_gpt_upload_set_builder \
  --workspace-root . \
  --package all \
  --json
```

## Build one package

```bash
PYTHONPATH=ION_Developement/ION/04_packages python3 -m kernel.ion_custom_gpt_upload_set_builder \
  --workspace-root . \
  --package ion_development_core_source \
  --json
```

## Output

Packages are written to:

```text
ION_EXPORTS_LOCAL/custom_gpt_upload_set/
```

This folder is ignored by git.

## Safety behavior

The builder excludes `.git`, `.env*`, `ION_VAULT_LOCAL`, `quarentine`, virtualenvs, caches, node_modules, build outputs, raw logs, key/cert files, and generated local export packages.

Each package contains:

- `START_HERE.md`
- `SOURCE_POSTURE.md`
- `TREE_SNAPSHOT.txt`
- `PACKAGE_MANIFEST.json`
- `SHA256SUMS.json`

The builder flags whether each zip is within the 512 MB GPT file-size limit.
