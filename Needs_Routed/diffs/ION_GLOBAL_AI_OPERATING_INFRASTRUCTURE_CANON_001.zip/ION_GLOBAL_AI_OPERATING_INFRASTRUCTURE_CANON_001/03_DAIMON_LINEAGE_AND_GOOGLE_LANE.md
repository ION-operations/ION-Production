# 03 — dAimon Lineage and the Google Carrier Lane

dAimon is best understood as an early vertical slice of ION inside the Google/Gemini/Agent Builder ecosystem.

## dAimon role

```text
Gemini / Google Agent Builder / Google Cloud / MongoDB / external traces
→ governed outputs
→ proof and visibility
→ inheritance decisions
```

dAimon is not “separate from ION.” It is a sibling carrier domain that demonstrates how ION law projects into another cloud/model ecosystem.

## Current routing correction

dAimon Gemini bridge was moved off the ION MCP port:

```text
8765 = ION MCP preview
8777 = ION Action Gateway
8788 = ION local cockpit
8795 = dAimon Gemini bridge
```

This expresses the larger principle:

```text
External carrier lanes plug into ION.
They do not overwrite ION’s own control surfaces.
```

## Future dAimon integration

dAimon should emit:

```text
daimon_trace_event
daimon_receipt
google_agent_builder_status
gemini_bridge_status
mongodb_trace_reference
```

ION should ingest those into its event bus and mirror selected indexes into Supabase for cockpit visibility.

## Google lane roadmap

1. dAimon bridge status and receipts visible in ION cockpit.
2. dAimon traces mapped into ION receipt index.
3. Google Agent Builder outputs routed through ION settlement.
4. Gemini lane becomes a first-class ION carrier with mount receipts.
