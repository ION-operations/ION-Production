# Branch 08 — UI / JOC / OPUS Visual Canon

## Bound artifacts

- `_ui_canon.zip`
- AIM/ION UI-related docs when routed from Branch 06
- ION/JOC UI implementation sources when routed from Branch 02

## Purpose

This branch governs UI and visual design questions, especially JOC and OPUS visual editor work. It contains canonical UI requirements, architecture, visual editor rules, layout decisions, and the visual instrument-panel aesthetic.

## Use this branch for

- JOC UI work
- OPUS visual interface/editor work
- visual instrument control design
- matte-black command surfaces
- layout, panels, responsive behavior, and display targets
- “make it look/feel like JOC/OPUS/DXL” requests
- reviewing UI changes against visual canon

## First files to inspect

- `_ui_canon_bundle/JOC_UI_REQUIREMENTS.md`
- `_ui_canon_bundle/CANON_JOC_UI_ARCHITECTURE.md`
- `_ui_canon_bundle/OPUS1_JOC_MASTER_VISION.md`
- `_ui_canon_bundle/OPUS1_JOC_UI_DESIGN.md`
- `_ui_canon_bundle/OPUS_VISUAL_EDITOR_CANON.md`
- `_ui_canon_bundle/ULTIMATE_OPUS_VISUAL_INTERFACE_CANON.md`
- `_ui_canon_bundle/uishader.txt`

## UI authority rules

- Binding for UI/design work when the target is JOC/OPUS.
- Not binding for core ION workflow law.
- Do not inject UI style into non-UI answers unless the user asks.
- Preserve constraints like no emoji in UI, instrument-grade density, monochrome/matte surfaces, small typography, and deliberate layout.

## Branch output rule

For UI work, answer with:

```text
canon source used
design implication
implementation target
constraints preserved
candidate patch or next design packet
```
