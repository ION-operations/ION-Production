# 03 — RPC Functions And AI Operations

ION should let AI manage Supabase through typed operations, not by direct broad table access.

## First RPC lane

Functions:

```text
ion_ops.record_automation_event(...)
ion_ops.record_service_health_snapshot(...)
ion_ops.record_carrier_mount_receipt(...)
```

Each function should:

- check ION role claim
- normalize defaults
- force `accepted_state_claim = false` unless a later steward function allows otherwise
- default `settlement_required = true`
- insert append-only row
- return inserted ID and timestamp

## Function security

Use `security invoker` where possible. If `security definer` is necessary later, set `search_path` defensively and keep functions out of exposed schemas if the design requires that.

For v001, functions can remain in `ion_ops` only if access and exposed schema posture are known. If unsure, a future `ion_api` schema can hold exposed RPC wrappers and call internal tables.

## Why functions matter

They let the cockpit, ION MCP, Codex, dAimon, and future agents write safe operational evidence without holding unrestricted DB permissions.

## Function payload shape

### record_automation_event

```json
{
  "event_type": "patch_applied",
  "severity": "notice",
  "agent_tag": "GPT-001",
  "payload": {},
  "evidence_refs": [],
  "source_posture": {}
}
```

### record_service_health_snapshot

```json
{
  "service_name": "ion_mcp_preview",
  "status": "ready",
  "port": 8765,
  "health": {}
}
```

### record_carrier_mount_receipt

```json
{
  "agent_tag": "GPT-001",
  "carrier_type": "chatgpt_browser_mcp",
  "context_instance_id": "...",
  "authority": {},
  "source_posture": {}
}
```

## Future functions

- `record_drift_finding`
- `record_git_event`
- `create_settlement_candidate`
- `update_settlement_status`
- `record_daimon_trace`
- `record_slack_event`
- `record_github_event`
