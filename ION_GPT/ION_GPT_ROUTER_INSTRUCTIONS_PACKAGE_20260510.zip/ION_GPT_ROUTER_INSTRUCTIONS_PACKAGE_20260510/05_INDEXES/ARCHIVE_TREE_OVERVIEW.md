# Archive Tree Overview

This is a folder-level routing index. It is not a claim that every file is current authority. Use branch instructions before promoting any source into state.

## AIM-ION.zip

| Folder | Files | Zone | Top roles |
|---|---:|---|---|
| `AIM-ION/knowledge_architecture/applications` | 2287 | aim_knowledge_architecture | code:1654; other:162; documentation:155; schema_data:124; index:74; front_door:36 |
| `AIM-ION/knowledge_architecture/systems` | 1874 | aim_knowledge_architecture | documentation:1523; front_door:108; other:90; index:47; code:34; agent_carrier:25 |
| `AIM-ION/ide_orchestration/prototypes` | 1344 | aim_lineage | documentation:489; code:382; agent_carrier:273; validation_test:66; index:45; instruction_prompt:21 |
| `AIM-ION/.agent/comms` | 776 | aim_lineage | schema_data:468; agent_carrier:294; validation_test:7; template:3; protocol:2; manifest:1 |
| `AIM-ION/knowledge_architecture/AETHER_MEMORY` | 634 | aim_knowledge_architecture | documentation:533; validation_test:24; protocol:22; front_door:17; schema_data:15; index:8 |
| `AIM-ION/Testing/artifacts` | 517 | aim_lineage | documentation:334; agent_carrier:106; schema_data:30; validation_test:26; code:15; front_door:5 |
| `AIM-ION/packages/ide_chat_app` | 271 | aim_packages | code:191; documentation:21; other:19; agent_carrier:16; index:7; schema_data:5 |
| `AIM-ION/knowledge_architecture/AGENT_ONBOARDING` | 248 | aim_knowledge_architecture | agent_carrier:186; front_door:44; template:7; index:4; protocol:4; validation_test:3 |
| `AIM-ION/cursor-addon/ARCHIVE_COMPLETE` | 247 | aim_cursor_addon | documentation:217; code:6; index:5; validation_test:5; front_door:4; other:4 |
| `AIM-ION/.agent/sev` | 241 | aim_lineage | agent_carrier:228; front_door:3; authority:3; state:3; index:3; template:1 |
| `AIM-ION/knowledge_architecture/FLOATING_FILES_ORGANIZED` | 211 | aim_knowledge_architecture | documentation:168; code:13; validation_test:9; index:7; other:3; schema_data:3 |
| `AIM-ION/mcp_memory/index` | 178 | aim_lineage | schema_data:169; index:4; instruction_prompt:2; validation_test:2; state:1 |
| `AIM-ION/packages/joc` | 157 | aim_packages | code:117; documentation:15; agent_carrier:8; index:7; schema_data:6; other:2 |
| `AIM-ION/north_star_project/chapters` | 151 | aim_lineage | other:70; schema_data:38; documentation:35; authority:4; template:3; validation_test:1 |
| `AIM-ION/coordination/epic_standards_overhaul` | 143 | aim_lineage | documentation:109; agent_carrier:9; validation_test:7; template:5; front_door:5; index:4 |
| `AIM-ION/packages/apoe` | 122 | aim_packages | code:87; validation_test:30; front_door:2; index:1; schema_data:1; documentation:1 |
| `AIM-ION/cursor-addon/docs` | 115 | aim_cursor_addon | documentation:83; agent_carrier:11; validation_test:7; index:6; protocol:4; other:3 |
| `AIM-ION/scripts/ai_engine` | 103 | aim_lineage | code:49; agent_carrier:26; validation_test:10; schema_data:9; documentation:8; other:1 |
| `AIM-ION/packages/timeline_context_system` | 98 | aim_packages | code:69; instruction_prompt:23; front_door:3; validation_test:2; documentation:1 |
| `AIM-ION/archive/docs_status_2026_03_11` | 96 | aim_archive | documentation:80; agent_carrier:5; front_door:3; validation_test:2; template:2; state:2 |
| `AIM-ION/packages/plix` | 95 | aim_packages | code:40; documentation:25; validation_test:19; schema_data:4; index:4; front_door:2 |
| `AIM-ION/packages/cmc_service` | 82 | aim_packages | code:61; validation_test:19; other:1; front_door:1 |
| `AIM-ION/packages/joc-tournament` | 77 | aim_packages | code:39; documentation:13; schema_data:12; index:8; front_door:3; template:1 |
| `AIM-ION/archive/legacy_docs_2026_03_11` | 76 | aim_archive | documentation:76 |
| `AIM-ION/packages/hhni` | 71 | aim_packages | code:46; validation_test:17; index:8 |
| `AIM-ION/docs/Aether-OS` | 71 | aim_docs | documentation:64; agent_carrier:3; index:2; state:2 |
| `AIM-ION/canon/agents` | 69 | aim_canon | agent_carrier:59; state:5; protocol:2; template:1; schema_data:1; front_door:1 |
| `AIM-ION/packages/vif` | 67 | aim_packages | code:53; validation_test:13; front_door:1 |
| `AIM-ION/packages/quaternion_kernel` | 66 | aim_packages | documentation:50; code:12; validation_test:2; other:1; front_door:1 |
| `AIM-ION/archive/documentation_duplicates_2026_03_11` | 61 | aim_archive | documentation:57; index:2; protocol:1; validation_test:1 |
| `AIM-ION/cursor-addon/out` | 60 | aim_cursor_addon | code:23; other:23; validation_test:10; agent_carrier:2; state:2 |
| `AIM-ION/packages/jarvis_injector` | 55 | aim_packages | code:49; agent_carrier:2; state:1; template:1; front_door:1; other:1 |
| `AIM-ION/ide_orchestration/research` | 54 | aim_lineage | documentation:49; instruction_prompt:3; index:2 |
| `AIM-ION/packages/lucid_document_editor` | 53 | aim_packages | code:31; index:12; validation_test:4; schema_data:4; documentation:1; front_door:1 |
| `AIM-ION/packages/lucid_orchestrator` | 52 | aim_packages | code:35; validation_test:5; schema_data:4; front_door:3; documentation:3; index:1 |
| `AIM-ION/knowledge_architecture/validation` | 51 | aim_knowledge_architecture | validation_test:36; documentation:13; index:2 |
| `AIM-ION/packages/advanced_monaco_editor` | 41 | aim_packages | code:23; validation_test:14; schema_data:2; index:1; front_door:1 |
| `AIM-ION/audit/2026-02-19_aimos_restart_audit` | 41 | aim_lineage | documentation:22; schema_data:18; index:1 |
| `AIM-ION/forensics_backups/volumetric-clouds-engine_2026-01-13_132427` | 40 | aim_lineage | code:16; documentation:13; other:4; schema_data:4; index:2; front_door:1 |
| `AIM-ION/cursor-addon/src` | 40 | aim_cursor_addon | code:31; validation_test:6; agent_carrier:1; front_door:1; state:1 |

## ATLAS.zip

| Folder | Files | Zone | Top roles |
|---|---:|---|---|
| `ATLAS/systems/cobol` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/cloudflare-workers` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/clang` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/civo-kubernetes` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/cilium` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/digitalocean-doks` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/dietlibc` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/centos-linux` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/centos-stream` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/c-language` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/buildkit` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/azure-application-gateway` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/azure-aks` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/azure-front-door` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/azure-container-apps` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/aws-eks` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/aws-ecs` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/arm-cca` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/argo-cd` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/apache-mesos` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/apache-kafka` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/azure-aci` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/aws-elastic-load-balancing` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/android-bionic` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/anthropic-claude-code-agent-sdk` | 18 | atlas_system_package | agent_carrier:15; schema_data:3 |
| `ATLAS/systems/android-aosp` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/amd-sev` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/amazon-cloudfront` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/amazon-api-gateway` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/amd-rocm` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/amazon-s3` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/almalinux` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/alpine-linux` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/algol` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/akamai` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/ada-language` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/aim-os` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/9front` | 18 | atlas_system_package | documentation:15; schema_data:3 |
| `ATLAS/systems/_template` | 18 | atlas_system_package | template:15; schema_data:3 |
| `ATLAS/systems/edgio` | 18 | atlas_system_package | documentation:15; schema_data:3 |

## EXTENSION.zip

| Folder | Files | Zone | Top roles |
|---|---:|---|---|
| `ion_chatops_bridge/README.md` | 1 | extension_chatops_bridge | front_door:1 |
| `ion_chatops_bridge/dist/background.js` | 1 | extension_chatops_bridge | code:1 |
| `ion_chatops_bridge/dist/content.js` | 1 | extension_chatops_bridge | code:1 |
| `ion_chatops_bridge/examples/SEV_CHATOPS_SMOKE.yaml` | 1 | extension_chatops_bridge | schema_data:1 |
| `ion_chatops_bridge/icons/ion-chatops-icon-128.png` | 1 | extension_chatops_bridge | other:1 |
| `ion_chatops_bridge/icons/ion-chatops-icon-16.png` | 1 | extension_chatops_bridge | other:1 |
| `ion_chatops_bridge/icons/ion-chatops-icon-32.png` | 1 | extension_chatops_bridge | other:1 |
| `ion_chatops_bridge/icons/ion-chatops-icon-48.png` | 1 | extension_chatops_bridge | other:1 |
| `ion_chatops_bridge/manifest.json` | 1 | extension_chatops_bridge | manifest:1 |
| `ion_chatops_bridge/src/approval_ui.ts` | 1 | extension_chatops_bridge | code:1 |
| `ion_chatops_bridge/src/background.ts` | 1 | extension_chatops_bridge | code:1 |
| `ion_chatops_bridge/src/content.ts` | 1 | extension_chatops_bridge | code:1 |
| `ion_chatops_bridge/src/schema.ts` | 1 | extension_chatops_bridge | schema_data:1 |
| `ion_chatops_bridge/tests/live_smoke_parser_simulation.js` | 1 | extension_chatops_bridge | code:1 |

## ION FULL DEVELOPMENT.zip

| Folder | Files | Zone | Top roles |
|---|---:|---|---|
| `ION_CODEX FULL/ION/06_intelligence` | 4851 | ion_full_repo | agent_carrier:1985; state:588; documentation:579; schema_data:413; protocol:321; receipt:220 |
| `ION_CODEX FULL/ION/05_context` | 4350 | ion_full_repo | state:2829; documentation:802; instruction_prompt:341; schema_data:114; receipt:53; template:48 |
| `ION_CODEX FULL/ION_sandbox/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_AI_ASSISTANT_WORK_TEMPLATE_INSTANCE_EXERCISES_CANDIDATE_20260508T154333Z` | 3736 | ion_sandbox | template:2077; state:491; schema_data:372; protocol:289; receipt:158; front_door:106 |
| `ION_CODEX FULL/ION/02_architecture` | 292 | ion_full_repo | protocol:244; documentation:14; receipt:11; state:7; authority:5; index:3 |
| `ION_CODEX FULL/ION/04_packages` | 280 | ion_full_repo | code:215; agent_carrier:21; template:11; receipt:10; state:6; documentation:4 |
| `ION_CODEX FULL/ION/03_registry` | 228 | ion_full_repo | schema_data:182; documentation:18; receipt:10; manifest:5; front_door:4; state:4 |
| `ION_CODEX FULL/ION/tests` | 87 | ion_full_repo | validation_test:80; receipt:3; state:2; instruction_prompt:1; authority:1 |
| `ION_CODEX FULL/ION/00_BOOTSTRAP` | 80 | ion_full_repo | documentation:63; receipt:7; agent_carrier:3; state:2; authority:2; schema_data:1 |
| `ION_CODEX FULL/ION/07_templates` | 67 | ion_full_repo | template:59; front_door:4; receipt:3; index:1 |
| `ION_CODEX FULL/ION/docs` | 66 | ion_full_repo | documentation:51; agent_carrier:5; state:4; authority:2; front_door:1; template:1 |
| `ION_CODEX FULL/ION/09_integrations` | 52 | ion_full_repo | code:19; front_door:11; schema_data:7; template:6; other:5; manifest:2 |
| `ION_CODEX FULL/ION/08_ui` | 34 | ion_full_repo | code:31; agent_carrier:1; state:1; receipt:1 |
| `ION_CODEX FULL/ION/examples` | 19 | ion_full_repo | schema_data:16; other:2; receipt:1 |
| `ION_CODEX FULL/ION/06_artifacts` | 13 | ion_full_repo | agent_carrier:8; other:5 |
| `ION_CODEX FULL/ION/04_agents` | 13 | ion_full_repo | agent_carrier:8; protocol:4; schema_data:1 |
| `ION_CODEX FULL/.cursor/rules` | 13 | ion_full_repo | agent_carrier:6; other:6; authority:1 |
| `ION_CODEX FULL/.cursor/agents` | 9 | ion_full_repo | agent_carrier:9 |
| `ION_CODEX FULL/.cursor/commands` | 6 | ion_full_repo | documentation:6 |
| `ION_CODEX FULL/workpackets/ion_extension_work_packets` | 6 | ion_workpackets | documentation:4; agent_carrier:1; front_door:1 |
| `ION_CODEX FULL/ION/01_doctrine` | 5 | ion_full_repo | documentation:4; front_door:1 |
| `ION_CODEX FULL/.cursor/hooks` | 4 | ion_full_repo | code:2; agent_carrier:1; other:1 |
| `ION_CODEX FULL/.github/ISSUE_TEMPLATE` | 3 | ion_full_repo | template:3 |
| `ION_CODEX FULL/.cursor/skills` | 2 | ion_full_repo | documentation:1; agent_carrier:1 |
| `ION_CODEX FULL/ion-sandbox-gpt/ION` | 2 | ion_full_repo | state:2 |
| `ION_CODEX FULL/.codex/config.toml` | 1 | ion_full_repo | other:1 |
| `ION_CODEX FULL/.cursor/hooks.json` | 1 | ion_full_repo | schema_data:1 |
| `ION_CODEX FULL/.github/PULL_REQUEST_TEMPLATE.md` | 1 | ion_full_repo | template:1 |
| `ION_CODEX FULL/.codex/hooks` | 1 | ion_full_repo | code:1 |
| `ION_CODEX FULL/.vscode/launch.json` | 1 | ion_full_repo | schema_data:1 |
| `ION_CODEX FULL/.cursor/mcp.json` | 1 | ion_full_repo | schema_data:1 |
| `ION_CODEX FULL/.vscode/settings.json` | 1 | ion_full_repo | schema_data:1 |
| `ION_CODEX FULL/.vscode/tasks.json` | 1 | ion_full_repo | schema_data:1 |
| `ION_CODEX FULL/CONTRIBUTING.md` | 1 | ion_full_repo | documentation:1 |
| `ION_CODEX FULL/ION/README.md` | 1 | ion_full_repo | front_door:1 |
| `ION_CODEX FULL/ION/REPO_AUTHORITY.md` | 1 | ion_full_repo | authority:1 |
| `ION_CODEX FULL/.gitignore` | 1 | ion_full_repo | other:1 |
| `ION_CODEX FULL/.vscode/extensions.json` | 1 | ion_full_repo | schema_data:1 |
| `ION_CODEX FULL/ION_sandbox/README.md` | 1 | ion_sandbox | front_door:1 |
| `ION_CODEX FULL/ION_sandbox/ION_SANDBOX_INDEX_20260508T190626Z.json` | 1 | ion_sandbox | index:1 |
| `ION_CODEX FULL/assessment/ION_Workflow_Self_Assessment_v0_8.md` | 1 | ion_full_repo | documentation:1 |

## ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7.zip

| Folder | Files | Zone | Top roles |
|---|---:|---|---|
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_file_continuity_bridge_mvp/outputs` | 11 | agent_framework_research | schema_data:5; agent_carrier:3; receipt:1; validation_test:1; state:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_langgraph_packet_lifecycle/outputs` | 8 | agent_framework_research | schema_data:5; manifest:1; agent_carrier:1; receipt:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_langgraph_packet_lifecycle/schemas` | 6 | agent_framework_research | agent_carrier:4; receipt:1; manifest:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_demo_packet_runner/schemas` | 6 | agent_framework_research | agent_carrier:4; receipt:1; manifest:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_demo_packet_runner/runner` | 5 | agent_framework_research | agent_carrier:4; receipt:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_langgraph_packet_lifecycle/runner` | 5 | agent_framework_research | agent_carrier:4; receipt:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_file_continuity_bridge_mvp/sample_inputs` | 5 | agent_framework_research | agent_carrier:2; schema_data:1; receipt:1; manifest:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_continuity_bridge_demo/outputs` | 4 | agent_framework_research | schema_data:2; receipt:1; agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_demo_packet_runner/outputs` | 4 | agent_framework_research | schema_data:2; receipt:1; validation_test:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_demo_packet_runner/examples` | 3 | agent_framework_research | schema_data:2; manifest:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_hitl_settlement_gate/outputs` | 3 | agent_framework_research | schema_data:2; receipt:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_adversarial_continuity_law_test/outputs` | 3 | agent_framework_research | agent_carrier:2; validation_test:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_langgraph_packet_lifecycle/examples` | 3 | agent_framework_research | schema_data:2; manifest:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/AFR_006_executive_brief_v0_7.md` | 1 | agent_framework_research | agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/AFR_006_public_comparison_draft_v0_7.md` | 1 | agent_framework_research | agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/AFR_007_integration_architecture_stack_v0_8.md` | 1 | agent_framework_research | agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/AFR_005_ion_vs_framework_archetype_map_report_v0_6.md` | 1 | agent_framework_research | agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/AFR_007_integration_candidate_map_report_v0_8.md` | 1 | agent_framework_research | agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/AFR_008_prototype_design_report_v0_9.md` | 1 | agent_framework_research | agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/AFR_008_prototype_design_candidate_v0_8.md` | 1 | agent_framework_research | agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/AFR_016_file_based_continuity_bridge_mvp_hardening_report_v1_7.md` | 1 | agent_framework_research | agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/README.md` | 1 | agent_framework_research | front_door:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/adversarial_continuity_law_test_matrix_v1_5.csv` | 1 | agent_framework_research | validation_test:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/archetype_summary_by_bucket_v0_6.csv` | 1 | agent_framework_research | agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/archetype_summary_by_bucket_v0_6.json` | 1 | agent_framework_research | schema_data:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/archetype_taxonomy_v0_6.json` | 1 | agent_framework_research | schema_data:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/archetype_taxonomy_v0_6.md` | 1 | agent_framework_research | agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/AFR_009_langgraph_vs_temporal_wrapper_report_v1_0.md` | 1 | agent_framework_research | agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/AFR_009_next_packet_candidate_v0_9.md` | 1 | agent_framework_research | agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/AFR_010_langgraph_first_packet_lifecycle_prototype_report_v1_1.md` | 1 | agent_framework_research | agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/AFR_010_next_packet_candidate_v1_0.md` | 1 | agent_framework_research | agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/AFR_011_reflective_assessment_and_field_fit_v1_2.md` | 1 | agent_framework_research | agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/AFR_012_continuity_pressure_doctrine_update_v1_3.md` | 1 | agent_framework_research | agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/AFR_013_branch_fission_continuity_market_and_settlement_gate_report_v1_4.md` | 1 | agent_framework_research | agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/AFR_014_adversarial_memory_projects_vs_ion_continuity_law_v1_5.md` | 1 | agent_framework_research | agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/AFR_015_continuity_product_thesis_and_prototype_bridge_v1_6.md` | 1 | agent_framework_research | agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/comparison_rubric.json` | 1 | agent_framework_research | schema_data:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/claim_safety_checklist_AFR_006_v0_7.md` | 1 | agent_framework_research | agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/candidate_additions_triage_v0_3.md` | 1 | agent_framework_research | agent_carrier:1 |
| `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/candidate_additions_triage_v0_3.json` | 1 | agent_framework_research | schema_data:1 |

## ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_7_CANDIDATE_20260509T224136Z.zip

| Folder | Files | Zone | Top roles |
|---|---:|---|---|
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context` | 1590 | custom_gpt_embedded_ion_source | agent_carrier:844; state:388; schema_data:136; receipt:57; template:48; front_door:36 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/06_intelligence` | 925 | custom_gpt_embedded_ion_source | agent_carrier:622; state:76; receipt:46; template:41; front_door:40; protocol:30 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/02_architecture` | 285 | custom_gpt_embedded_ion_source | protocol:239; agent_carrier:12; receipt:11; state:7; authority:5; schema_data:3 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/04_packages` | 256 | custom_gpt_embedded_ion_source | agent_carrier:217; template:11; receipt:10; state:6; authority:4; front_door:2 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/03_registry` | 220 | custom_gpt_embedded_ion_source | schema_data:174; agent_carrier:18; receipt:10; manifest:5; front_door:4; state:4 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/00_BOOTSTRAP` | 80 | custom_gpt_embedded_ion_source | agent_carrier:66; receipt:7; state:2; authority:2; protocol:1; schema_data:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/tests` | 75 | custom_gpt_embedded_ion_source | validation_test:68; receipt:3; state:2; authority:1; instruction_prompt:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/docs` | 70 | custom_gpt_embedded_ion_source | agent_carrier:58; state:4; authority:2; schema_data:1; validation_test:1; manifest:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/07_templates` | 67 | custom_gpt_embedded_ion_source | template:59; front_door:4; receipt:3; index:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/product/package_guides` | 43 | custom_gpt_product_adapter | agent_carrier:18; schema_data:8; receipt:3; manifest:3; front_door:3; state:3 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/08_ui` | 34 | custom_gpt_embedded_ion_source | agent_carrier:32; state:1; receipt:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/product/starter_data` | 22 | custom_gpt_product_adapter | agent_carrier:6; schema_data:5; front_door:4; state:3; manifest:2; receipt:2 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/examples` | 19 | custom_gpt_embedded_ion_source | schema_data:16; agent_carrier:2; receipt:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/030_CUSTOM_GPT_ADAPTER/v2_5_saved_files` | 18 | custom_gpt_product_adapter | agent_carrier:12; receipt:2; front_door:2; manifest:1; instruction_prompt:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/product/custom_gpt_adapter` | 14 | custom_gpt_product_adapter | agent_carrier:5; protocol:2; instruction_prompt:2; receipt:1; template:1; manifest:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/product/data_schema` | 14 | custom_gpt_product_adapter | schema_data:7; manifest:2; front_door:2; receipt:1; state:1; agent_carrier:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/04_agents` | 13 | custom_gpt_embedded_ion_source | agent_carrier:8; protocol:4; schema_data:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/09_integrations` | 7 | custom_gpt_embedded_ion_source | front_door:4; schema_data:2; manifest:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/01_doctrine` | 5 | custom_gpt_embedded_ion_source | agent_carrier:4; front_door:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/050_STARTER_DATA/INBOX` | 2 | custom_gpt_root | front_door:1; agent_carrier:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/050_STARTER_DATA/OUTBOX` | 2 | custom_gpt_root | front_door:1; agent_carrier:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/050_STARTER_DATA/DECISIONS` | 2 | custom_gpt_root | schema_data:1; agent_carrier:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/050_STARTER_DATA/ARTIFACTS` | 2 | custom_gpt_root | manifest:1; agent_carrier:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/050_STARTER_DATA/STATE` | 2 | custom_gpt_root | state:2 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/050_STARTER_DATA/PACKETS` | 2 | custom_gpt_root | schema_data:1; agent_carrier:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/050_STARTER_DATA/ARCHIVE` | 2 | custom_gpt_root | front_door:1; agent_carrier:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/050_STARTER_DATA/RECEIPTS` | 2 | custom_gpt_root | receipt:2 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/product/source_inputs` | 2 | custom_gpt_product_adapter | state:2 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/060_ACTION_SCHEMAS/mcp_json_rpc` | 2 | custom_gpt_action_schema | schema_data:1; front_door:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/060_ACTION_SCHEMAS/action_gateway` | 2 | custom_gpt_action_schema | schema_data:1; front_door:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/004_V2_6_DELTA_NOTE.md` | 1 | custom_gpt_root | agent_carrier:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/006_V2_6_3_PROTOCOL_BREACH_REPAIR_NOTE.md` | 1 | custom_gpt_root | protocol:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/007_V2_6_4_8K_INSTRUCTIONS_NOTE.md` | 1 | custom_gpt_root | instruction_prompt:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/005_V2_6_2_SANDBOX_FIRST_ACTION_GATE_NOTE.md` | 1 | custom_gpt_root | agent_carrier:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/001_GPT_INSTRUCTIONS_PASTE.md` | 1 | custom_gpt_root | instruction_prompt:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/000_READ_FIRST_MOUNT_ORDER.md` | 1 | custom_gpt_root | agent_carrier:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/002_KNOWLEDGE_UPLOAD_MANIFEST.json` | 1 | custom_gpt_root | manifest:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/003_PACKAGE_AUTHORITY_AND_LIMITS.md` | 1 | custom_gpt_root | authority:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/004_V2_6_1_GUEST_MODE_TOOL_GATE_NOTE.md` | 1 | custom_gpt_root | agent_carrier:1 |
| `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/001_GPT_INSTRUCTIONS_PASTE_8K.md` | 1 | custom_gpt_root | instruction_prompt:1 |

## _ui_canon.zip

| Folder | Files | Zone | Top roles |
|---|---:|---|---|
| `_ui_canon_bundle/CANON_JOC_UI_ARCHITECTURE.md` | 1 | ui_joc_opus_canon | documentation:1 |
| `_ui_canon_bundle/JOC_UI_REQUIREMENTS.md` | 1 | ui_joc_opus_canon | documentation:1 |
| `_ui_canon_bundle/OPUS1_JOC_ARCHITECTURE.md` | 1 | ui_joc_opus_canon | documentation:1 |
| `_ui_canon_bundle/OPUS1_JOC_COMPUTE_AND_IDE_LAYOUT.md` | 1 | ui_joc_opus_canon | documentation:1 |
| `_ui_canon_bundle/OPUS1_JOC_GOALS_AND_ROADMAP.md` | 1 | ui_joc_opus_canon | documentation:1 |
| `_ui_canon_bundle/OPUS1_JOC_MASTER_VISION.md` | 1 | ui_joc_opus_canon | documentation:1 |
| `_ui_canon_bundle/OPUS1_JOC_UI_DESIGN.md` | 1 | ui_joc_opus_canon | documentation:1 |
| `_ui_canon_bundle/OPUS_VISUAL_CANON_CONTEXT_PROMPT.md` | 1 | ui_joc_opus_canon | instruction_prompt:1 |
| `_ui_canon_bundle/OPUS_VISUAL_EDITOR_ARCHITECTURE.md` | 1 | ui_joc_opus_canon | documentation:1 |
| `_ui_canon_bundle/OPUS_VISUAL_EDITOR_CANON.md` | 1 | ui_joc_opus_canon | documentation:1 |
| `_ui_canon_bundle/OPUS_VISUAL_SETTINGS_CANON.md` | 1 | ui_joc_opus_canon | documentation:1 |
| `_ui_canon_bundle/ULTIMATE_OPUS_VISUAL_INTERFACE_CANON.md` | 1 | ui_joc_opus_canon | documentation:1 |
| `_ui_canon_bundle/ui_evolution_plan.md` | 1 | ui_joc_opus_canon | documentation:1 |
| `_ui_canon_bundle/uishader.txt` | 1 | ui_joc_opus_canon | documentation:1 |

## dAimon3.zip

| Folder | Files | Zone | Top roles |
|---|---:|---|---|
| `dAimon/.env` | 1 | daimon | other:1 |
| `dAimon/.env.example` | 1 | daimon | other:1 |
| `dAimon/.gcloudignore` | 1 | daimon | other:1 |
| `dAimon/.gitignore` | 1 | daimon | other:1 |
| `dAimon/LICENSE` | 1 | daimon | other:1 |
| `dAimon/README.md` | 1 | daimon | front_door:1 |
| `dAimon/agent_builder/agent_tool_manifest.yaml` | 1 | daimon | manifest:1 |
| `dAimon/agent_builder/openapi_tools_contract.json` | 1 | daimon | schema_data:1 |
| `dAimon/agent_builder/system_prompt.md` | 1 | daimon | instruction_prompt:1 |
| `dAimon/capability_graph/capability_graph_seed.json` | 1 | daimon | schema_data:1 |
| `dAimon/capability_graph/domain_agent_registry_seed.json` | 1 | daimon | schema_data:1 |
| `dAimon/dashboard/index.html` | 1 | daimon | index:1 |
| `dAimon/dashboard/styles.css` | 1 | daimon | code:1 |
| `dAimon/docs/agent_builder_mcp_trace_capture.md` | 1 | daimon | agent_carrier:1 |
| `dAimon/docs/architecture.md` | 1 | daimon | documentation:1 |
| `dAimon/docs/contest_vertical_slice_plan.md` | 1 | daimon | validation_test:1 |
| `dAimon/docs/credential_handoff.md` | 1 | daimon | documentation:1 |
| `dAimon/docs/custom_gpt_expansion_plan.md` | 1 | custom_gpt_root | documentation:1 |
| `dAimon/docs/demo_script.md` | 1 | daimon | documentation:1 |
| `dAimon/docs/full_orchestration_plan.md` | 1 | daimon | documentation:1 |
| `dAimon/docs/github_actions_validate_template.yml` | 1 | daimon | template:1 |
| `dAimon/docs/self_demonstrating_video_agent.md` | 1 | daimon | agent_carrier:1 |
| `dAimon/docs/ui_canon_product_plan.md` | 1 | daimon | documentation:1 |
| `dAimon/ion_kernel/Dockerfile` | 1 | daimon | other:1 |
| `dAimon/ion_kernel/api.py` | 1 | daimon | code:1 |
| `dAimon/ion_kernel/bridge_core.py` | 1 | daimon | code:1 |
| `dAimon/ion_kernel/capability_router.py` | 1 | daimon | code:1 |
| `dAimon/ion_kernel/inheritance.py` | 1 | daimon | code:1 |
| `dAimon/ion_kernel/mcp_trace.py` | 1 | daimon | code:1 |
| `dAimon/ion_kernel/mongodb_adapter.py` | 1 | daimon | code:1 |
| `dAimon/ion_kernel/persistence.py` | 1 | daimon | code:1 |
| `dAimon/ion_kernel/receipt_chain.py` | 1 | daimon | receipt:1 |
| `dAimon/ion_kernel/requirements.txt` | 1 | daimon | documentation:1 |
| `dAimon/ion_kernel/schemas.py` | 1 | daimon | schema_data:1 |
| `dAimon/ion_kernel/settlement_queue.py` | 1 | daimon | code:1 |
| `dAimon/mcp/mongodb_atlas_schema_contract_v0_8.json` | 1 | daimon | schema_data:1 |
| `dAimon/mcp/mongodb_mcp_visibility_contract.json` | 1 | daimon | schema_data:1 |
| `dAimon/orchestration/build_roadmap.json` | 1 | daimon | schema_data:1 |
| `dAimon/orchestration/domain_registry.json` | 1 | daimon | schema_data:1 |
| `dAimon/orchestration/management_cadence.json` | 1 | daimon | schema_data:1 |

## dAimon_ION3.zip

| Folder | Files | Zone | Top roles |
|---|---:|---|---|
| `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/repo_scaffold` | 54 | daimon | agent_carrier:30; schema_data:17; receipt:2; front_door:1; manifest:1; instruction_prompt:1 |
| `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/evidence` | 8 | daimon | agent_carrier:4; front_door:2; instruction_prompt:1; index:1 |
| `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/source_audit` | 8 | daimon | schema_data:3; agent_carrier:2; state:1; manifest:1; validation_test:1 |
| `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/handoff` | 4 | daimon | agent_carrier:3; instruction_prompt:1 |
| `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/validation` | 3 | daimon | validation_test:3 |
| `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/mcp_trace` | 2 | daimon | schema_data:1; agent_carrier:1 |
| `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/RAH_038_capability_graph_dashboard_trace_spec_v1_0.md` | 1 | daimon | agent_carrier:1 |
| `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/MANIFEST.json` | 1 | daimon | manifest:1 |
| `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/FILE_MANIFEST_SHA256.json` | 1 | daimon | manifest:1 |
| `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/CURRENT_STATE.json` | 1 | daimon | state:1 |
| `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/RAH_037_route_endpoint_and_dashboard_trace_report_v1_0.md` | 1 | daimon | agent_carrier:1 |
| `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/README.md` | 1 | daimon | front_door:1 |
| `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/RAH_039_functionality_only_guardrail_v1_0.md` | 1 | daimon | agent_carrier:1 |
| `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/brand` | 1 | daimon | agent_carrier:1 |
| `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/RAH_040_next_packet_mongodb_mcp_trace_harness_v1_0.md` | 1 | daimon | agent_carrier:1 |
| `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/RAH_041_source_evidence_register_v1_0.csv` | 1 | daimon | agent_carrier:1 |
| `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/packets` | 1 | daimon | agent_carrier:1 |
| `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/receipt_candidate_RAH_011A_v1_1_full.json` | 1 | daimon | receipt:1 |
| `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/receipt_candidate_RAH_010_v1_0.json` | 1 | daimon | receipt:1 |
| `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/patches` | 1 | daimon | agent_carrier:1 |
| `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/validation_manifest_v1_0.json` | 1 | daimon | manifest:1 |

