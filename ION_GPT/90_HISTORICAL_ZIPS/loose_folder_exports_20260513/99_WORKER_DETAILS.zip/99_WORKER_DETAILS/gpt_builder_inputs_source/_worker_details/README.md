# Worker Details

This folder is for Codex/AI workers and release auditors.

Human-facing GPT Builder folders are:

```text
instructions/
actions/
packages_to_upload/
```

Do not make Braden use files from this folder unless a specific recovery or release packet says so.
