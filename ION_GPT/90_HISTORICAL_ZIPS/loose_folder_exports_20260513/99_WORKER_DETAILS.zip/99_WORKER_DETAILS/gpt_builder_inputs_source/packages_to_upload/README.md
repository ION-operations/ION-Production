# Packages to Upload

Use this folder to understand which zip files to upload to Custom GPT Knowledge.

The actual generated zip files are local-only and live in:

```text
ION_EXPORTS_LOCAL/
```

Start with:

```text
UPLOAD_STRATEGY.md
```

Older package plans or replaced manifests go in:

```text
historical/
```
