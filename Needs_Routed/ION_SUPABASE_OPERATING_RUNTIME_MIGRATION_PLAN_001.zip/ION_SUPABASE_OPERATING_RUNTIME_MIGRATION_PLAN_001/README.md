# ION Supabase Operating Runtime Migration Plan 001

Status: candidate architecture / migration plan.

This package plans how Supabase should become ION's first serious realtime operational data-plane adapter without becoming ION's source of truth.

Core split:

- Git / local repo: source truth.
- ION files, receipts, packets, branch capsules, settlement: continuity and state truth.
- Supabase: queryable realtime operational mirror and cockpit backend.
- Codex CLI/App: local implementation engine and carrier.
- ION MCP / Actions: bounded live control surface.
- dAimon / MongoDB / Google: Google/Gemini carrier lane and lineage trace substrate.
- Slack/GitHub/GitLab/Drive: app carriers and user-world integration surfaces.

This package is designed to be used by GPT-001, Sev/GPT PRO, Codex CLI, and future ION agents.
