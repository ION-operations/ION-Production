# ATLAS Expansion Backlog for ION

## Priority packages to add

### 1. `openai-codex-cli-app`

Purpose: Codex CLI/App as local execution carrier, sessions, memory, hooks, subagents, MCP, app server.

### 2. `chatgpt-apps-and-connectors`

Purpose: ChatGPT apps, sync apps, MCP apps, write actions, approval model.

### 3. `chatgpt-google-drive-sync`

Purpose: Drive as GPT context mirror/visibility surface.

### 4. `chatgpt-slack-app`

Purpose: Slack as AI/human comms and Workspace Agent carrier.

### 5. `supabase-platform`

Purpose: Supabase Postgres/Auth/Realtime/Storage/Edge Functions as operating data plane.

### 6. `supabase-mcp-server`

Purpose: Supabase MCP as developer tool and optional ChatGPT app carrier.

### 7. `github-chatgpt-app`

Purpose: GitHub source reference / review carrier.

### 8. `gitlab-devops-carrier`

Purpose: GitLab as source/CI/issues/review carrier.

### 9. `ion-intelligent-operating-network`

Purpose: ION itself as a system package, documented with ATLAS evidence discipline.

### 10. `daimon-google-agent-lane`

Purpose: dAimon/Gemini/Google Cloud/MongoDB lineage and ION integration.

### 11. `ion-browser-extension-carrier`

Purpose: browser extension as local relay/cockpit/approval surface.

### 12. `ion-mcp-action-gateway`

Purpose: ION MCP/Action Gateway as bounded control surface.

## Package quality bar

Every new ATLAS package should include:
- identity/scope
- architecture
- components
- namespace/memory/process model
- storage/network/IPC
- security/permissions
- extension/tooling
- build/deploy/update
- operator surface
- observability
- lineage
- relations
- evidence ledger
- documented vs inferred split
- sources
- tags
- relations JSON

Do not create marketing summaries. Create evidence-disciplined packages.
