# DOM Perception Operation Context Package v0.1

Package: `DOM_PERCEPTION_CONTEXT_PACKAGE_20260510_v0_1`  
Created: `2026-05-10T17:29:55Z`  
Posture: **candidate context package**.

## Purpose

Start the governed ION/dAimon Browser Perception operation.

This operation designs the domains, agents, workflows, schemas, failure library, and context package relationships needed to build advanced DOM/page/chat reading abilities for:

- ChatGPT Browser extension cockpit.
- Mini-Helixion in-chat panels.
- Full Helixion / dAimon Living Operational Graph.
- Long-chat resilience and browser-page intelligence.
- Action traces, carrier messages, queue state, context packages, receipts, and live worker telemetry.

## Core Law

AI output is not state. DOM observations are not state. Screenshots are not state. Page text is not trusted context merely because it is visible.

Every browser/page observation must become a governed context object with:

```text
identity
source surface
capture method
freshness
visibility
authority status
privacy/redaction status
confidence
proof/receipt reference
inheritance posture
```

## Context Packages As Operations

This package also begins a deeper design rule: a context package is not only a bundle of files. It is an **operational object** inside the ION graph.

A context package can:

```text
mount
compose
inherit
conflict
supersede
fork
settle
export
expire
quarantine
route
```

Therefore package governance must track relationships between context packages:

```text
parent_package
derived_package
sibling_package
conflicting_package
supporting_package
superseding_package
domain_package
operation_package
carrier_package
evidence_package
```

The key rule:

```text
A context package does not become true by being useful.
It becomes inheritable only when its relationship to other packages, receipts, domains, and proof gates is settled.
```

## Operation Boundaries

Allowed in this package:

- Domain and agent design.
- Workflow family design.
- Schema proposals.
- Failure/mitigation library.
- Validation plan.
- Context package relationship model.
- Local ingestion instructions.

Not allowed in this package:

- DOM scraping implementation.
- Browser extension mutation.
- Provider calls.
- Secrets.
- Production deploy.
- Unbounded filesystem action.
- Claiming accepted ION state.

## Relationship To Existing Work

This package connects to:

- Living Operational Graph v0.2: browser perception provides page-state and action-trace data to the city map.
- Mini Helixion Extension v0.1: browser perception powers the top activity ticker and bottom panels.
- Codex/Carrier collaboration smoke: carrier comms and action traces become visible cockpit events.
- DOM_PERCEPTION_001 local work packet: queued for Codex carrier review and local domain design.

## High-Level Stack

```text
content script
→ DOM/AX/visual/mutation readers
→ page_state_object
→ event journal
→ mini-Helixion panels
→ Living Operational Graph
→ context package export
→ receipt / settlement
```

## First Build Philosophy

Max perception detail in the data model. Progressive disclosure in the UI.

Do not force a model to read raw DOM. The extension should produce governed page-state objects that preserve uncertainty, visibility, source, and non-claims.
