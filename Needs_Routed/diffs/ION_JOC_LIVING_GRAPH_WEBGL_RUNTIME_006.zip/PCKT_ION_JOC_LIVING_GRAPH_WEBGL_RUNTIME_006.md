# PCKT-ION-JOC-LIVING-GRAPH-WEBGL-RUNTIME-006

## Status

Candidate UI/JOC evolution packet. This packet is not accepted ION state and does not claim production deployment, Git push, live telemetry, live Action/MCP mutation, or queue-worker activity.

## Objective

Add the first dependency-free canvas/WebGL runtime layer for the ION Living Operational Graph cockpit, preserving the 005 SVG/2.5D territory fallback and keeping the JOC browser-proof harness active.

## Patch dependency

Apply after packets 001-005:

```bash
git apply ion_joc_living_graph_view_model_panel_001.diff
git apply ion_joc_living_graph_source_mount_visual_proof_002.diff
git apply ion_joc_living_graph_browser_proof_interaction_003.diff
git apply ion_joc_living_graph_browser_capture_004.diff
git apply ion_joc_living_graph_territory_scene_005.diff
git apply ion_joc_living_graph_webgl_runtime_006.diff
```

## Files changed

```text
ION/04_packages/kernel/ion_living_graph_webgl_runtime.py
ION/04_packages/kernel/ion_living_graph_view_model.py
ION/04_packages/kernel/ion_living_graph_visual_proof.py
ION/04_packages/kernel/ion_living_graph_browser_capture.py
ION/08_ui/joc_cockpit_shell/LivingGraphWorkbenchPanel.tsx
ION/08_ui/joc_cockpit_shell/ionRuntimeCockpitTypes.ts
ION/08_ui/joc_cockpit_shell/ion-runtime-cockpit.css
ION/tests/test_kernel_ion_living_graph_view_model.py
```

Patch stat:

```text
.../kernel/ion_living_graph_browser_capture.py     |  12 +
 .../kernel/ion_living_graph_view_model.py          |   8 +
 .../kernel/ion_living_graph_visual_proof.py        |   4 +
 .../kernel/ion_living_graph_webgl_runtime.py       | 281 +++++++++++++++++++++
 .../LivingGraphWorkbenchPanel.tsx                  | 239 +++++++++++++++++-
 .../joc_cockpit_shell/ion-runtime-cockpit.css      |  50 +++-
 .../joc_cockpit_shell/ionRuntimeCockpitTypes.ts    |  43 ++++
 .../test_kernel_ion_living_graph_view_model.py     |  28 ++
 8 files changed, 662 insertions(+), 3 deletions(-)
```

## What 006 adds

- New `ion_living_graph_webgl_runtime.py` projection module.
- `webgl_scene` added to the living graph view model.
- Runtime buffers for platform triangles, road lines, structure points, and traffic beacon points.
- A dependency-free browser canvas runtime in the JOC Graph route.
- WebGL-first rendering path with honest 2D canvas fallback when the browser environment disables WebGL.
- Browser proof gates for canvas runtime presence, runtime primitive rendering, SVG fallback preservation, shell zones, no-monolith behavior, keyboard focus, and selected-node interaction.
- Static proof markers for `graph-webgl-canvas` and `graph-webgl-runtime-badge`.
- Regression tests for webgl runtime projection and degraded empty-scene behavior.

## Model proof summary

```json
{
  "kpis": {
    "browser_proof_fixture_count": 11,
    "command_count": 6,
    "district_count": 8,
    "domain_count": 8,
    "edge_count": 72,
    "event_count": 66,
    "focus_lens_count": 5,
    "live_telemetry_connected": false,
    "node_count": 64,
    "proof_required_route_count": 48,
    "risk_node_count": 1,
    "selected_relationship_count": 10,
    "territory_road_count": 72,
    "territory_structure_count": 64,
    "territory_traffic_beacon_count": 66,
    "timeline_track_count": 6,
    "visible_edge_count": 72,
    "visible_node_count": 64,
    "webgl_runtime_draw_call_count": 4,
    "webgl_runtime_primitive_count": 514
  },
  "proof_gates": {
    "bundle_parses": true,
    "bundle_present": true,
    "honesty_badges_required": true,
    "layout_parses": true,
    "layout_present": true,
    "no_live_label_without_adapter": true,
    "references_resolve": true,
    "required_zones_present": true,
    "territory_beacons_project_all_events": true,
    "territory_roads_project_all_edges": true,
    "territory_scene_ready": true,
    "territory_structures_project_all_nodes": true,
    "visible_edges_project_all_edges": true,
    "visible_nodes_project_all_nodes": true,
    "webgl_runtime_ready": true,
    "webgl_structures_project_all_structures": true,
    "webgl_svg_fallback_preserved": true
  },
  "source_package_id": "ION_UI_DOMAIN_CONTEXT_PACKAGE_v0_4_SCHEMA_REPAIR",
  "status": "ready",
  "webgl_scene_metrics": {
    "draw_call_count": 4,
    "live_telemetry_connected": false,
    "platform_vertex_count": 96,
    "road_vertex_count": 288,
    "structure_point_count": 64,
    "svg_fallback_preserved": true,
    "total_runtime_primitives": 514,
    "traffic_point_count": 66
  },
  "webgl_scene_status": "candidate_webgl_runtime_ready"
}
```

## Browser proof summary

```json
{
  "capture_status": "candidate_browser_capture_pass",
  "console_tail": [],
  "gates": {
    "canvas_runtime_has_primitives": true,
    "canvas_runtime_rendered": true,
    "full_graph_nodes_rendered": true,
    "graph_viewport_present": true,
    "keyboard_node_selection": true,
    "keyboard_search_focus": true,
    "no_body_horizontal_monolith": true,
    "no_body_vertical_monolith": true,
    "no_page_errors": true,
    "required_fixtures_present": true,
    "required_zones_present": true,
    "right_inspector_present": true,
    "svg_fallback_preserved": true,
    "territory_beacons_rendered": true,
    "territory_roads_rendered": true,
    "territory_stage_present": true,
    "territory_structures_rendered": true,
    "timeline_events_rendered": true,
    "webgl_canvas_present": true
  },
  "page_errors": [],
  "status": "candidate_browser_capture_pass",
  "webgl_metrics": {
    "webgl_canvas_count": 1,
    "webgl_draw_call_count": 4,
    "webgl_mode": "dependency_free_webgl_canvas_with_svg_fallback",
    "webgl_primitive_count": 514,
    "webgl_render_status": "candidate_canvas_fallback_rendered",
    "webgl_status": "candidate_webgl_runtime_ready"
  }
}
```

Important browser-capture detail: the sandbox Chromium configuration used for stable capture disables WebGL, so the runtime rendered through the new 2D canvas fallback. The model and UI still include the WebGL path; this packet does not claim that WebGL itself was rendered in this sandbox browser pass.

## Validation commands

```bash
python3 -m py_compile \
  ION/04_packages/kernel/ion_living_graph_webgl_runtime.py \
  ION/04_packages/kernel/ion_living_graph_view_model.py \
  ION/04_packages/kernel/ion_living_graph_visual_proof.py \
  ION/04_packages/kernel/ion_living_graph_browser_capture.py

PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH=ION/04_packages \
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 \
python3 -m pytest -q \
  ION/tests/test_kernel_ion_living_graph_view_model.py \
  ION/tests/test_kernel_ion_cockpit_view_model.py \
  ION/tests/test_kernel_ion_local_cockpit_app.py

cd ION/08_ui/joc_cockpit_shell
node node_modules/vite/bin/vite.js build

PYTHONPATH=ION/04_packages \
python3 -m kernel.ion_living_graph_view_model --root . --write

PYTHONPATH=ION/04_packages \
python3 -m kernel.ion_living_graph_visual_proof --root . --write

PYTHONPATH=ION/04_packages \
python3 -m kernel.ion_living_graph_browser_capture --root . --write --no-build --json
```

Validation result:

```text
py_compile: passed
targeted pytest: 20 passed
direct Vite build: passed
view model write: ready
static visual proof: candidate_visual_static_pass
browser capture: candidate_browser_capture_pass
```

## Known caveats

- This packet does not add `three` or `@react-three/fiber` dependencies.
- The browser screenshot pass rendered the canvas fallback path because this sandbox's stable Chromium launch profile disables WebGL.
- `npm run build` may still require executable-bit repair after zip extraction; direct Vite build was used after chmodding zip-restored binaries, as in earlier packets.
- Earlier non-patch `tsc --noEmit` issues remain outside this packet.

## Non-claims

- no accepted UI state
- no production deployment
- no Git push
- no live telemetry claim
- no live Action/MCP mutation
- no queue workers
- no accepted settlement
- no Three/R3F dependency runtime yet

## Next recommended packet

`PCKT-ION-JOC-LIVING-GRAPH-R3F-ADAPTER-007`

Scope:
- introduce a real Three/R3F adapter only if dependency policy and package path are approved;
- preserve the 006 canvas runtime and 005 SVG fallback;
- prove WebGL/R3F or explicitly classify environment limitations;
- keep JOC shell/no-monolith/browser proof gates mandatory.
