# Settlement Batches v2

generated_at: 2026-05-10T23:43:38.236352-04:00

These batches convert content-proof registries into reviewable settlement work. They do not accept state by themselves.

## B00 — Root and folder proof

**Scope:** `CONTENT_PROOF_MANIFEST.json, LOCAL_CONTENT_PROOF_REPORT.md`

**Goal:** Verify local root shape, counts, hashes, and script non-claims before any content settlement.

**Risk:** `low`

**Acceptance gate:**

- workpackets_dir_present
- diffs_dir_present
- hashes_generated
- non_claims_preserved

**Settlement output:** `root_integrity_receipt`

## B01 — Indexes and front doors

**Scope:** `workpackets/README.md, workpackets/*INDEX*.json, diffs/README.md, diffs/*INDEX*.json`

**Goal:** Compare local index/front-door claims against content-proven counts.

**Risk:** `low`

**Acceptance gate:**

- index_counts_match_or_discrepancy_recorded
- front_door_purpose_recorded

**Settlement output:** `front_door_index_settlement_note`

## B02 — Patch/diff affected-path review

**Scope:** `diffs/*.diff, diffs/*.patch`

**Goal:** Extract touched paths and determine whether each diff is safe docs/schema/code/instruction/runtime/connector risk.

**Risk:** `high`

**Acceptance gate:**

- affected_paths_extracted
- no_apply
- target_domain_assigned
- human_review_for_code_or_instruction

**Settlement output:** `diff_affected_path_review_receipt`

## B03 — Custom GPT and instruction surfaces

**Scope:** `custom_gpt_carrier, instruction_surface_candidate`

**Goal:** Compare candidate instruction files and Custom GPT bridge docs against current router/branch law before any promotion.

**Risk:** `high`

**Acceptance gate:**

- source_priority_checked
- stale_instruction_risk_checked
- anti_theater_claims_verified

**Settlement output:** `custom_gpt_instruction_surface_settlement`

## B04 — Action gateway / MCP / connector surfaces

**Scope:** `action_gateway_mcp_connector, connector_schema_or_config_candidate, production_or_live_connector_surface, secret_or_auth_surface`

**Goal:** Classify connector/openapi/gateway/workpack material without invoking live services.

**Risk:** `high`

**Acceptance gate:**

- no_live_invocation
- auth_secret_surface_flagged
- schema_currentness_checked
- approval_boundary_preserved

**Settlement output:** `connector_surface_settlement`

## B05 — Extension / DOM / cockpit surfaces

**Scope:** `extension_browser_cockpit`

**Goal:** Group browser extension packets, DOM perception packages, and cockpit evidence for later integration.

**Risk:** `medium`

**Acceptance gate:**

- package_manifest_inspected
- extension_authority_boundary_preserved
- no_browser_action

**Settlement output:** `extension_surface_settlement`

## B06 — UI / JOC / OPUS context packages

**Scope:** `ui_joc_opus, media_evidence, binary_or_media_evidence`

**Goal:** Inspect UI context package manifests and image evidence; keep visual canon separate from workflow authority.

**Risk:** `medium`

**Acceptance gate:**

- zip_manifest_inspected
- image_metadata_recorded
- ui_canon_authority_boundary_preserved

**Settlement output:** `ui_context_package_settlement`

## B07 — Self-knowledge and doctrine witnesses

**Scope:** `self_knowledge_doctrine, governance_protocol_candidate`

**Goal:** Classify ontology, continuity, self-audit, architecture, and monolith/context export docs as current/candidate/witness/stale.

**Risk:** `medium`

**Acceptance gate:**

- source_priority_checked
- candidate_vs_current_boundary_preserved
- doctrine_conflict_recorded

**Settlement output:** `self_knowledge_doctrine_settlement`

## B08 — Codex CLI / IDE / local worker surfaces

**Scope:** `codex_cli_local_worker, carrier_runtime_governance`

**Goal:** Classify Codex/IDE/runtime worker proposals without executing local workers.

**Risk:** `medium_high`

**Acceptance gate:**

- no_worker_invocation
- runtime_boundary_checked
- packet_return_contract_identified

**Settlement output:** `codex_runtime_surface_settlement`

## B09 — Lineage, dAimon, and unclassified candidates

**Scope:** `aim_ion_lineage, daimon_product_line, unclassified_candidate`

**Goal:** Route historical/lineage/product/unclassified material to witness or future-domain status unless stronger evidence exists.

**Risk:** `medium`

**Acceptance gate:**

- lineage_not_promoted_to_current_law_without_evidence
- unclassified_items_routed
- deferred_items_named

**Settlement output:** `unclassified_and_lineage_settlement`
