# CODEX-001 Prompt — Apply SEV Multi-Lane Phase 4/5 Infrastructure

You are CODEX_LOCAL_ION_MASON operating on the local ION repo.

## Packet

```text
PCKT-ION-MULTI-LANE-OPERATING-SEQUENCER-001
PCKT-ION-PHASE-A-CONSTITUTIONAL-STABILIZATION-QUEUE-001
```

## Authority

No accepted-state authority. No production authority. No Git push. No Supabase migration. No raw Codex context export.

## Apply order

```bash
git apply SEV_MULTI_LANE_OPERATING_SEQUENCER_PHASE4_SOURCE_20260513.patch

git apply SEV_PHASE_A_CONSTITUTIONAL_STABILIZATION_QUEUE_PHASE5_SOURCE_20260513.patch
```

If either patch does not apply cleanly, stop and return the reject/context. Do not hand-merge silently.

## Validate

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=ION/04_packages PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest \
  ION/tests/test_kernel_ion_multi_lane_operating_sequencer.py \
  ION/tests/test_kernel_ion_phase_a_constitutional_stabilization_queue.py \
  -q

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=ION/04_packages python3 -m py_compile \
  ION/04_packages/kernel/ion_multi_lane_operating_sequencer.py \
  ION/04_packages/kernel/ion_phase_a_constitutional_stabilization_queue.py

git diff --check
```

## Generate candidate route artifacts

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=ION/04_packages python3 -S -m kernel.ion_multi_lane_operating_sequencer \
  --ion-root . \
  --write \
  --confirmation ION_MULTI_LANE_ROUTE_MAP_WRITE_CONFIRMED \
  --json

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=ION/04_packages python3 -S -m kernel.ion_phase_a_constitutional_stabilization_queue \
  --ion-root . \
  --write \
  --confirmation ION_PHASE_A_CONSTITUTIONAL_STABILIZATION_QUEUE_WRITE_CONFIRMED \
  --json
```

## Return format

```text
### CONTEXT PROOF
- active root
- branch
- git status summary before/after

### TEMPLATE ACTION PROOF
- patches applied
- generated refs

### ROUTE MAP RESULT
- verdict
- lane counts
- phase counts
- warnings

### PHASE A QUEUE RESULT
- verdict
- blockers
- ordered next packets
- Phase B unlock state

### VALIDATION
- tests
- py_compile
- git diff --check

### DIFF SUMMARY
- source files added/modified
- generated candidate refs

### NON-CLAIMS
- no accepted state
- no production
- no stage/commit/push unless separately authorized
- no Supabase migration
- no raw Codex context export
```
