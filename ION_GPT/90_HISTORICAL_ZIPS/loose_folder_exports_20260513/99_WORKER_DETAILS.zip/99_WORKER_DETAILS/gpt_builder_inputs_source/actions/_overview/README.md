# GPT Builder Actions Overview

There are currently two Custom GPT Action schemas to install if we want the old full setup restored.

## 1. ION Action Gateway

Folder:

```text
../ion-actions.helixion.net/
```

Schema:

```text
../ion-actions.helixion.net/SCHEMA_TO_PASTE.yaml
```

Purpose:

- ION core Action Gateway
- bounded gateway reads/writes
- browser queue endpoints
- bounded agent lane
- Supabase ion_ops cockpit endpoints

Server:

```text
https://ion-actions.helixion.net
```

## 2. ION MCP Action

Folder:

```text
../ion.helixion.net_mcp/
```

Schema:

```text
../ion.helixion.net_mcp/SCHEMA_TO_PASTE.yaml
```

Purpose:

- MCP health/status
- MCP JSON-RPC bridge
- tools/list and tools/call through MCP wrapper

Server:

```text
https://ion.helixion.net
```

Endpoint:

```text
/mcp
```

## Important

These are two separate GPT Builder Action entries, not one schema.

The previous recovery work focused on the Action Gateway schema. The MCP Action existed historically and is now restored in this input folder for visibility.
