# 06 — Supabase Runtime Data Plane

Supabase should become the realtime operational database and cockpit backend for ION.

ION files and Git remain truth. Supabase makes the truth queryable and visible.

## First principle

```text
ION local receipts/files/Git = durable truth.
Supabase = realtime operational mirror and query/index layer.
```

## Initial tables

Start small:

```text
automation_events
carrier_mount_receipts
service_health_snapshots
```

Then expand:

```text
agents
codex_sessions
branch_capsules
work_packets
task_returns
receipts
tool_calls
drift_findings
git_events
settlement_items
drive_exports
slack_events
daimon_traces
```

## Event mirror law

```text
local receipt/event first
then Supabase mirror
never Supabase-only accepted truth
```

## Realtime cockpit

Supabase Realtime can power:

```text
active agent list
automation timeline
service health
drift findings
settlement queue
git events
packet status
dAimon lane status
```

## Read/write posture

Start with a development project, read-only MCP, project-scoped access, and restricted feature groups. Only after schema and mirror code are proven should write access be introduced through ION policy.
