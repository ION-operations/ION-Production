# ION UI Edge / Drawer / Timeline Context Patch v0.1.1

**Patch ID:** `ION_UI_EDGE_DRAWER_TIMELINE_PATCH_V0_1_1`  
**Receipt ID:** `ION_UI_CONTEXT_PATCH_RECEIPT_20260510T160050Z`  
**Status:** Candidate context patch; not accepted registry state.  
**Reason:** Operator flagged three critical UI mechanisms that must not be lost: wraparound button borders, left/right drawer behavior, and bottom timeline behavior.

## Finding

| Mechanism | Present in UI canon? | Patch action |
|---|---|---|
| Wraparound / four-side button border | **Partial.** The physical edge law is present, but not as a single named button-border spec. | Formalized as `ION_EDGE_BUTTON_FRAME_SPEC`. |
| Left/right drawers | **Yes, explicit.** Right split-click drawer zones, collapsible drawers, left drawer/page-local pattern, and drawer layers are documented. | Promoted into `ION_DRAWER_SPLIT_ZONE_AND_DUAL_RAIL_SPEC`. |
| Bottom timeline | **Yes, explicit.** Five-zone shell and bottom timeline/expandable inspector are documented. | Promoted into `ION_BOTTOM_TIMELINE_AND_EXPANDABLE_INSPECTOR_SPEC`. |

## 1. Edge Button Frame Spec

**Name:** `ION_EDGE_BUTTON_FRAME_SPEC`

The source bundle does not use the exact phrase "wraparound button border", but `uishader.txt` contains the deeper mechanism:

- global light source and top/bottom edge behavior: `_ui_canon_bundle/uishader.txt` L11-L16
- material volume gradients: `_ui_canon_bundle/uishader.txt` L18-L24
- inverse cut / micro-bevels: `_ui_canon_bundle/uishader.txt` L33-L39
- track top/bottom bevel implementation: `_ui_canon_bundle/uishader.txt` L60-L70
- 1px border as chassis cut / physical separation: `_ui_canon_bundle/uishader.txt` L146-L170
- icon button active bottom-edge standard: `_ui_canon_bundle/OPUS_VISUAL_SETTINGS_CANON.md` L208-L235

### Canonical Rules

1. Important buttons are physical instruments, not flat rectangles.
2. The four sides matter: top, bottom, left, and right must participate in one coherent light/material model.
3. Top edge normally catches or blocks light depending on convex/concave geometry.
4. Bottom edge carries the paired highlight/shadow that sells depth.
5. Left/right sides must not leak generic shadow; constrained or negative-spread shadows preserve the top-down material illusion.
6. A `1px` border is not decorative; it represents a microscopic chassis cut, material seam, or separation line.
7. Active bottom-border cues are allowed only when they do not erase the full edge-frame/material volume.
8. Hover, active, pressed, disabled, dark/light, and high-contrast states must all preserve edge-frame truth.

## 2. Drawer Split-Zone And Dual-Rail Spec

**Name:** `ION_DRAWER_SPLIT_ZONE_AND_DUAL_RAIL_SPEC`

Source anchors:

- right icon bar split-click zones: `_ui_canon_bundle/OPUS1_JOC_UI_DESIGN.md` L51-L64
- collapsible drawers, sub-tabs, scroll overflow, collapsed 16px state, width modes: `_ui_canon_bundle/OPUS1_JOC_UI_DESIGN.md` L66-L106
- complete layout with left drawer bar and right icon bar: `_ui_canon_bundle/OPUS1_JOC_UI_DESIGN.md` L176-L245
- sparse pages become drawers/sections; activity/project surfaces live in left drawer: `_ui_canon_bundle/JOC_UI_REQUIREMENTS.md` L75-L85
- layered drawer architecture: `_ui_canon_bundle/ULTIMATE_OPUS_VISUAL_INTERFACE_CANON.md` L683-L722

### Canonical Rules

1. Left rail/drawer owns navigation, project/context graph, activity feed, source/context selection, and page-local orientation.
2. Right rail/drawer owns inspectors, settings, tools, visual editors, and contextual actions.
3. Right icon targets support split zones:
   - left/full area → full-height drawer
   - top-right → top-half drawer
   - bottom-right → bottom-half drawer
4. Dense drawers use top sub-tabs instead of becoming many pages.
5. Collapsed drawers retain identity as a thin rail/rotated title, not invisible hidden state.
6. Widths have meaning: compact settings ≈ 280px, rich specialized drawers ≈ 400px, custom only when domain need proves it.

## 3. Bottom Timeline And Expandable Inspector Spec

**Name:** `ION_BOTTOM_TIMELINE_AND_EXPANDABLE_INSPECTOR_SPEC`

Source anchors:

- five-zone shell with bottom bar for Timeline/Comms/Terminal/Diagnostics: `_ui_canon_bundle/CANON_JOC_UI_ARCHITECTURE.md` L50-L63
- responsive collapsible bottom behavior: `_ui_canon_bundle/CANON_JOC_UI_ARCHITECTURE.md` L69-L83
- normal h-12 timeline and expanded h-64 inspector: `_ui_canon_bundle/OPUS1_JOC_UI_DESIGN.md` L109-L132
- bottom panel tabs/status footer: `_ui_canon_bundle/OPUS1_JOC_UI_DESIGN.md` L214-L224

### Canonical Rules

1. The bottom rail is not a footer; it is the temporal/operational substrate.
2. Normal state shows hints, mission progress, timeline cursor, active agents, compute, MCP, and selected agent/session state.
3. Expanded state becomes an inspector with selected entity, properties, session details, and quick actions.
4. Bottom panels may host Agent Comms, Output, Missions, Resources, terminal, diagnostics, and proof logs.
5. Timeline state must distinguish live, historical, queued, blocked, and verified events.
6. Responsive behavior may collapse or overlay the timeline, but must not delete temporal continuity.

## Candidate Agents Added

- `EDGE_FRAME_PHYSICS_SPECIALIST`
- `DRAWER_SYSTEM_ARCHITECT`
- `BOTTOM_TIMELINE_ORCHESTRATOR`

## Proof Gates Added

- `edge_frame_four_side_visual_check`
- `drawer_split_zone_interaction_check`
- `left_right_drawer_role_separation_check`
- `bottom_timeline_collapsed_expanded_check`
- `temporal_state_distinction_check`

## Next Packet

`ION_UI_PACKET_002_EDGE_DRAWER_TIMELINE` — convert this canon patch into concrete ION UI templates/primitives.
