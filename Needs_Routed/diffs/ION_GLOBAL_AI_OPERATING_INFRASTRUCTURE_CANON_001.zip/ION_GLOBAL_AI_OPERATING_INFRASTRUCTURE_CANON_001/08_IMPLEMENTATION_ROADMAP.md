# 08 — Implementation Roadmap

## Phase 0 — unblock visibility

1. Full Google Drive repo mirror.
2. GPT PRO mounts repo from Drive.
3. Stop manual ZIP dependency.

## Phase 1 — commit local governance primitives

1. Commit branch-capsule consolidation.
2. Commit carrier mount + persona presentation.
3. Add read-only MCP mount receipt tool.

## Phase 2 — Codex Carrier OS

1. Codex carrier cartography.
2. Codex session registry.
3. Codex memory ↔ ION rolling context sync.
4. Codex agent/domain registry.
5. Codex hooks and slash commands.
6. Codex app-server/cockpit integration.

## Phase 3 — Supabase runtime

1. Supabase cartography.
2. Operational schema.
3. Event mirror adapter.
4. Realtime cockpit panels.
5. Drift/consistency dashboards.

## Phase 4 — App carrier expansion

1. Slack carrier bus.
2. GitHub/GitLab source/review plane.
3. Google Drive mirror automation.
4. dAimon/Gemini lane integration.
5. Browser extension / cockpit integration.

## Phase 5 — Full ION operating runtime

1. Multi-agent orchestration graph.
2. User-specific carrier onboarding.
3. Realtime cockpit.
4. Automations and approvals.
5. Settlement UI.
6. AI workforce operations layer.

## Immediate next packets

```text
PCKT-ION-FULL-GDRIVE-REPO-MIRROR-001
PCKT-ION-BRANCH-CAPSULE-COMMIT-REVIEW-006
PCKT-ION-CARRIER-MOUNT-PERSONA-COMMIT-REVIEW-001
PCKT-ION-CODEX-CARRIER-OPERATING-SYSTEM-CARTOGRAPHY-001
PCKT-ION-SUPABASE-CARRIER-CARTOGRAPHY-001
PCKT-ION-COCKPIT-OPERATING-UI-SPEC-001
```
