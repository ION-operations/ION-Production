# Open Questions for ION PRO

## Codex Carrier Domain

1. What should be ION-owned durable state versus Codex native memory/session state?
2. How should Codex `resume` sessions map to ION branch capsules?
3. Should each ION domain agent have a long-lived Codex session?
4. How should Codex native memories be used without creating hidden, ungoverned state?
5. Which existing ION Codex files should be preserved, consolidated, or retired?
6. How should Codex subagents map to ION domains and branch capsules?
7. How should Codex hooks enforce ION law without overblocking local IDE-style work?
8. What slash commands should become canonical ION/Codex commands?
9. What MCP surfaces should Codex use directly versus through ION gateway tooling?
10. How should the system expose visible agent state without claiming hidden reasoning?

## ION Workflow / Logic Gaps

1. Where is ION currently duplicating functionality that Codex already provides natively?
2. Where is Codex memory too weak/ephemeral and must be replaced by ION durable context?
3. What current workflows still rely on fragile prompts rather than deterministic templates/hooks?
4. Where are receipts and settlement too late in the process?
5. Which source-lane indexes are stale and need regeneration?
6. How should runtime evidence be quarantined and shown in Git/settlement dashboards?
7. What does “accepted state” mean when source code is pushed but runtime/settlement is candidate?
8. How should branch-capsule law wrap Git, Codex, and extension work?

## ION Codex Cockpit

1. What are the minimum cockpit panels needed first?
2. What should the agent graph show?
3. What should the drift/consistency dashboard show?
4. What automations should emit UI events?
5. How should Git staging/commit/push plans be displayed?
6. How should settlement status be displayed?
7. How can the UI be AI-assisted without becoming opaque or over-automated?
8. How does UI canon/JOC/OPUS constrain the cockpit design?

## Near-term packet review

Please review these proposed packets:

1. `PCKT-ION-CODEX-CARRIER-OPERATING-SYSTEM-CARTOGRAPHY-001`
2. `PCKT-ION-CODEX-SESSION-BRANCH-CAPSULE-SYNC-001`
3. `PCKT-ION-CODEX-SPECIALIST-DOMAIN-REGISTRY-001`
4. `PCKT-ION-CODEX-HOOK-ENFORCEMENT-LAYER-001`
5. `PCKT-ION-CODEX-SLASH-COMMAND-PACK-001`
6. `PCKT-ION-CODEX-COCKPIT-MVP-001`
7. `PCKT-ION-DRIFT-CONSISTENCY-DASHBOARD-001`
