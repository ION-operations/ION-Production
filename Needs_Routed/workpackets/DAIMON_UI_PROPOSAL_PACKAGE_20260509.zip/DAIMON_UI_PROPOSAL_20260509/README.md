# dAimon UI Proposal Package

This package contains a source-grounded UI proposal for **dAimon**, interpreted as a productized Conjugate Daimon / Vice review cockpit for ION.

## Contents

```text
DAIMON_UI_PROPOSAL_MASTER_SPEC_20260509.md
DAIMON_UI_IMPLEMENTATION_BACKLOG_20260509.md
prototype/daimon_ui_prototype.html
schemas/DAIMON_UI_DATA_MODEL_20260509.yaml
schemas/DAIMON_UI_SCREEN_MAP_20260509.json
schemas/DAIMON_UI_SAMPLE_SESSION_20260509.json
manifests/DAIMON_UI_SOURCE_MANIFEST_20260509.json
receipts/DAIMON_UI_PROPOSAL_RECEIPT_20260509.json
```

## How to view the prototype

Open:

```text
prototype/daimon_ui_prototype.html
```

It is a static, no-dependency HTML prototype. It does not call external services and does not mutate state.

## Posture

```yaml
source_posture: CARTOGRAPHED_WITNESS
accepted_ion_state_changed: false
live_runtime_claimed: false
production_authority: false
```
