# WisdomNET Structural Evolution Layer

## Role

WisdomNET should be integrated as ION's structural intelligence evolution layer.

It is not a data-extraction layer.

WisdomNET should learn from the shape of lawful AI work:

```text
template usage patterns
template gaps
domain fission pressure
context package shapes
proof-gate failures
settlement outcomes
branch return patterns
carrier routing patterns
recovery-tax measures
workflow success/failure classes
```

It should not export user content, private code, secrets, or proprietary project substance.

## Private-content firewall

```text
Private workspace:
  user code
  private documents
  receipts with sensitive substance
  source material
  raw transcripts
  customer/project content

WisdomNET structural export:
  template type
  domain class
  failure class
  proof gate class
  route class
  settlement outcome class
  context shape
  anonymized structure
```

## Relationship to ION

```text
ION governs inheritance.
WisdomNET evolves scaffolds.
```

ION decides what a workflow is allowed to inherit. WisdomNET improves the reusable structures that make future workflows more effective.

## Relationship to Supabase

Supabase can mirror WisdomNET structural signals as queryable events:

```text
wisdomnet_structural_signal
template_gap_detected
domain_fission_signal
proof_failure_classified
settlement_pattern_observed
recovery_tax_measured
```

## Relationship to the cockpit

The cockpit should show WisdomNET signals as learning opportunities, not accepted law:

```text
Template gap detected
Domain fission pressure rising
Repeated proof failure class
High recovery tax branch
Candidate workflow improvement
```
