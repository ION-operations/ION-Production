# 05 — Integration With ION Carriers

## Codex CLI

Codex writes and validates migrations, adapter code, tests, and type generation.

Codex should not receive service-role secrets in chat. It may use locally configured environment variables or Supabase CLI after Braden approves.

## GPT-001

GPT-001 coordinates, reads cockpit summaries, tests ION MCP, and prepares packets. GPT-001 should not directly own database secrets.

## Sev / GPT PRO

Sev reviews Supabase architecture and long-horizon ION runtime design. Sev should distinguish live Supabase evidence, repo migration evidence, and inference.

## ION MCP / Action Gateway

ION MCP should become the primary safe bridge:

```text
ChatGPT → ION MCP → local ION adapter → Supabase
```

## Cockpit UI

Cockpit reads views and subscribes to Realtime after policies are deliberate.

## dAimon / MongoDB

dAimon remains a Google/Gemini lane. MongoDB/Atlas may remain the trace/document backend. ION mirrors selected dAimon trace metadata into Supabase.

## GitHub / GitLab

GitHub/GitLab remain source/review planes. Supabase may mirror git events but does not replace Git.

## Slack

Slack events can be mirrored later as witness/notification events.
