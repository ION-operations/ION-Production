# Branch 05 — ATLAS External Systems Reference

## Bound artifact

`ATLAS.zip`

## Purpose

ATLAS is a source-grounded comparative reference library for real-world operating systems, platforms, runtimes, protocols, and adjacent systems. It lets ION learn from many lineages without replacing ION doctrine or copying one system wholesale.

## Use this branch for

- comparative OS/platform research
- evidence-tiered references to external systems
- design inspiration for ION, AIM, JOC, agents, IDE/OS-class architecture
- taxonomy, tags, and system relation maps
- identifying what is documented, observed, historical, inferred, or unknown

## First files to inspect

- `ATLAS/README.md`
- `ATLAS/_meta/MASTER_SYSTEMS_EXPANSION_PLAN.md`
- `ATLAS/_meta/ontology.md`
- `ATLAS/_meta/evidence_tiers.md`
- `ATLAS/_meta/quality_bar.md`
- `ATLAS/_meta/naming_conventions.md`
- `ATLAS/_meta/relation_types.md`
- `ATLAS/indexes/systems_index.yaml`
- `ATLAS/indexes/tag_index.yaml`
- `ATLAS/indexes/evidence_index.yaml`
- relevant `ATLAS/systems/<slug>/` package

## Authority posture

ATLAS is curatorial and external-reference authority, not ION constitutional law. It can support analogies, comparisons, risks, and design options. It cannot accept state for ION.

## Branch output rule

For external-system claims, preserve evidence tier:

```text
DOCUMENTED
OBSERVED
HISTORICAL
INFERRED
UNKNOWN
```

Prefer UNKNOWN over invented architecture when primary evidence is missing.
