-- ION Supabase Operating Runtime
-- Migration 003: Authority helpers and typed RPC insert lane
--
-- Purpose:
--   Allow AI/service carriers to insert operational mirror evidence through
--   narrow typed functions instead of broad table privileges.
--
-- Assumes role helpers from migration 002 exist.

-- ---------------------------------------------------------------------
-- record_automation_event
-- ---------------------------------------------------------------------

create or replace function ion_ops.record_automation_event(
  p_event_type text,
  p_severity text default 'info',
  p_source_system text default 'ion',
  p_carrier_id text default null,
  p_carrier_type text default null,
  p_agent_tag text default null,
  p_branch_id text default null,
  p_context_instance_id text default null,
  p_packet_id text default null,
  p_correlation_id text default null,
  p_idempotency_key text default null,
  p_title text default null,
  p_summary text default null,
  p_payload jsonb default '{}'::jsonb,
  p_evidence_refs jsonb default '[]'::jsonb,
  p_source_posture jsonb default '{}'::jsonb
)
returns ion_ops.automation_events
language plpgsql
security invoker
as $$
declare
  inserted ion_ops.automation_events;
begin
  if not ion_ops.has_any_ion_role(array['ion_agent_writer', 'ion_operator', 'ion_steward', 'ion_admin']) then
    raise exception 'ION role required: ion_agent_writer or higher';
  end if;

  insert into ion_ops.automation_events (
    source_system,
    event_type,
    severity,
    carrier_id,
    carrier_type,
    agent_tag,
    branch_id,
    context_instance_id,
    packet_id,
    correlation_id,
    idempotency_key,
    title,
    summary,
    payload,
    evidence_refs,
    source_posture,
    accepted_state_claim,
    settlement_required
  )
  values (
    p_source_system,
    p_event_type,
    coalesce(p_severity, 'info'),
    p_carrier_id,
    p_carrier_type,
    p_agent_tag,
    p_branch_id,
    p_context_instance_id,
    p_packet_id,
    p_correlation_id,
    p_idempotency_key,
    p_title,
    p_summary,
    coalesce(p_payload, '{}'::jsonb),
    coalesce(p_evidence_refs, '[]'::jsonb),
    coalesce(p_source_posture, '{}'::jsonb),
    false,
    true
  )
  returning * into inserted;

  return inserted;
end;
$$;

grant execute on function ion_ops.record_automation_event(
  text, text, text, text, text, text, text, text, text, text, text, text, text, jsonb, jsonb, jsonb
) to authenticated;

-- Policy for RPC/function insert path.
-- Since security invoker functions need underlying insert permission and policy,
-- allow INSERT only for ion_agent_writer or higher. The function still normalizes
-- accepted_state_claim=false and settlement_required=true.

drop policy if exists automation_events_agent_writer_insert
  on ion_ops.automation_events;

create policy automation_events_agent_writer_insert
on ion_ops.automation_events
for insert
to authenticated
with check (
  ion_ops.has_any_ion_role(array['ion_agent_writer', 'ion_operator', 'ion_steward', 'ion_admin'])
  and accepted_state_claim = false
  and settlement_required = true
);

grant insert on ion_ops.automation_events to authenticated;

-- ---------------------------------------------------------------------
-- record_service_health_snapshot
-- ---------------------------------------------------------------------

create or replace function ion_ops.record_service_health_snapshot(
  p_service_name text,
  p_status text default 'unknown',
  p_service_role text default null,
  p_carrier_id text default null,
  p_endpoint text default null,
  p_host text default null,
  p_port integer default null,
  p_pid integer default null,
  p_verdict text default null,
  p_version_line text default null,
  p_health jsonb default '{}'::jsonb,
  p_findings jsonb default '[]'::jsonb,
  p_source_posture jsonb default '{}'::jsonb
)
returns ion_ops.service_health_snapshots
language plpgsql
security invoker
as $$
declare
  inserted ion_ops.service_health_snapshots;
begin
  if not ion_ops.has_any_ion_role(array['ion_agent_writer', 'ion_operator', 'ion_steward', 'ion_admin']) then
    raise exception 'ION role required: ion_agent_writer or higher';
  end if;

  insert into ion_ops.service_health_snapshots (
    service_name,
    status,
    service_role,
    carrier_id,
    endpoint,
    host,
    port,
    pid,
    verdict,
    version_line,
    production_authority,
    live_execution_authority,
    health,
    findings,
    source_posture
  )
  values (
    p_service_name,
    coalesce(p_status, 'unknown'),
    p_service_role,
    p_carrier_id,
    p_endpoint,
    p_host,
    p_port,
    p_pid,
    p_verdict,
    p_version_line,
    false,
    false,
    coalesce(p_health, '{}'::jsonb),
    coalesce(p_findings, '[]'::jsonb),
    coalesce(p_source_posture, '{}'::jsonb)
  )
  returning * into inserted;

  return inserted;
end;
$$;

drop policy if exists service_health_snapshots_agent_writer_insert
  on ion_ops.service_health_snapshots;

create policy service_health_snapshots_agent_writer_insert
on ion_ops.service_health_snapshots
for insert
to authenticated
with check (
  ion_ops.has_any_ion_role(array['ion_agent_writer', 'ion_operator', 'ion_steward', 'ion_admin'])
  and production_authority = false
  and live_execution_authority = false
);

grant insert on ion_ops.service_health_snapshots to authenticated;

-- ---------------------------------------------------------------------
-- record_carrier_mount_receipt
-- ---------------------------------------------------------------------

create or replace function ion_ops.record_carrier_mount_receipt(
  p_carrier_type text,
  p_agent_tag text,
  p_context_instance_id text,
  p_carrier_id text default null,
  p_carrier_instance_id text default null,
  p_conversation_tag text default null,
  p_branch_id text default null,
  p_parent_context_id text default null,
  p_current_packet text default null,
  p_model_lane text default null,
  p_loaded_refs jsonb default '[]'::jsonb,
  p_authority jsonb default '{}'::jsonb,
  p_write_scope jsonb default '[]'::jsonb,
  p_source_posture jsonb default '{}'::jsonb,
  p_return_target jsonb default '{}'::jsonb,
  p_persona_presentation jsonb default '{}'::jsonb,
  p_drift_findings jsonb default '[]'::jsonb,
  p_raw_receipt jsonb default '{}'::jsonb
)
returns ion_ops.carrier_mount_receipts
language plpgsql
security invoker
as $$
declare
  inserted ion_ops.carrier_mount_receipts;
begin
  if not ion_ops.has_any_ion_role(array['ion_agent_writer', 'ion_operator', 'ion_steward', 'ion_admin']) then
    raise exception 'ION role required: ion_agent_writer or higher';
  end if;

  insert into ion_ops.carrier_mount_receipts (
    carrier_id,
    carrier_type,
    carrier_instance_id,
    agent_tag,
    conversation_tag,
    context_instance_id,
    branch_id,
    parent_context_id,
    current_packet,
    model_lane,
    loaded_refs,
    authority,
    write_scope,
    source_posture,
    return_target,
    persona_presentation,
    drift_findings,
    raw_receipt,
    accepted_state_authority,
    settlement_required,
    valid
  )
  values (
    p_carrier_id,
    p_carrier_type,
    p_carrier_instance_id,
    p_agent_tag,
    p_conversation_tag,
    p_context_instance_id,
    p_branch_id,
    p_parent_context_id,
    p_current_packet,
    p_model_lane,
    coalesce(p_loaded_refs, '[]'::jsonb),
    coalesce(p_authority, '{}'::jsonb),
    coalesce(p_write_scope, '[]'::jsonb),
    coalesce(p_source_posture, '{}'::jsonb),
    coalesce(p_return_target, '{}'::jsonb),
    coalesce(p_persona_presentation, '{}'::jsonb),
    coalesce(p_drift_findings, '[]'::jsonb),
    coalesce(p_raw_receipt, '{}'::jsonb),
    false,
    true,
    true
  )
  returning * into inserted;

  return inserted;
end;
$$;

drop policy if exists carrier_mount_receipts_agent_writer_insert
  on ion_ops.carrier_mount_receipts;

create policy carrier_mount_receipts_agent_writer_insert
on ion_ops.carrier_mount_receipts
for insert
to authenticated
with check (
  ion_ops.has_any_ion_role(array['ion_agent_writer', 'ion_operator', 'ion_steward', 'ion_admin'])
  and accepted_state_authority = false
  and settlement_required = true
);

grant insert on ion_ops.carrier_mount_receipts to authenticated;
