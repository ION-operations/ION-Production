# Living Encyclopedia Compiler Workspace

Status: candidate workspace for `PCKT-ION-AIMOS-WISDOMNET-LIVING-ENCYCLOPEDIA-INTEGRATION-001`.

This directory is for candidate documentation deltas, compiler reports, and settlement requests that feed the Living Encyclopedia.

## Intended layout

```text
inbox/
  documentation_delta_*.json

compiled/
  candidate_report_*.json
  branch_summary_*.md
  domain_summary_*.md

reports/
  validation_report_*.json
```

## Source posture

Files here are candidate inputs or generated candidate reports. They do not directly update the main encyclopedia, global canon, or accepted ION state.

## Core relationship

```text
lawful operation
→ receipt / branch return
→ documentation delta
→ compiler candidate report
→ settlement request
→ accepted documentation update if approved
```
