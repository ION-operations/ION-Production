# Drift, Consistency, and Proof Dashboards

Status: candidate dashboard requirements.

## Why this exists

ION has become a multi-carrier, multi-repo, multi-agent operating substrate. The cockpit must not only show activity; it must show whether activity is lawful, current, coherent, and inheritable.

## Signals to compute

### Context drift

- Codex session references an old packet.
- Branch capsule `CURRENT_PACKET` differs from session prompt.
- Codex memory suggests outdated state.
- `HOT_CONTEXT` and `STATUS.json` disagree.
- Continuity bundle generated before latest commit.

### Git drift

- dirty tracked source files,
- dirty runtime state files,
- untracked candidate diffs/workpackets,
- staged files not matching stage manifest,
- pushed commits not reflected in context package,
- sibling repo drift not represented in ION.

### Queue drift

- duplicate work packet groups,
- queue head differs from selected packet,
- superseded packets still shown as active,
- worker return attached to superseded packet,
- active process null but active run pointer exists,
- stale queue indices.

### Proof drift

- worker says tests passed but no command/return code saved,
- task return missing required sections,
- workload diff missing,
- proof-gate failed but candidate work was still materially useful,
- proof-blocked return not indexed for salvage.

### Agent drift

- agent branch missing identity card,
- write scope absent or too broad,
- loaded refs missing,
- branch capsule stale relative to Codex session,
- subagent return lacks settlement target.

### Service drift

- documented port owner differs from live process owner,
- Cloudflare tunnel points to wrong local service,
- MCP tools exposed but local service not refreshed,
- Action Gateway and MCP disagree on policy.

### UI/cockpit drift

- UI claim lacks screenshot/visual proof,
- component violates UI canon,
- dashboard hides action provenance,
- operational state not visually linked to receipts.

## Dashboard outputs

Each signal should resolve to a status:

```text
READY
CANDIDATE
STALE
DRIFTED
BLOCKED
CONFLICT
UNKNOWN
SUPERSEDED
ACCEPTED
DEFERRED
```

## Required proof per status

- READY: current hash/receipt/test exists.
- CANDIDATE: candidate path and non-claim shown.
- STALE: older timestamp/hash/packet detected.
- DRIFTED: two state surfaces disagree.
- BLOCKED: blocker path/reason/next route shown.
- CONFLICT: conflicting branches/files/scope shown.
- SUPERSEDED: canonical replacement and receipt shown.
- ACCEPTED: settlement/receipt authority shown.
- DEFERRED: deferral reason and recheck condition shown.

## Immediate implementation packets

1. `PCKT-ION-CODEX-CARRIER-DASHBOARD-SIGNAL-REGISTRY-001`
2. `PCKT-ION-CODEX-CARRIER-SESSION-DRIFT-CHECK-002`
3. `PCKT-ION-GIT-STATE-CLASSIFIER-DASHBOARD-003`
4. `PCKT-ION-QUEUE-DUPLICATE-SUMMARY-MODE-004`
5. `PCKT-ION-CARRIER-SERVICE-PORT-DRIFT-PROJECTION-005`
