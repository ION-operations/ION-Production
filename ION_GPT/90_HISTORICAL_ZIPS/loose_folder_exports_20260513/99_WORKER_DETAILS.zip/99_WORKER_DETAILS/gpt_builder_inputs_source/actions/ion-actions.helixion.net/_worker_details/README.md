# Worker Details

This folder is for AI workers, Codex, and release auditors.

Human GPT Builder setup uses only:

```text
../INSTRUCTIONS.md
../SCHEMA_TO_PASTE.yaml
```

Files here may explain operation groups, auth posture, release rules, validation, and rollback details. They are not separate Action inputs.
