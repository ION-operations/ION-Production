# ION Action Details for Workers

## Active server

```text
https://ion-actions.helixion.net
```

## Active schema

```text
ION_GPT/gpt_builder_inputs/actions/ion-actions.helixion.net/SCHEMA_TO_PASTE.yaml
```

## Logical operation groups

The active schema is one installable Action schema with two logical groups:

1. ION core Action Gateway operations.
2. Supabase ion_ops cockpit operations.

## Release law

Do not hand Braden a fragment as an install target. GPT Builder changes require a release bundle when schema/auth changes are material.

## Stop rule

If a protected Action returns `AUTH_INVALID`, `gateway_token_invalid`, or unexpected `AUTH_MISSING`, stop all protected calls immediately.
