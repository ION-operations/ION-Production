# External Platform Notes

This package is primarily based on uploaded/repo/ATLAS inspection. For current external platform direction, GPT-001 also checked official and vendor docs:

- OpenAI ChatGPT Apps / connectors docs: apps, sync apps, MCP apps, write actions.
- OpenAI Google Drive sync docs: Google Drive app with sync can make Drive content available to ChatGPT when synced and permissioned.
- OpenAI Codex docs: Codex CLI/App supports local work, sessions/resume, app workflows, hooks, subagents, MCP, etc.
- Supabase MCP docs: Supabase MCP supports project scoping, read-only mode, and dev-oriented project access.

These external sources should be rechecked before implementation because platform capabilities are moving quickly.
