# R3F Build Plan for Living Operational Graph

## Rendering Architecture

```text
Data graph (JSON)
→ normalization layer
→ view model / LOD resolver
→ R3F scene graph
→ HTML overlay panels
→ Mermaid/ReactFlow deep workflow inspector
```

## Scene Components

```text
<LivingGraphScene>
  <OrthographicCamera />
  <DistrictLayer />
  <RoadLayer />
  <BuildingLayer />
  <CarrierTrafficLayer />
  <CheckpointLayer />
  <TimelineSync />
  <SelectionRaycaster />
  <HtmlLabels />
</LivingGraphScene>
```

## Data Stores

```text
graphStore
selectionStore
timelineStore
layerFilterStore
liveTelemetryStore
```

## Performance

Use instanced meshes for:

```text
buildings
small nodes
traffic particles
checkpoint markers
```

Use CSS/HTML overlays for:

```text
labels
cards
inspector
timeline
filters
```

## LOD

```text
zoom < 0.35: districts and highways only
0.35-0.7: buildings and route classes
0.7-1.4: floors, carriers, checkpoints
>1.4: workflow/mermaid detail available
```

## MVP Vertical Slice

1. Load sample JSON.
2. Render districts as hex/organic parcels.
3. Render roads as glowing curves.
4. Render buildings as instanced towers.
5. Animate carriers as particles along roads.
6. Click building opens inspector.
7. Timeline scrub moves traffic events.
8. Badge sample/live/candidate state everywhere.
