# Install / Ingest Instructions

Package: `ION_LIVING_GRAPH_CONTEXT_PACKAGE_20260510_v0_2`

This is a candidate context package. Do not treat as accepted local ION state until local ION/Codex validates and receipts it.

Recommended local target:

```text
/home/sev/ION - Production/ION_CODEX FULL/
```

Suggested copy/stage:

```bash
unzip ION_LIVING_GRAPH_CONTEXT_PACKAGE_20260510_v0_2.zip -d /tmp/ION_LIVING_GRAPH_CONTEXT_PACKAGE_20260510_v0_2
cd "/home/sev/ION - Production/ION_CODEX FULL"
cp -r /tmp/ION_LIVING_GRAPH_CONTEXT_PACKAGE_20260510_v0_2/APPLY_TO_LOCAL/* .
```

Then ask Codex/ION to:

```text
1. Validate JSON schemas and sample graph.
2. Confirm target paths.
3. Preserve existing dashboard and evidence files.
4. Create a proof-gated task return.
5. Do not implement full UI until GRAPH_003.
```
