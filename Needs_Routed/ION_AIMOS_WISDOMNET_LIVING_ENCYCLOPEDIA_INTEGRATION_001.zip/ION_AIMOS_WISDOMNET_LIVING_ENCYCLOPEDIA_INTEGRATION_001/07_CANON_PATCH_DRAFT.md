# Canon Patch Draft

Candidate section for ION v9 / global canon.

## AIMOS, WisdomNET, and the Living Encyclopedia

ION should treat AIMOS/AIM-ION as lineage witness and source-bearing ancestor material, not as current law. AIMOS preserves a deep north-star and master-index family that can strengthen ION's current documentation, variable-density context, and long-horizon navigation.

WisdomNET is the structural evolution layer. It should not export user content. It should learn from the reusable shapes of lawful operations: template use, proof failures, domain fission, settlement outcomes, and recovery-tax patterns.

The living encyclopedia should be compiled from lawful ION operations. Templates, receipts, branch returns, documentation deltas, WisdomNET signals, and ATLAS signals become the raw material of future context. The main explainer is one rendering of this substrate, not the substrate itself.

Strong formulation:

```text
AIMOS preserves navigational depth.
WisdomNET evolves workflow structure.
ION governs inheritance.
The living encyclopedia compiles from lawful movement.
```
