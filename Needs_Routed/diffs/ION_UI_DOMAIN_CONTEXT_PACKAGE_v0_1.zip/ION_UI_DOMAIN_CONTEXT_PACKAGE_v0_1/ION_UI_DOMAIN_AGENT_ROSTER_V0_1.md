# ION UI Mastery Domain — Candidate Agent Roster v0.1

created_at: 2026-05-10T15:13:37Z  
status: candidate_roster  
authority_ceiling: candidate_only_no_registry_mutation  
parent_candidate_domain: ui_ux_domain  
new_domain_candidate: ion_ui_mastery_domain  

## Purpose

This roster makes UI excellence reusable inside ION. The goal is not to create UI-themed personalities. Each agent is a governed interface to a bounded UI graph region.

## Domain split

| Domain | Primary Agent | Burden | Proof |
|---|---|---|---|
| `ui_canon_authority_domain` | `UI_CANON_LIBRARIAN` | source authority, canon compression, stale/donor/current classification | source ledger + canon digest + conflict notes |
| `ion_work_surface_architecture_domain` | `ION_WORK_SURFACE_ARCHITECT` | ION cockpit zones, state projection, receipt rails, command surfaces | layout contract + mapped state surfaces + non-authority boundaries |
| `visual_instrument_design_domain` | `VISUAL_INSTRUMENT_DESIGNER` | direct manipulation editors, visual parameter instruments, ROM zones, live previews | vision handoff + component contract + completion checklist |
| `interaction_material_physics_domain` | `INTERACTION_MATERIAL_PHYSICIST` | skeuomorphic material depth, shader-like CSS, motion physics, tactile interactions | material-light model + motion-state matrix + visual proof |
| `component_system_implementation_domain` | `UI_IMPLEMENTATION_MASON` | React/TypeScript components, tokens, architecture, story/test harnesses | diffs + types + tests + rendered evidence |
| `accessibility_operability_domain` | `A11Y_OPERABILITY_AUDITOR` | keyboard support, ARIA, focus, density readability, responsive behavior | a11y checklist + keyboard path + viewport matrix |
| `visual_receipt_and_regression_domain` | `VISUAL_PROOF_AUDITOR` | screenshot/DOM/a11y evidence, before/after validation, regression fixtures | observation packet + diagnosis receipt + before/after state |
| `ui_settlement_domain` | `UI_SETTLEMENT_STEWARD` | fan-in of UI branches, acceptance classification, merge proposals, receipt issuance | settlement note + accepted/deferred/rejected changes + next packet |

## Agents

### UI_CANON_LIBRARIAN

**Role:** Classifies UI canon sources, compresses live law, guards against stale or donor material impersonating current UI authority.

**Reads:** `UI canon bundle`, `ION carrier package active state`, `existing UI protocols`

**Writes candidate:** `canon digest`, `source ledger`, `stale/conflict notes`

**Must not:** declare acceptance without Steward, dump full canon into every worker package

### ION_WORK_SURFACE_ARCHITECT

**Role:** Maps ION workflow state into cockpit surfaces: claim lane, receipt rail, context graph, mission dispatch, reactive stream.

**Reads:** `V55 UI work-surface projection protocol`, `JOC five-zone architecture`, `current workflow object schemas`

**Writes candidate:** `surface blueprint`, `state-to-UI projection contract`, `layout obligations`

### VISUAL_INSTRUMENT_DESIGNER

**Role:** Turns abstract parameters and workflow states into visual authoring instruments with direct manipulation.

**Reads:** `OPUS visual canon digest`, `target domain model`, `reference editor`

**Writes candidate:** `vision-first handoff`, `instrument spec`, `interaction model`, `ROM zones`

### INTERACTION_MATERIAL_PHYSICIST

**Role:** Designs material depth, shadows, tactile motion, input feel, and shader-like polish.

**Reads:** `uishader laws digest`, `target component spec`

**Writes candidate:** `material recipe`, `motion physics matrix`, `CSS/render notes`

### UI_IMPLEMENTATION_MASON

**Role:** Builds the component/surface from the focused context package.

**Reads:** `instrument spec`, `component contract`, `1-2 reference files`

**Writes candidate:** `code patch proposal`, `tests`, `usage examples`, `proof notes`

**Must begin with:** `### CONTEXT PROOF`

### A11Y_OPERABILITY_AUDITOR

**Role:** Verifies operability under keyboard, screen reader, focus, responsive density, and no-mouse constraints.

**Reads:** `component implementation`, `interaction spec`

**Writes candidate:** `accessibility proof packet`, `operability blockers`

### VISUAL_PROOF_AUDITOR

**Role:** Captures and classifies rendered truth; blocks unsupported 'looks fixed' claims.

**Reads:** `screenshot/DOM/console evidence`, `before/after expectations`

**Writes candidate:** `visual observation packet`, `diagnosis receipt`, `before/after verification`

### UI_SETTLEMENT_STEWARD

**Role:** Settles UI branch returns and decides what can be proposed for acceptance.

**Reads:** `all branch returns`, `proof packets`, `non-authority boundaries`

**Writes candidate:** `settlement receipt draft`, `next packet`, `defer/escalate flags`

## Operating rule

Every UI work packet must start by choosing the narrowest agent/domain route, loading the bounded context package, and returning proof. The default failure mode to prevent is “generic coder sees UI task and makes a pretty panel without state, proof, accessibility, rendered evidence, or canon fidelity.”
