# Router Index

This package converts ION Custom GPT behavior into a short global router plus branch-specific instruction files.

## Paste into GPT Builder Instructions

`00_PASTE_MAIN_GLOBAL_INSTRUCTIONS_UNDER_8000_CHARS.txt`

Character count is recorded in `00_MAIN_GLOBAL_INSTRUCTIONS_WITH_NOTES.md`.

## Branch files

| Branch | File | Use for |
|---|---|---|
| 00 | `04_BRANCH_INSTRUCTIONS/BRANCH_00_CORE_DOCTRINE_AND_CONTEXT_ENGINEERING.md` | ION doctrine, context engineering, continuity architecture |
| 01 | `BRANCH_01_CUSTOM_GPT_SANDBOX_CARRIER_PACKAGE.md` | Custom GPT sandbox package and old 8K kernel |
| 02 | `BRANCH_02_ION_FULL_DEVELOPMENT_REPO.md` | Full ION repo, protocols, registries, kernel, templates |
| 03 | `BRANCH_03_EXTENSION_ACTION_GATEWAY_CONNECTORS.md` | Extension, Action Gateway, MCP, YAML bridge, connector lane |
| 04 | `BRANCH_04_AGENT_FRAMEWORK_RESEARCH.md` | agent-framework comparison and research prototypes |
| 05 | `BRANCH_05_ATLAS_EXTERNAL_SYSTEMS_REFERENCE.md` | external systems reference and evidence-tiered comparison |
| 06 | `BRANCH_06_AIM_ION_AIM_OS_LINEAGE.md` | AIM-ION/AIM-OS/Aether lineage and donor materials |
| 07 | `BRANCH_07_DAIMON_PACKAGES.md` | dAimon and dAimon-ION prototype/candidate packages |
| 08 | `BRANCH_08_UI_JOC_OPUS_CANON.md` | UI/JOC/OPUS visual canon |

## Index files

| Index | Purpose |
|---|---|
| `05_INDEXES/UPLOADED_ARTIFACT_INDEX.md` | top-level uploaded file use and authority |
| `05_INDEXES/HOT_FILE_INDEX.md` | first files to retrieve inside archives |
| `05_INDEXES/ARCHIVE_TREE_OVERVIEW.md` | folder-level route map |
| `05_INDEXES/FOLDER_SUMMARY_INDEX.csv` | machine-readable folder counts and role guesses |
| `05_INDEXES/ALL_ARCHIVE_FILE_INDEX_FILTERED.csv` | filtered internal file index excluding common noise |
| `05_INDEXES/BRANCH_ROUTER_MAP.json` | machine-readable branch route map |

## Runtime rule

The GPT should not try to “remember everything.” It should select the relevant branch, hydrate the minimum context, act, and leave proof/next-route/continuity output for serious work.
