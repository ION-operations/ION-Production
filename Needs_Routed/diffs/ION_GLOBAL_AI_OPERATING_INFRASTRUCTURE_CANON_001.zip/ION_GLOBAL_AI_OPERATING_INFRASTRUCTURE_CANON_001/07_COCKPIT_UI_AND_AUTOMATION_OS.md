# 07 — ION Cockpit UI and Automation OS

The UI must show the living system, not just logs.

## Core screens

```text
Project Overview
Agent Graph
Codex Sessions
Branch Capsules
Packet Board
Automation Timeline
Git / Commit Board
Receipt Ledger
Settlement Queue
Drift / Consistency Console
Service Health
Drive Mirror Status
Slack / Comms Feed
dAimon / Google Lane
Supabase Runtime DB
```

## Agent graph

Nodes:

```text
agent
carrier
Codex session
branch capsule
work packet
receipt
git commit
settlement item
service
external app
```

Edges:

```text
mounted
spawned
delegated_to
returned
blocked_by
superseded
depends_on
settled_into
mirrored_to
```

## Drift console

Detect and display:

```text
stale context
stale index
dirty working tree
wrong mounted branch
write-scope collision
unsettled candidate work
blocked proof return
duplicate queue packet
port/routing mismatch
Drive mirror stale
Supabase mirror lag
Slack decision unresolved
Git push mismatch
```

## Automation events

Every system action should become an event:

```text
carrier_mounted
context_loaded
packet_created
worker_spawned
tool_called
patch_previewed
patch_applied
test_run
receipt_written
commit_created
push_completed
drive_mirror_synced
slack_notification_sent
drift_detected
settlement_requested
```

## UI canon

The cockpit should be dense and operational, not a generic dashboard. It should show truth, proof, drift, authority, and next action.
