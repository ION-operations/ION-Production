# Codex Prompt — PCKT-ION-NEEDS-ROUTED-LANE-CONSOLIDATION-001

You are CODEX_LOCAL_ION_MASON.

Goal: apply and validate SEV's Needs_Routed lane consolidation patch.

Patch:

```text
SEV_NEEDS_ROUTED_LANE_CONSOLIDATION_PHASE4_INCREMENTAL_20260513.patch
```

Rules:

- Do not stage, commit, push, apply patches from Needs_Routed, extract bundles, apply Supabase migrations, mirror to Drive, or promote raw Codex context.
- This packet only installs a read-only/candidate routing surface for Needs_Routed/diffs/workpackets.
- Treat the output as candidate routing evidence, not accepted ION state.

Run:

```bash
git apply SEV_NEEDS_ROUTED_LANE_CONSOLIDATION_PHASE4_INCREMENTAL_20260513.patch

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=ION/04_packages PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest \
  ION/tests/test_kernel_ion_needs_routed_lane_consolidation.py \
  ION/tests/test_kernel_ion_codex_carrier_os.py \
  ION/tests/test_kernel_ion_mcp_local_bridge.py \
  ION/tests/test_kernel_ion_codex_source_bundle_stage_review.py \
  ION/tests/test_kernel_ion_codex_commit_boundary_audit.py -q

git diff --check

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=ION/04_packages python3 -S -m kernel.ion_needs_routed_lane_consolidation \
  --ion-root . \
  --write \
  --confirmation ION_NEEDS_ROUTED_LANE_CONSOLIDATION_WRITE_CONFIRMED \
  --json
```

Return:

### CONTEXT PROOF
### TEMPLATE ACTION PROOF
### GENERATED REFS
### LANE CONSOLIDATION RESULT
### VALIDATION
### NEXT PACKET RECOMMENDATION
### NON-CLAIMS
