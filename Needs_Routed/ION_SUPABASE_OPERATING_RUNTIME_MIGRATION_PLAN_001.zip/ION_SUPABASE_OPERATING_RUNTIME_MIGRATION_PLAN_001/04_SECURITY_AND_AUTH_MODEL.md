# Security And Auth Model

## Default Mode

Start development-scoped and read-only.

Supabase MCP should be configured:

- project-scoped;
- read-only when pointed at any real data;
- feature groups restricted;
- dev branch/project preferred.

## RLS

Supabase Row Level Security is the authorization layer for user-facing cockpit reads.

Development policy may allow broad reads for a local-only dev project, but production policy should segment by:

- workspace;
- user;
- role;
- carrier;
- visibility class.

## Never Store By Default

- secrets;
- API keys;
- raw `.env`;
- hidden chain-of-thought;
- unredacted private logs;
- full private files unless classified;
- unfiltered user documents;
- raw provider tokens.

## Write Path

Preferred write path:

```text
ION local receipt
→ local validation
→ event mirror write to Supabase
```

Do not let Supabase be first writer for authoritative ION state.

## Authority Classes

- `read_only_dashboard`
- `operator_review`
- `local_dev_mirror`
- `service_writer`
- `admin_migration`
- `production_read`
- `production_write` (future, gated)
