# 04 — Codex Carrier Operating System

Codex CLI/App is not just a terminal helper. It is a local execution carrier with native sessions, memories, hooks, worktrees, app-server/remote operation, subagents, MCP, Git functionality, and UI/app surfaces.

## Codex should become

```text
local implementation engine
session/memory carrier
agent/subagent runtime
Git and test operator
local app/cockpit contributor
```

## ION must provide

```text
mount receipts
branch capsule sync
rolling context sync
write scope
current packet
receipts
settlement target
domain routing
cockpit visibility
```

## Session and memory law

```text
Codex session memory = useful working continuity.
ION branch capsule = durable governed continuity.
ION settlement = accepted inheritance.
```

Codex memory should help Codex continue work, but ION decides what is durable and accepted.

## Required infrastructure

- Codex session registry.
- Codex agent/domain registry.
- Codex branch capsule sync.
- Codex hook enforcement.
- Codex slash command pack.
- Codex cockpit/app-server integration.
- Codex worktree and automation mapping.
- Codex Git orchestration bridge.

## Domain agents

Potential Codex domains:

```text
codex_local_ion_mason
codex_git_orchestration_steward
codex_runtime_cartographer
codex_branch_capsule_architect
codex_ui_joc_opus_canonist
codex_daimon_bridge_specialist
codex_proof_nemesis
```

These should map to Codex native agents/subagents where available and to ION branch capsules for durable state.
