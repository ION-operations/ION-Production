# PCKT-ION-JOC-LIVING-GRAPH-BROWSER-CAPTURE-004

## Packet

- Packet ID: `PCKT-ION-JOC-LIVING-GRAPH-BROWSER-CAPTURE-004`
- Status: `CANDIDATE_PATCH_READY_FOR_LOCAL_REVIEW`
- Branch posture: candidate UI/JOC evolution after packets 001 → 002 → 003
- Acceptance posture: not accepted ION state
- Production authority: false
- Live telemetry authority: false
- Action/MCP mutation authority: false
- Queue worker authority: false

## Objective

Add actual local browser-proof readiness for the Living Operational Graph route without claiming live state.

This packet converts packet 003's fixture manifest into a reusable local browser capture harness and fixes two issues discovered during proof:

1. dense same-domain SVG nodes could collide and make arbitrary click targets unreliable;
2. the graph route initially produced browser-body vertical scroll, violating the no-monolith JOC shell law.

## Patch

Candidate patch:

```text
ion_joc_living_graph_browser_capture_004.diff
```

Patch stat:

```text
.../kernel/ion_living_graph_view_model.py          |   67 +++
 .../kernel/ion_living_graph_visual_proof.py        |    5 
 .../kernel/ion_living_graph_browser_capture.py     |  418 ++++++++++++++++++++
 .../LivingGraphWorkbenchPanel.tsx                  |    9 
 .../joc_cockpit_shell/ionRuntimeCockpitTypes.ts    |    1 
 ION/08_ui/joc_cockpit_shell/joc-cockpit.css        |   19 +
 .../joc_cockpit_shell/ion-runtime-cockpit.css      |   19 +
 .../test_kernel_ion_living_graph_view_model.py     |    7 
 8 files changed, 535 insertions(+), 10 deletions(-)
```

Changed source files:

```text
ION/04_packages/kernel/ion_living_graph_view_model.py
ION/04_packages/kernel/ion_living_graph_visual_proof.py
ION/04_packages/kernel/ion_living_graph_browser_capture.py
ION/08_ui/joc_cockpit_shell/LivingGraphWorkbenchPanel.tsx
ION/08_ui/joc_cockpit_shell/ionRuntimeCockpitTypes.ts
ION/08_ui/joc_cockpit_shell/joc-cockpit.css
ION/08_ui/joc_cockpit_shell/ion-runtime-cockpit.css
ION/tests/test_kernel_ion_living_graph_view_model.py
```

## What changed

### 1. Deterministic graph hit-target relief

`ion_living_graph_view_model.py` now emits `screen_point` for each visible node. This preserves the source `position` while adding small deterministic layer/collision offsets for the cockpit SVG.

Reason: browser proof found SVG nodes could overlap densely enough that a pointer click on one node could be intercepted by another painted node.

### 2. React graph workbench uses projected screen points

`LivingGraphWorkbenchPanel.tsx` now prefers `node.screen_point` when rendering the SVG and exposes:

```text
data-proof-fixture="graph-selected-object"
```

for selected-object browser proof.

### 3. Static visual proof aligns with screen points

`ion_living_graph_visual_proof.py` now uses projected `screen_point` coordinates when drawing the static proof SVG.

### 4. Browser capture harness

New module:

```text
ION/04_packages/kernel/ion_living_graph_browser_capture.py
```

It:

- builds the React/Vite shell;
- creates an inline browser fixture;
- injects `/model.json` through a fetch override;
- launches Chromium through Playwright;
- captures route screenshot, selected-node screenshot, DOM snapshot, and metrics;
- runs keyboard search focus and keyboard node selection;
- opens the relationship inspector;
- writes a candidate capture result.

The inline fixture exists because this sandbox blocks Chromium loopback navigation with `net::ERR_BLOCKED_BY_ADMINISTRATOR`; local Codex may still use loopback, but inline mode is safer and avoids network claims.

### 5. No-monolith shell fix

`joc-cockpit.css` and `ion-runtime-cockpit.css` now constrain the JOC shell to viewport height with page-local/internal scrolling. The browser proof result shows:

```text
body_scroll_height: 1000
viewport_height: 1000
body_scroll_width: 1600
viewport_width: 1600
```

## Validation

Patch chain from fresh `ION_CODEX FULL3` snapshot:

```text
001 apply: passed
002 apply: passed
003 apply: passed
004 apply: passed
```

Targeted pytest:

```text
18 passed
```

Python compile:

```text
passed
```

Static visual proof:

```text
candidate_visual_static_pass
```

Browser capture:

```text
candidate_browser_capture_pass
```

Browser capture gates:

```json
{
  "full_graph_nodes_rendered": true,
  "graph_viewport_present": true,
  "keyboard_node_selection": true,
  "keyboard_search_focus": true,
  "no_body_horizontal_monolith": true,
  "no_body_vertical_monolith": true,
  "no_page_errors": true,
  "required_fixtures_present": true,
  "required_zones_present": true,
  "right_inspector_present": true,
  "timeline_events_rendered": true
}
```

Screenshots:

```text
BROWSER_CAPTURE_GRAPH_ROUTE_004.png: [1600, 1000]
BROWSER_CAPTURE_GRAPH_ROUTE_SELECTED_NODE_004.png: [1600, 1000]
```

## Local apply route

Apply after packets 001, 002, and 003:

```bash
git apply ion_joc_living_graph_view_model_panel_001.diff
git apply ion_joc_living_graph_source_mount_visual_proof_002.diff
git apply ion_joc_living_graph_browser_proof_interaction_003.diff
git apply ion_joc_living_graph_browser_capture_004.diff
```

Validate:

```bash
PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH=ION/04_packages \
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 \
python3 -m pytest -q \
  ION/tests/test_kernel_ion_living_graph_view_model.py \
  ION/tests/test_kernel_ion_cockpit_view_model.py \
  ION/tests/test_kernel_ion_local_cockpit_app.py

python3 -m py_compile \
  ION/04_packages/kernel/ion_living_graph_view_model.py \
  ION/04_packages/kernel/ion_living_graph_visual_proof.py \
  ION/04_packages/kernel/ion_living_graph_browser_capture.py

PYTHONPATH=ION/04_packages \
python3 -m kernel.ion_living_graph_visual_proof --root . --write

PYTHONPATH=ION/04_packages \
python3 -m kernel.ion_living_graph_browser_capture --root . --write --json
```

## Non-claims

- No accepted UI state.
- No production deployment.
- No git push.
- No live telemetry.
- No live Action/MCP mutation.
- No queue workers.
- Browser capture is candidate visual proof only.

## Next packet

Recommended next evolution:

```text
PCKT-ION-JOC-LIVING-GRAPH-R3F-TERRITORY-MAP-005
```

Scope:

- introduce a contained R3F/3D territory renderer or a dependency-free staged 2.5D renderer;
- keep the current browser capture harness as the proof gate;
- add heat/traffic overlays for proof gates, receipts, branches, Codex sessions, duplicate queue status, and settlement paths;
- require screenshot proof and no-monolith gates before any acceptance recommendation.
