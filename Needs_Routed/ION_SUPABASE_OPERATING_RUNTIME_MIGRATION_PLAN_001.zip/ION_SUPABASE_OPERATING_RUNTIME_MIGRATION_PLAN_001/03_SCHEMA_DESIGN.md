# Schema Design

## Naming

Use schema `ion_ops` for operational mirror tables.

All rows should include:

- `id uuid primary key`
- `created_at timestamptz not null default now()`
- `source_system text not null`
- `source_path text`
- `source_sha256 text`
- `source_posture text`
- `accepted_state_claim boolean not null default false`
- `payload jsonb not null default '{}'::jsonb`

## Phase 1 Tables

### automation_events

General event stream.

Fields:

- `event_type text not null`
- `event_family text`
- `agent_tag text`
- `carrier_id text`
- `branch_id text`
- `context_instance_id text`
- `packet_id text`
- `severity text default 'info'`
- `status text default 'observed'`
- `source_path text`
- `source_sha256 text`
- `payload jsonb`

Suggested event types:

- `carrier_mounted`
- `codex_session_started`
- `branch_capsule_synced`
- `work_packet_created`
- `tool_call_started`
- `tool_call_completed`
- `patch_previewed`
- `patch_applied`
- `test_run`
- `commit_created`
- `push_completed`
- `receipt_written`
- `drift_detected`
- `settlement_requested`
- `service_health_changed`
- `daimon_trace_received`
- `slack_message_received`
- `github_event_received`

### carrier_mount_receipts

Index of mount receipts.

Fields:

- `agent_tag text`
- `carrier_type text`
- `carrier_instance_id text`
- `context_instance_id text not null`
- `branch_id text`
- `current_packet text`
- `authority jsonb`
- `loaded_refs jsonb`
- `source_posture jsonb`
- `return_target jsonb`
- `persona_presentation jsonb`
- `receipt_path text`
- `receipt_sha256 text`

### service_health_snapshots

Point-in-time service state.

Fields:

- `service_name text not null`
- `service_type text`
- `host text`
- `port integer`
- `status text`
- `verdict text`
- `pid integer`
- `checked_by text`
- `details jsonb`

## Phase 2 Tables

- `codex_sessions`
- `branch_capsules`
- `work_packets`
- `receipts_index`
- `drift_findings`
- `git_events`
- `settlement_items`

## Phase 3 Tables

- `daimon_traces`
- `slack_events`
- `github_events`
- `drive_exports`
- `artifact_index`
- `template_evolution_signals`
- `wisdomnet_structural_signals`
- `atlas_system_signals`

## Source Posture Enum

Use text initially, later a Postgres enum:

- `accepted`
- `candidate`
- `runtime_evidence`
- `witness`
- `archive_witness`
- `stale_index`
- `external_observed`
- `inferred`

## Settlement Status Enum

- `candidate`
- `accepted`
- `rejected`
- `deferred`
- `superseded`
- `blocked`
- `witness_only`
