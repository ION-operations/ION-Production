# PCKT-ION-WORKPACKETS-DIFFS-INGEST-002

generated_at: 2026-05-10T23:43:38.236352-04:00
status: CANDIDATE_PACKET
posture: CONSERVATIVE
authority: sandbox/local read-only inspection; derived report writes only

## Objective

Upgrade the first index-derived ingestion bundle into a **content-proven local scan** of the actual local folders:

```text
ION_CODEX FULL/workpackets/
ION_CODEX FULL/diffs/
```

This packet must not apply any patch, mutate source files, invoke live connectors, or promote candidate material to accepted state.

## Why this is the correct next step

The first bundle established an index-derived registry and settlement plan. The operator reports that the bundle has been saved into the local PC workflow folder. The next lawful step is to compare the control artifact against the real local folders and produce content-level proof: hashes, modified times, diff affected paths, ZIP manifests, text headings, packet IDs, references, domain guesses, risk classes, and settlement queue entries.

## Inputs

Required:

- local `ION_CODEX FULL` root
- local `ION_CODEX FULL/workpackets/`
- local `ION_CODEX FULL/diffs/`

Optional but recommended:

- `ion_workpackets_diffs_ingestion_20260510T232520.zip`
- this packet folder: `ion_workpackets_diffs_ingestion_002_20260510T234208`

## Execution

Use:

```bash
python ion_local_workpackets_diffs_ingest.py \
  --ion-root "/path/to/ION_CODEX FULL" \
  --candidate-bundle "/path/to/ion_workpackets_diffs_ingestion_20260510T232520.zip" \
  --output "./local_content_proof_out"
```

Windows PowerShell example:

```powershell
python .\ion_local_workpackets_diffs_ingest.py `
  --ion-root "C:\path\to\ION_CODEX FULL" `
  --candidate-bundle "C:\path\to\workflow\ion_workpackets_diffs_ingestion_20260510T232520.zip" `
  --output "C:\path\to\workflow\local_content_proof_out"
```

## Required outputs

The local scan should produce:

```text
CONTENT_PROOF_MANIFEST.json
WORKPACKET_REGISTRY_CONTENT_PROVEN.json
WORKPACKET_REGISTRY_CONTENT_PROVEN.csv
DIFF_REGISTRY_CONTENT_PROVEN.json
DIFF_REGISTRY_CONTENT_PROVEN.csv
WORKPACKET_DIFF_LINKS_CONTENT_PROVEN.json
SETTLEMENT_QUEUE_CONTENT_PROVEN.json
SETTLEMENT_QUEUE_CONTENT_PROVEN.csv
LOCAL_CONTENT_PROOF_REPORT.md
ORPHAN_WORKPACKETS_REPORT.md
ORPHAN_DIFFS_REPORT.md
LOCAL_INGEST_RECEIPT_DRAFT.md
```

## Acceptance boundary

The output of this packet is **not accepted state**. It is admissible evidence for settlement.

A later Steward/human settlement must decide:

```text
ACCEPTED_AS_IS
MERGE_PROPOSAL_REQUIRED
ESCALATE_REVIEW
DEFERRED
ABANDONED
```

## Non-claims

- This packet does not prove local folder contents until the local script is run.
- This packet does not approve any workpacket.
- This packet does not apply any diff.
- This packet does not change ION source authority.
- This packet does not invoke connectors, GitHub, daemon, browser extension, or Codex worker.
