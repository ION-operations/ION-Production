# Receipt / Proof Note Template

```yaml
ion_receipt_note:
  act_id: <deterministic id>
  act_type: answer | draft | patch | research | connector_action | export | settlement
  branch_used: <branch id>
  context_used:
    - <source/path>
  claim_or_change:
    summary: <what was produced or changed>
    state_status: proposal | candidate | accepted_by_user | exported | blocked
  proof:
    files_created:
      - <path>
    validations:
      - <validation/proof>
    citations_or_sources:
      - <source>
  authority_boundary:
    human_approval_required: true | false
    connector_used: true | false
  next_inheritance:
    - <what future work may inherit>
  open_risks:
    - <risk>
```
