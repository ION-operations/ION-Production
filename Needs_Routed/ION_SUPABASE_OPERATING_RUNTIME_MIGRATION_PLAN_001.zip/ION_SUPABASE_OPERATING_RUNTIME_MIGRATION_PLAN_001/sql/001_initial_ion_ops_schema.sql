-- ION Supabase Operating Runtime - Initial Schema
-- Status: candidate migration.
-- Do not apply to production without review.

create schema if not exists ion_ops;

create table if not exists ion_ops.automation_events (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  event_type text not null,
  event_family text,
  agent_tag text,
  carrier_id text,
  branch_id text,
  context_instance_id text,
  packet_id text,
  severity text not null default 'info',
  status text not null default 'observed',
  source_system text not null default 'ion_local',
  source_path text,
  source_sha256 text,
  source_posture text not null default 'runtime_evidence',
  accepted_state_claim boolean not null default false,
  payload jsonb not null default '{}'::jsonb
);

create table if not exists ion_ops.carrier_mount_receipts (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  agent_tag text,
  carrier_type text,
  carrier_instance_id text,
  context_instance_id text not null,
  branch_id text,
  current_packet text,
  authority jsonb not null default '{}'::jsonb,
  loaded_refs jsonb not null default '[]'::jsonb,
  source_posture jsonb not null default '{}'::jsonb,
  return_target jsonb not null default '{}'::jsonb,
  persona_presentation jsonb not null default '{}'::jsonb,
  source_system text not null default 'ion_local',
  source_path text,
  source_sha256 text,
  source_posture_class text not null default 'runtime_evidence',
  accepted_state_claim boolean not null default false,
  payload jsonb not null default '{}'::jsonb
);

create table if not exists ion_ops.service_health_snapshots (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  service_name text not null,
  service_type text,
  host text,
  port integer,
  status text,
  verdict text,
  pid integer,
  checked_by text,
  source_system text not null default 'ion_local',
  source_path text,
  source_sha256 text,
  source_posture text not null default 'runtime_evidence',
  accepted_state_claim boolean not null default false,
  details jsonb not null default '{}'::jsonb
);

create index if not exists automation_events_created_at_idx on ion_ops.automation_events (created_at desc);
create index if not exists automation_events_type_idx on ion_ops.automation_events (event_type);
create index if not exists automation_events_branch_idx on ion_ops.automation_events (branch_id);
create index if not exists automation_events_context_idx on ion_ops.automation_events (context_instance_id);

create index if not exists carrier_mount_receipts_agent_idx on ion_ops.carrier_mount_receipts (agent_tag);
create index if not exists carrier_mount_receipts_context_idx on ion_ops.carrier_mount_receipts (context_instance_id);
create index if not exists carrier_mount_receipts_branch_idx on ion_ops.carrier_mount_receipts (branch_id);

create index if not exists service_health_snapshots_service_idx on ion_ops.service_health_snapshots (service_name, created_at desc);

alter table ion_ops.automation_events enable row level security;
alter table ion_ops.carrier_mount_receipts enable row level security;
alter table ion_ops.service_health_snapshots enable row level security;

-- Development-only read policy placeholder.
-- Replace with real auth.uid()/claims policy before user-facing deployment.
create policy if not exists "ion_ops_read_all_dev"
on ion_ops.automation_events
for select
using (true);

create policy if not exists "ion_mount_read_all_dev"
on ion_ops.carrier_mount_receipts
for select
using (true);

create policy if not exists "ion_health_read_all_dev"
on ion_ops.service_health_snapshots
for select
using (true);
