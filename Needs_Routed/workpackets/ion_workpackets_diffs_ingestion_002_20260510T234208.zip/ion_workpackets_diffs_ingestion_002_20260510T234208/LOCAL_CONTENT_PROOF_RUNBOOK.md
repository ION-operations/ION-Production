# Local Content-Proof Runbook

generated_at: 2026-05-10T23:43:38.236352-04:00

## Purpose

Run a read-only local inspection over the real `workpackets/` and `diffs/` folders, converting the index-derived candidate plan into content-proven registries.

## Preflight

Confirm these exist locally:

```text
<ION_ROOT>/workpackets/
<ION_ROOT>/diffs/
```

Here `<ION_ROOT>` is the local `ION_CODEX FULL` folder.

## Run

```bash
python ion_local_workpackets_diffs_ingest.py --ion-root "<ION_ROOT>" --candidate-bundle "<workflow>/ion_workpackets_diffs_ingestion_20260510T232520.zip" --output "<workflow>/local_content_proof_out"
```

The script writes only to the output folder.

## What the script reads

- File paths under `workpackets/`
- File paths under `diffs/`
- Text content for readable files
- Diff hunks and affected paths for `.diff`/`.patch`
- ZIP manifests for `.zip`
- Basic binary/media metadata for image files

## What the script does not do

- It does not apply patches.
- It does not edit source files.
- It does not run project tests.
- It does not call connectors.
- It does not accept or reject candidates.
- It does not delete, move, or rename any source file.

## After run

Inspect these first:

```text
CONTENT_PROOF_MANIFEST.json
LOCAL_CONTENT_PROOF_REPORT.md
SETTLEMENT_QUEUE_CONTENT_PROVEN.csv
ORPHAN_DIFFS_REPORT.md
ORPHAN_WORKPACKETS_REPORT.md
```

Then settle by batch using `SETTLEMENT_BATCHES_v2.md`.

## Blocker handling

If the script outputs `LOCAL_INGEST_BLOCKER.json`, the folder shape was not found. Correct the `--ion-root` path so that it points directly to the folder containing both `workpackets` and `diffs`.

## Success condition

Success is not “everything is organized.” Success is:

```text
local folder contents were scanned read-only
hashes exist
diff affected paths were extracted
ZIP manifests were inspected
candidate links were generated
settlement queue exists
non-claims preserved
receipt draft produced
```
