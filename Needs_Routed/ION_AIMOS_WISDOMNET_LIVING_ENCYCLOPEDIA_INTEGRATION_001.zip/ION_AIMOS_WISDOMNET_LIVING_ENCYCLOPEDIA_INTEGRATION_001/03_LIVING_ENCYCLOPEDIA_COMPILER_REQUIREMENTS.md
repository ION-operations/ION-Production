# Living Encyclopedia Compiler Requirements

## Core principle

The living encyclopedia should not be manually authored after the fact.

It should be compiled from lawful ION operations.

```text
lawful operation
→ receipt
→ template delta
→ context delta
→ doctrine delta
→ documentation delta
→ WisdomNET signal
→ ATLAS signal
→ candidate encyclopedia patch
→ settlement
```

## Required delta fields

Every material packet should be able to emit:

```yaml
operation_result:
  what_happened:
  proof:
  touched_surfaces:
  validation:

context_delta:
  new_context_nodes:
  changed_context_nodes:
  stale_context_nodes:
  future_inheritance:

template_delta:
  template_used:
  template_gap:
  template_improvement_signal:

doctrine_delta:
  candidate_claim:
  affected_sections:
  confidence:
  settlement_required:

documentation_delta:
  short_summary:
  branch_summary:
  canon_patch:
  explainer_patch:
  cockpit_note:

wisdomnet_signal:
  structural_pattern:
  workflow_pattern:
  failure_class:
  domain_pattern:

atlas_signal:
  os_dimension:
  comparative_reference:
  platform_pattern:
```

## Documentation levels

The compiler should generate several density levels:

```text
atomic receipts
branch returns
settlement summaries
current-state capsules
domain summaries
main explainer
global canon package
full trace archive
machine-readable graph
```

## Initial implementation

The first compiler does not need to rewrite the main explainer. It should:

1. collect documentation deltas,
2. validate schema,
3. group deltas by branch/domain,
4. produce candidate patch fragments,
5. produce a settlement request,
6. produce a generated summary report.
