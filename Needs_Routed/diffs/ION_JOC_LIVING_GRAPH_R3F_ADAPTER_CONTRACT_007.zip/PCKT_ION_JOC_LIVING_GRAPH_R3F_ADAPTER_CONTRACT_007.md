# PCKT-ION-JOC-LIVING-GRAPH-R3F-ADAPTER-CONTRACT-007

Posture: **candidate patch / not accepted ION state**.

## Objective

Add a dependency-gated Three / React Three Fiber adapter contract for the ION Living Operational Graph cockpit without installing packages, importing unapproved dependencies, weakening the 006 canvas runtime, or removing the 005 SVG fallback.

## Why this packet is dependency-gated

The current `ION/08_ui/joc_cockpit_shell/package.json` declares React/Vite only. It does **not** declare:

```text
three
@react-three/fiber
```

and the extracted `node_modules` tree does not contain them. This packet therefore adds the R3F contract, dependency scan, UI disclosure, render-mode controls, proof fixtures, and tests, but it does **not** add or install dependencies.

## Patch

```text
ion_joc_living_graph_r3f_adapter_contract_007.diff
sha256: fd656ea98b4d5baae836909cbd7f95846d3984771e6880e755c8ca1df83e05d8
```

Patch stat:

```text
.../kernel/ion_living_graph_r3f_adapter.py         |  306 ++++++++++++++++++++
 .../kernel/ion_living_graph_view_model.py          |   30 ++
 .../kernel/ion_living_graph_visual_proof.py        |   17 +
 .../kernel/ion_living_graph_browser_capture.py     |   10 +
 .../LivingGraphWorkbenchPanel.tsx                  |   99 ++++++
 .../joc_cockpit_shell/ionRuntimeCockpitTypes.ts    |   51 +++
 .../joc_cockpit_shell/ion-runtime-cockpit.css      |   73 ++++-
 .../README_R3F_ADAPTER_CANDIDATE.md                |   41 +++
 .../test_kernel_ion_living_graph_view_model.py     |   40 +++
 9 files changed, 658 insertions(+), 9 deletions(-)
```

## Files changed

```text
ION/04_packages/kernel/ion_living_graph_r3f_adapter.py
ION/04_packages/kernel/ion_living_graph_view_model.py
ION/04_packages/kernel/ion_living_graph_visual_proof.py
ION/04_packages/kernel/ion_living_graph_browser_capture.py
ION/08_ui/joc_cockpit_shell/LivingGraphWorkbenchPanel.tsx
ION/08_ui/joc_cockpit_shell/ionRuntimeCockpitTypes.ts
ION/08_ui/joc_cockpit_shell/ion-runtime-cockpit.css
ION/08_ui/joc_cockpit_shell/README_R3F_ADAPTER_CANDIDATE.md
ION/tests/test_kernel_ion_living_graph_view_model.py
```

## What changed

- Added `kernel.ion_living_graph_r3f_adapter`.
- Added dependency scan for `three`, `@react-three/fiber`, and optional `@react-three/drei`.
- Added R3F adapter contract to the living graph view model.
- Added R3F candidate primitive contracts for:
  - district platform meshes
  - structure instanced meshes
  - authority road segments
  - proof traffic particles
  - runtime buffer bridge
- Added graph render mode controls:
  - hybrid
  - r3f
  - canvas
  - svg
- Added viewport R3F adapter disclosure panel.
- Added runtime inspector tab for dependency gate, primitive contract, and non-claims.
- Extended static/browser proof contracts to require R3F disclosure fixtures.
- Preserved canvas and SVG fallbacks as required proof layers.

## Full mounted graph projection after 007

```text
nodes: 64
edges: 72
events: 66
districts: 8
webgl runtime primitives: 514
r3f candidate primitives: 724
r3f missing dependencies: 2
browser proof fixtures: 14
```

## Validation

```text
py_compile: passed
targeted pytest: 21 passed
direct Vite build: passed
view model write: ready
static visual proof: candidate_visual_static_pass
browser capture: candidate_browser_capture_pass
```

`tsc --noEmit` remains blocked on existing non-packet issues in:

```text
ContextPackageInspectorPanel.tsx
DocsProjectsPackagesPanel.tsx
vite.config.ts moduleResolution
```

## Browser proof

Browser capture result:

```text
status: candidate_browser_capture_pass
r3f_adapter_status: candidate_r3f_adapter_dependency_gated
r3f_dependency_status: r3f_dependency_policy_pending
render_mode_toggle_count: 4
```

Important: this is still **candidate visual proof**, not accepted UI state.

## Apply locally after 001–006

```bash
git apply ion_joc_living_graph_view_model_panel_001.diff
git apply ion_joc_living_graph_source_mount_visual_proof_002.diff
git apply ion_joc_living_graph_browser_proof_interaction_003.diff
git apply ion_joc_living_graph_browser_capture_004.diff
git apply ion_joc_living_graph_territory_scene_005.diff
git apply ion_joc_living_graph_webgl_runtime_006.diff
git apply ion_joc_living_graph_r3f_adapter_contract_007.diff
```

## Validate locally

```bash
PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH=ION/04_packages \
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 \
python3 -m pytest -q \
  ION/tests/test_kernel_ion_living_graph_view_model.py \
  ION/tests/test_kernel_ion_cockpit_view_model.py \
  ION/tests/test_kernel_ion_local_cockpit_app.py

python3 -m py_compile \
  ION/04_packages/kernel/ion_living_graph_r3f_adapter.py \
  ION/04_packages/kernel/ion_living_graph_view_model.py \
  ION/04_packages/kernel/ion_living_graph_visual_proof.py \
  ION/04_packages/kernel/ion_living_graph_browser_capture.py

cd ION/08_ui/joc_cockpit_shell
node node_modules/vite/bin/vite.js build
cd ../../..

PYTHONPATH=ION/04_packages \
python3 -m kernel.ion_living_graph_view_model --root . --write

PYTHONPATH=ION/04_packages \
python3 -m kernel.ion_living_graph_visual_proof --root . --write

PYTHONPATH=ION/04_packages \
python3 -m kernel.ion_living_graph_browser_capture --root . --write --no-build --json
```

## Non-claims

```text
no accepted UI state
no production deployment
no git push
no dependency install
no package mutation authority
no live telemetry claim
no live Action/MCP mutation
no queue workers
no actual R3F runtime until dependencies are approved and browser-proved
```

## Recommended next packet

```text
PCKT-ION-JOC-LIVING-GRAPH-R3F-DEPENDENCY-APPROVAL-008
```

Scope:

```text
decide whether to add three + @react-three/fiber
update package policy if approved
preserve canvas/SVG fallback
add actual R3F stage only after dependency approval
prove through browser capture
```
