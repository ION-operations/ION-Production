# GPT Knowledge Uploads

Start with the strategy file:

```text
ION_GPT/gpt_builder_inputs/knowledge_uploads/UPLOAD_STRATEGY.md
```

Primary upload package:

```text
ION_EXPORTS_LOCAL/custom_gpt_sandbox_carrier/latest generated zip
```

Build it from the workspace root:

```bash
PYTHONPATH=ION_Developement/ION/04_packages python3 -m kernel.ion_custom_gpt_sandbox_package --workspace-root . --json
```

Recommended posture:

- Upload the sandbox-carrier package first.
- Also upload a full repo/workspace snapshot, but treat it as source library, not boot router.
- Upload isolated domain packages for dAimon, extension, UI canon/JOC, AIMOS/Atlas/WisdomNET, research/doctrine, and latest receipts when limits allow.
- Never upload vault/secrets, `.git`, env files, virtualenvs, node_modules, raw logs, or raw quarantine evidence.
