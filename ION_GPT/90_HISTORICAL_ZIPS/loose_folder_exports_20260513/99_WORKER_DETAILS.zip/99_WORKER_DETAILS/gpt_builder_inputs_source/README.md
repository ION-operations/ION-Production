# GPT Builder Inputs

This is the operator-facing folder for configuring the ION Custom GPT.

Use these top-level folders:

```text
instructions/
actions/
packages_to_upload/
_worker_details/
```

## 1. Instructions

Open:

```text
instructions/CURRENT_INSTRUCTIONS_TO_PASTE.md
```

Paste that into the Custom GPT Instructions box.

## 2. Actions

Open:

```text
actions/
```

There are currently two Action schemas:

```text
actions/ion-actions.helixion.net/SCHEMA_TO_PASTE.yaml
actions/ion.helixion.net_mcp/SCHEMA_TO_PASTE.yaml
```

## 3. Packages to upload

Open:

```text
packages_to_upload/UPLOAD_STRATEGY.md
```

Generated zip files are local-only under:

```text
ION_EXPORTS_LOCAL/
```

## 4. Worker details

Worker/reference material lives in:

```text
_worker_details/
```

This is not the normal user path.
