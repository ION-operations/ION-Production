# Migration Phases

## Phase 0 — Cartography

- Audit whether any Supabase code/config already exists.
- Identify project credentials without printing them.
- Decide dev project vs production project.
- Confirm MCP availability.
- Confirm local CLI availability.

## Phase 1 — Schema Prototype

- Add SQL migrations under `supabase/migrations/`.
- Add schema docs and tests.
- Run locally or in dev Supabase branch only.
- Tables: automation_events, carrier_mount_receipts, service_health_snapshots.

## Phase 2 — Local Event Exporter

- Add `ion_supabase_event_mirror.py`.
- Reads local receipt/event objects.
- Inserts into Supabase only after local receipt exists.
- Supports dry-run JSON output.

## Phase 3 — Cockpit Read Model

- Query Supabase for dashboard cards:
  - latest service health;
  - latest mounts;
  - event timeline;
  - open drift.
- Add API/read layer or direct Supabase client.

## Phase 4 — Realtime Cockpit

- Subscribe to automation_events changes.
- Subscribe to service health changes.
- Add live agent/session graph.

## Phase 5 — Carrier Adapters

- GitHub/GitLab events.
- Slack events.
- dAimon trace events.
- Codex session events.
- Drive mirror events.

## Phase 6 — Production Hardening

- RLS policies.
- Auth roles.
- tenant/workspace model.
- retention/archive.
- migration promotion path.
- backups and export.
