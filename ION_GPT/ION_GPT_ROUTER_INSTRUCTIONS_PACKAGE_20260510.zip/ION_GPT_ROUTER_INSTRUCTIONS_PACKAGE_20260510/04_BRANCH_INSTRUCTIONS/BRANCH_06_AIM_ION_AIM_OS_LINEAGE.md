# Branch 06 — AIM-ION / AIM-OS / Aether Lineage

## Bound artifact

`AIM-ION.zip`

## Purpose

This branch contains AIM-OS/Aether lineage, memory architecture, project-truth indexes, MCP/JOC materials, knowledge architecture, canon, packages, cursor add-ons, coordination, archives, and implementation history. It is a donor and lineage repository for concepts that overlap with ION.

## Use this branch for

- AIM-OS / Project Aether questions
- persistent memory and verifiable AI lineage
- Aether/JOC/MCP/Cursor addon history
- donor architecture that inspired or intersects ION
- resolving AIM-specific project truth using its own indexes
- comparing AIM-OS concepts to ION concepts
- retrieving UI/JOC or memory/MCP materials that live in AIM, not ION

## First files to inspect

- `AIM-ION/README.md` if present
- `AIM-ION/PROJECT_TRUTH/README.md`
- `AIM-ION/PROJECT_TRUTH/01_canonical_system_index.md`
- `AIM-ION/PROJECT_TRUTH/02_canonical_doc_index.md`
- `AIM-ION/knowledge_architecture/README.md`
- `AIM-ION/knowledge_architecture/MASTER_NAVIGATION_INDEX.md`
- `AIM-ION/canon/README.md`
- `AIM-ION/canon/INDEX.md`
- `AIM-ION/docs/`
- `AIM-ION/packages/`
- `AIM-ION/archive/README.md` only for historical context

## Authority posture

AIM-ION is not automatically current ION law. Use it as lineage, donor evidence, or AIM-specific current source. If current ION and AIM conflict, current ION branch authority wins for ION tasks.

## Branch output rule

Always label AIM-derived material as one of:

```text
AIM-current
AIM-archive
ION-donor
lineage witness
candidate cross-port
```
