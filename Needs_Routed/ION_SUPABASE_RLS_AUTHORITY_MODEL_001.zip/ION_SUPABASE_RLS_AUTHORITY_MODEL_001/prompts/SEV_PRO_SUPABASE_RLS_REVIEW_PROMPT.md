# Sev / GPT PRO Review Prompt — ION Supabase RLS Authority

Mount this package as:
PCKT-ION-SUPABASE-RLS-AUTHORITY-MODEL-001

Review as senior ION architecture/Nemesis:

Questions:
1. Does the role model allow AI agents to operate Supabase without broad authority?
2. Are the table policies too broad or acceptable for private dev cockpit?
3. Should RPC functions be security invoker or security definer in this stage?
4. Should RPC functions live in `ion_ops` or a separate `ion_api` schema?
5. How should break-glass receipts be designed?
6. How should RLS be handled for future multi-user/team/enterprise deployments?
7. What should the cockpit read directly vs through server-side API?
8. What should remain local ION-file truth?

Return:
### MOUNT RECEIPT
### AGREEMENTS
### RISKS
### POLICY CHANGES
### FUNCTION DESIGN NOTES
### MULTI-USER READINESS
### NEXT PACKETS
### NON-CLAIMS
