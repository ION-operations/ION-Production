# ION / dAimon Living Operational Graph Context Bundle v0.2

**Package:** `ION_LIVING_GRAPH_CONTEXT_PACKAGE_20260510_v0_2`  
**Status:** candidate context package  
**Purpose:** plan the complex UI and data model for the ION/dAimon Living Operational Graph before implementation.

This bundle refines the graph cockpit from a generic network into a multi-scale operational city:

```text
map UI mastery
+ real-time operations cockpit
+ city-builder / empire simulation viewpoint
+ n8n workflow graph
+ Obsidian knowledge graph
+ computer-chip routing geometry
+ ION domain/template/receipt law
= Living Operational Graph
```

This is not decorative UI. It is the visual operating surface for ION/dAimon.

---

## 1. Governing Doctrine

ION is a living context graph. A node is not trusted context merely because it exists. A node must carry identity, authority, lifecycle, proof, and relationship posture before it can be used as lawful context.

The graph cockpit must therefore show:

```text
what exists
what is allowed to move
what is moving now
what proof was produced
what state may inherit the result
```

The core law remains:

```text
AI output is not state.
Graph motion is not acceptance.
Visible traffic is not proof.
Receipts and settlement decide what lands.
```

---

## 2. Visual North Star

The UI should feel like:

```text
Google Maps / Apple Maps at night
+ cybernetic city model
+ RTS / city-builder simulation
+ n8n workflow editor
+ Obsidian graph
+ semiconductor routing diagram
+ live NOC/SOC cockpit
```

The user should be able to zoom from global operational topology down to exact workflow logic.

---

## 3. Multi-Scale Zoom Semantics

The graph is not one flat view. It is a multi-scale map.

### Zoom 0 — Empire / World Map

Shows the whole ION/dAimon system as a living territory.

Visible objects:

```text
domain districts
major highways
core exchanges
high-level health cards
live traffic pulses
risk heat zones
global timeline
```

Question answered:

```text
Where is the system active, blocked, risky, or healthy?
```

### Zoom 1 — City / District Map

Shows a domain as a governed district.

Visible objects:

```text
template group buildings
protocol roads
receipt checkpoints
settlement hubs
partner lanes
traffic volume
district health
```

Question answered:

```text
What work-fields exist inside this domain, and how can work move between them?
```

### Zoom 2 — Building / Template Group View

A template group is represented as a building or building cluster.

Visible objects:

```text
building identity
template family
authority level
floors/templates inside
active carriers
queue pressure
ingress/egress roads
proof requirement badges
```

Question answered:

```text
What governed workflow family is this, and what traffic is currently using it?
```

### Zoom 3 — Floor / Template View

Each template or template phase becomes a floor, room, or chamber.

Visible objects:

```text
required inputs
allowed outputs
validation gates
escalators/elevators between authority levels
local route exits
template status
```

Question answered:

```text
What does this template require and what can it produce?
```

### Zoom 4 — Room / Mermaid Workflow View

The deepest zoom opens exact Mermaid-like workflow logic.

Visible objects:

```text
step-by-step workflow
decision branches
proof gates
failure branches
receipt outputs
next-packet routes
settlement outcomes
```

Question answered:

```text
What are every possible route and exit condition inside this workflow?
```

---

## 4. The City Objects

### Domains as Districts

A domain is a governed graph region.

Visual form:

```text
neighborhood / district / territory
```

Examples:

```text
ION Codex Carrier Operations
dAimon Product Delivery
Cloud Partner Integrations
WisdomNET Federated Evolution
Receipts and Settlement
Security and Authority
```

### Template Groups as Buildings

A template group is a building complex.

Examples:

```text
Project Ingestion Building
Task Return Proof Gate Building
Carrier Execution Building
Domain Fission Building
WisdomNET Contribution Building
```

### Templates as Floors or Rooms

Templates are floors, rooms, labs, checkpoints, or chambers inside buildings.

Examples:

```text
Floor 1 — Intake
Floor 2 — Context Binding
Floor 3 — Execution
Floor 4 — Validation
Floor 5 — Settlement
Floor 6 — Receipt / Export
```

### Routes as Roads

Roads represent lawful movement, not generic relationships.

A route must encode:

```text
movement type
authority ceiling
proof requirement
allowed payloads
source / destination
state-crossing rules
```

### Carriers as Moving Units

Carriers are vehicles, agents, drones, crews, or process lights moving through routes.

Examples:

```text
ChatGPT Browser Carrier
Codex Queue Worker
Codex Capsule Agent
Gemini Agent Builder Agent
Cloud Run Backend
WisdomNET Import Worker
```

### Receipts as Checkpoints

Receipts are signed stops, checkpoints, tollbooths, customs gates, or proof stations.

### Settlement as Fan-In Junctions

Settlement is a courthouse, merge interchange, control tower, or customs authority.

---

## 5. Three Overlaid Graphs

The UI must separate three layers.

### Structural Graph

```text
what exists
```

Includes:

```text
domains
template groups
templates
agents
carriers
protocols
partner adapters
receipt ledgers
```

### Operational Graph

```text
what movement is lawful
```

Includes:

```text
routes
authority gates
allowed transitions
proof requirements
settlement paths
fan-out/fan-in structure
```

### Live Traffic Graph

```text
what is happening or happened over time
```

Includes:

```text
active packets
moving carriers
event trails
heartbeat / telemetry
queue pressure
recent receipts
blocked runs
```

---

## 6. Roadway Taxonomy

### Highway / Trunk Route

Major cross-domain movement.

Used for:

```text
domain-to-domain routes
carrier handoffs
WisdomNET import/export
```

### Template Route

Movement between template groups or template phases.

### Data Flow Route

Movement of context, evidence, or payload.

### Control Flow Route

Scheduling, dispatch, queue, and command movement.

### Receipt Flow Route

Proof and receipt movement.

### Settlement Flow Route

Branch return and fan-in.

### Integration Link

Partner or external system route.

### Restricted / Risk Route

Requires stronger proof or human approval.

---

## 7. Mermaid as Micro-Blueprint

Mermaid is not the whole graph. Mermaid is the blueprint opened at deep zoom.

Each template group may expose:

```text
macro building card
→ floor list
→ template inspector
→ Mermaid workflow blueprint
```

Mermaid diagrams can be generated from the same graph schema or stored as local workflow views.

Types:

```text
template_mermaid
domain_mermaid
packet_journey_mermaid
settlement_mermaid
wisdomnet_evolution_mermaid
cloud_ops_mermaid
```

---

## 8. Interaction Model

### Main Canvas

Pannable, zoomable city.

Possible implementation:

```text
React Three Fiber / Three.js for city and animated traffic
SVG/Canvas fallback for low-power mode
DOM overlay for panels/tooltips
```

### Left Rail

```text
layer toggles
filters
domain selectors
carrier selectors
risk toggles
sample/live data switch
```

### Top Bar

```text
system health
operations count
carriers
processes
receipts
settlements
SLA / proof health
search
```

### Right Inspector

Contextual details for selected object.

Inspector tabs:

```text
Overview
Workflow
Relationships
Proof
Receipts
Events
Metrics
Raw JSON
```

### Bottom Timeline

Replay and scrub event trails.

Tracks:

```text
carriers
processes
receipts
settlements
warnings
proof gates
```

### Mini Map

Lower-right system map.

---

## 9. Data Honesty Rules

The cockpit must distinguish:

```text
live
accepted
candidate
sample
mock
stale
blocked
unknown
```

Visual badges are mandatory for non-live or sample data.

No generated animation may imply accepted proof unless it has receipt/proof reference.

---

## 10. R3F Direction

React Three Fiber is likely the right premium-rendering path.

Suggested stack:

```text
React
React Three Fiber
Three.js
drei
zustand or jotai
zod
react-flow or mermaid for micro workflows
framer-motion for panel motion
```

Scene strategy:

```text
orthographic camera
isometric tilt
instanced buildings
curved route meshes
animated emissive particles
district floor planes
CSS2D/HTML labels
postprocessing bloom optional
```

Performance principles:

```text
instancing for buildings/vehicles
LOD by zoom level
sample thousands of nodes but render summaries at high zoom
separate data graph from render graph
progressive hydration of deep detail
```

---

## 11. Implementation Roadmap

### GRAPH_001A_VISUAL_ONTOLOGY_REFINEMENT

Update the context bundle with city/building/floor/roadway semantics.

### GRAPH_002_DATA_GENERATOR

Generate structural/event graph data from ION/dAimon artifacts.

### GRAPH_003_CITY_CANVAS_VERTICAL_SLICE

Build first city canvas with districts, buildings, roads, inspector, and timeline using sample data.

### GRAPH_004_TEMPLATE_BUILDING_DETAIL

Implement template group buildings, floors, and deep zoom.

### GRAPH_005_MERMAID_PROTOCOL_EMBED

Embed Mermaid micro-blueprints in inspector/deep zoom.

### GRAPH_006_LIVE_TRAFFIC_OVERLAY

Map queue/worker/receipt telemetry into moving traffic.

### GRAPH_007_WISDOMNET_EVOLUTION_LAYER

Add carrier/domain-pack import/export routes, trusted candidate packs, and universal/default evolution lanes.

---

## 12. Non-Claims

This bundle does not implement the final UI.

This bundle does not claim the generated visual is live.

This bundle does not claim a graph node is trusted merely because it appears.

This bundle does not grant production authority.

This bundle is a candidate planning artifact until ingested, reviewed, and accepted by ION.
