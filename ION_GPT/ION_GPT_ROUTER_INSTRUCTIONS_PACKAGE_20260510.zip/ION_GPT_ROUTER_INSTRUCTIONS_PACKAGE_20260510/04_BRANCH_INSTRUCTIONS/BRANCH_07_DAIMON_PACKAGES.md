# Branch 07 — dAimon and dAimon-ION Packages

## Bound artifacts

- `dAimon3.zip`
- `dAimon_ION3.zip`

## Purpose

This branch covers dAimon prototype/runtime materials and the dAimon-ION rapid-agent hackathon entry candidate. These packages contain agent builder surfaces, capability graph/dashboard traces, MCP contracts, orchestration, validation outputs, and candidate state manifests.

## Use this branch for

- dAimon system questions
- agent builder and clone/package generation
- capability graph and dashboard trace design
- sample inputs/outputs
- rapid agent hackathon entry materials
- governed state candidate analysis
- package validation manifest review

## First files to inspect

For `dAimon3.zip`:

- `dAimon/README.md`
- `dAimon/agent_builder/system_prompt.md`
- `dAimon/agent_builder/agent_tool_manifest.yaml`
- `dAimon/capability_graph/`
- `dAimon/orchestration/build_roadmap.json`
- `dAimon/sample_outputs/`

For `dAimon_ION3.zip`:

- `.../README.md`
- `.../MANIFEST.json`
- `.../CURRENT_STATE.json`
- `.../validation_manifest_v1_0.json`
- `.../RAH_*` reports

## Authority posture

Both packages are candidate/prototype surfaces unless current user instruction or an ION receipt settles them. Do not treat their contents as production state.

## Branch output rule

Preserve candidate posture:

```text
prototype
candidate package
validated sample
hackathon entry
requires settlement
```
