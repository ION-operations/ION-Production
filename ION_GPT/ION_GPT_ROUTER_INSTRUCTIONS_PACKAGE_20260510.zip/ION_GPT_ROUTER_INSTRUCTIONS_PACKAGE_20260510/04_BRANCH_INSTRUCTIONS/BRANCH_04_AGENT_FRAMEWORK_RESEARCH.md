# Branch 04 — Agent Framework Research Context Package

## Bound artifact

`ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7.zip`

## Purpose

This branch is a research/comparator layer for agent frameworks and ION prototypes. It includes feature extraction, source-authority policy, framework cards, comparator reports, LangGraph packet lifecycle demos, file-continuity bridge MVPs, human-in-the-loop settlement gate prototypes, adversarial continuity law tests, validation manifests, and state-surface sync reports.

## Use this branch for

- comparing ION to LangGraph, agent frameworks, wrappers, and related systems
- designing mini-ION demonstrations
- extracting framework capabilities into ION concepts
- source-authority coverage work
- testing state-surface sync patterns
- HITL settlement gate examples
- file-continuity bridge examples
- building research briefs or public comparison drafts

## First files to inspect

- `README.md`
- `source_authority_policy_v0_3.md`
- `source_authority_table_v0_3.csv/json`
- `bucketed_comparison_index_v0_4.md/csv`
- `framework_cards_index_v0_4.csv`
- latest `validation_manifest_v*.json`
- latest `state_surface_sync_report_v*.md`
- `ion_langgraph_packet_lifecycle/README.md`
- `ion_file_continuity_bridge_mvp/README.md`
- `ion_hitl_settlement_gate/README.md`

## Authority posture

Research evidence is useful but not ION constitutional law. Treat it as comparator/prototype evidence unless a current ION authority file routes to it.

## Branch output rule

When using this branch, name the evidence posture:

```text
research evidence
prototype evidence
validation evidence
candidate integration idea
not accepted ION state
```
