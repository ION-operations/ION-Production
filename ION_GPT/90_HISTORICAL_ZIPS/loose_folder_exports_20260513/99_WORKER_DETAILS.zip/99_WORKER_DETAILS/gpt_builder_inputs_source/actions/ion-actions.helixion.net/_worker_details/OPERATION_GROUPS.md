# Operation Groups

## ION core gateway

- `ionGatewayHealth`
- `ionGatewayPolicy`
- `ionGatewayContextPack`
- `ionGatewayCodexQueue`
- `ionGatewayAgentStatus`
- `ionGatewayDaimonVisibility`
- `ionGatewayReceiptsRecent`
- `ionBrowserQueueStatus`
- `ionBrowserQueueReceiptsRecent`
- `ionBrowserQueueEnqueue`
- `ionGatewayValidateAction`
- `ionGatewaySubmitAction`
- `ionGatewayAgentInvoke`
- `ionGatewayAgentRelayPending`
- `ionGatewayAgentRelayRespond`
- `ionGatewayAgentControl`
- `ionGatewayAgentReceiptsRecent`
- `ionGatewayAgentSettle`

## Supabase ion_ops cockpit

- `ionSupabaseCockpitOverview`
- `ionSupabaseRecentEvents`
- `ionSupabaseLatestServiceHealth`
- `ionSupabaseCurrentCarrierMounts`
- `ionSupabaseRecordAutomationEvent`
- `ionSupabaseRecordServiceHealth`
- `ionSupabaseRecordCarrierMount`
