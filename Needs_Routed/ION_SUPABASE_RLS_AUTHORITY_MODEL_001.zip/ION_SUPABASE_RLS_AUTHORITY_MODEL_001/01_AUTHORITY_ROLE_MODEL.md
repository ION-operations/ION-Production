# 01 — Authority Role Model

ION's Supabase authority model should be role/claim based, but should not rely on a human manually editing tables for every operation.

## Role classes

| Role | Purpose | Typical actor |
|---|---|---|
| `ion_viewer` | Read safe cockpit views | Braden, GPT/PRO via server, team member |
| `ion_operator` | Acknowledge alerts, request safe workflows | human operator / cockpit |
| `ion_agent_writer` | Insert structured operational events | ION MCP adapter, Codex service, dAimon bridge |
| `ion_steward` | Mark settlement items, approve/defer/reject candidate state | Braden / designated reviewer |
| `ion_admin` | Manage schema, roles, migrations | Braden / trusted admin / Codex with approval |
| `ion_break_glass` | Emergency repair path with special receipt | direct human admin only |

## Claim-based access

Preferred Supabase/JWT pattern:

```json
{
  "app_metadata": {
    "ion_roles": ["ion_viewer", "ion_agent_writer"]
  }
}
```

ION helper:

```sql
ion_ops.has_ion_role('ion_agent_writer')
```

A user/service may have multiple roles.

## Why not broad `authenticated` write?

`authenticated` means the user has logged in. It does not mean they are authorized to mutate ION operational state.

ION must distinguish:

```text
authenticated identity
≠ ION authority
```

## AI management model

AI agents should not hold broad database ownership. They should:

- call narrow RPC functions
- include mount receipt / source posture
- produce local ION receipt first where possible
- insert append-only evidence
- never disable RLS
- never widen policies without migration review

## Human admin variance

Admins vary in skill. ION should protect them from normal mistakes by:

- keeping core schema and permissions in Git migrations
- avoiding manual policy sprawl
- using views for cockpit read state
- using functions for writes
- keeping destructive actions rare and receipted
