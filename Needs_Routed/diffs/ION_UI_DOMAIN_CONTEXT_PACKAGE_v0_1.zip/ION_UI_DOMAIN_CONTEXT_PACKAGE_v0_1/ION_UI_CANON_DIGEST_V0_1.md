# ION UI Canon Digest v0.1

created_at: 2026-05-10T15:13:37Z  
status: candidate_digest_from_uploaded_ui_canon  
source_bundle: `_ui_canon.zip`

## Prime directive

**Never build generic slider/input settings panels for complex controls.** Build visual authoring instruments where the user manipulates the represented phenomenon or workflow state directly.

## ION-native translation

ION UI is not decoration. It is a maintained work-surface renderer for governed state: claims, receipts, routes, authority, evidence, context graph state, repair obligations, session health, and automation events must remain inspectable.

## Core invariants

- UI work starts from a vision-first handoff before implementation.
- Build one focused visual surface/component/editor at a time; protect model attention budget.
- Every complex setting maps to an interactive visual instrument, not a generic form control.
- Source-code correctness is not product correctness; rendered behavior must be observed and receipted.
- Show state as state: accepted/candidate/proposal/blocked/verified must be visually distinct.
- Use five-zone operator cockpit structure for ION/JOC surfaces: top bar, left rail, main work surface, right inspector, bottom timeline.
- Use DXL matte-black instrument-panel discipline for ION cockpit surfaces unless a specific domain skin is approved.
- No placeholder-only panel may be presented as a finished UI.
- Direct manipulation, ROM zones, live preview, accessible keyboard operation, and before/after visual proof are completion requirements.

## Universal visual editor types

- GradientEditor
- CurveEditor
- PolarEditor / CompassEditor
- HemisphereEditor
- ProfileEditor
- RangeEditor
- ColorEditor
- LayerStackEditor
- NoiseEditor
- DistributionEditor

## DXL / JOC cockpit constraints

- Matte-black instrument-panel aesthetic; dense, precise, monospace UI.
- Forbidden: emoji in actual UI controls.
- Forbidden: generic Material Design color tokens in structural UI.
- Forbidden: purple/blue structural accent drift except confined data visualization.
- Forbidden: var(--accent) for navigation or structure.
- Forbidden: instrument panel radii greater than 2px.
- Forbidden: large casual typography.
- Forbidden: placeholder-only finished surfaces.

## Visual completion gate

- direct manipulation of the actual visual representation
- ROM zones for bounded parameters
- live preview in editor and affected viewport/work surface
- physical and artistic presets where useful
- keyboard shortcuts: Shift+drag, double-click reset, arrow nudge
- ARIA labels and focus states
- complete TypeScript contracts
- documented usage examples
- integration into at least one drawer/surface
- tested propagation to simulation, viewport, or state model

## Orchestration pattern

Vision-first handoff → single focused implementation → reference-grounded build → cascade review → rendered proof/receipt.
