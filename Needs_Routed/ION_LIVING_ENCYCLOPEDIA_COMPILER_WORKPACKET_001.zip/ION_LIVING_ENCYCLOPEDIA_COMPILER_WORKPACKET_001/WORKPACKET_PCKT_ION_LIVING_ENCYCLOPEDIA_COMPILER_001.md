# PCKT-ION-LIVING-ENCYCLOPEDIA-COMPILER-001

## Status

Candidate implementation workpacket.  
Settlement required.  
Accepted-state authority: false.

## Objective

Implement the first ION Living Encyclopedia Compiler layer.

The goal is to make ION's living documentation, context packages, canon summaries, and branch continuity surfaces compile from lawful operations rather than being manually rewritten after the fact.

## Core law

```text
Templates are not only work forms.
Templates are how ION writes its own future context.

Receipts are not only logs.
Receipts are raw material for future doctrine, context, and recovery.

The living encyclopedia is not manually authored.
It is compiled from lawful movement through the context graph.
```

## Required concept

Every material ION operation should be able to produce structured deltas:

```yaml
operation_result:
  what_happened:
  proof:
  touched_surfaces:
  validation:

context_delta:
  what_future_agents_may_inherit:
  new_context_nodes:
  stale_context_nodes:
  changed_routes:

template_delta:
  template_used:
  template_gap_found:
  template_improvement_signal:

doctrine_delta:
  what_this_teaches_about_ION:
  candidate_section:
  confidence:
  settlement_required:

documentation_delta:
  short_summary:
  branch_summary:
  canon_patch:
  explainer_patch:
  cockpit_note:

wisdomnet_signal:
  reusable_structure:
  failure_pattern:
  workflow_pattern:
  domain_pattern:

atlas_signal:
  system_pattern:
  os_dimension:
  comparative_reference:
```

## Required implementation surfaces

### New protocol

`ION/02_architecture/ION_LIVING_ENCYCLOPEDIA_COMPILER_PROTOCOL_V0_1.md`

Defines:
- documentation delta law;
- compiler inputs and outputs;
- settlement relation;
- WisdomNET and ATLAS signal relation;
- generated documentation hierarchy;
- non-claims and authority boundaries.

### New registry

`ION/03_registry/ion_documentation_surfaces.yaml`

Defines:
- living encyclopedia;
- global canon;
- domain summaries;
- branch capsules;
- current-state capsules;
- cockpit notes;
- WisdomNET signal surfaces;
- ATLAS signal surfaces;
- export surfaces.

### New template registry

`ION/03_registry/ion_template_delta_registry.yaml`

Defines which template families must emit which documentation/context deltas.

### New templates

`ION/07_templates/documentation_delta/`

At minimum:
- `ION_DOCUMENTATION_DELTA_TEMPLATE_V0_1.yaml`
- `ION_WISDOMNET_SIGNAL_TEMPLATE_V0_1.yaml`
- `ION_ATLAS_SIGNAL_TEMPLATE_V0_1.yaml`
- `ION_CONTEXT_DELTA_TEMPLATE_V0_1.yaml`

### New kernel helper

`ION/04_packages/kernel/ion_living_encyclopedia_compiler.py`

Required behavior:
- read documentation delta objects from an inbox;
- validate schema;
- classify outputs by target documentation surface;
- produce compiled draft surfaces in a candidate folder;
- never overwrite accepted docs directly;
- write compile report;
- write candidate settlement packet.

### New candidate state folders

```text
ION/05_context/current/living_encyclopedia/
  inbox/
  compiled/
  reports/
  settlement_requests/
```

### Tests

`ION/tests/test_kernel_ion_living_encyclopedia_compiler.py`

Required tests:
- valid documentation delta passes;
- missing operation_result fails;
- hidden chain-of-thought exposure field is rejected if present;
- doctrine_delta with settlement_required false is rejected for canon surfaces;
- compiler produces draft output, not direct accepted-state mutation;
- WisdomNET and ATLAS signals are preserved as candidate signals;
- generated compile report is valid JSON.

## Required source reads

Before implementation, inspect:

```text
ION_Continuity_Substrate_Explainer_v8_current_ion_evolution.md, if present in repo/workpackets
ION/02_architecture/
ION/03_registry/
ION/04_packages/kernel/
ION/05_context/current/context_settlement/
ION/05_context/current/agent_context_branches/
ION/07_templates/
workpackets/
diffs/
```

Search specifically for:
- living encyclopedia;
- documentation delta;
- WisdomNET;
- ATLAS;
- context graph;
- templates;
- receipts;
- settlement;
- state-surface sync;
- continuity bridge.

## Validation

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH=ION/04_packages \
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 \
python3 -m pytest -q ION/tests/test_kernel_ion_living_encyclopedia_compiler.py
```

Also run:
- py_compile for touched Python;
- YAML parse for touched registry/template files;
- JSON parse for generated reports.

## Output required from Codex

```text
### MOUNT PROOF
### EXISTING SURFACE AUDIT
### IMPLEMENTATION RESULT
### VALIDATION
### DIFF SUMMARY
### RISKS
### BLOCKERS
### RECOMMENDED COMMIT SPLIT
### NEXT PACKET
### NON-CLAIMS
```

## Non-claims

This packet does not:
- accept any doctrine update;
- mutate the living encyclopedia directly;
- promote WisdomNET or ATLAS signals to accepted state;
- claim production readiness;
- start workers;
- use live Action/MCP mutation;
- delete evidence.
