# ION Supabase RLS / Authority Model 001

Generated: 2026-05-13T01:43:15Z

This package defines the next Supabase authority layer for ION after the initial `ion_ops` bootstrap.

Core posture:

- Supabase is an operational mirror and cockpit backend, not ION source truth.
- ION files, Git, receipts, and settlement remain truth.
- AI agents should operate through typed append-first functions and narrow policies, not broad table power.
- Human/admin variance is expected, but ordinary misconfiguration should not easily damage ION state.
- A malicious owner/admin can still sabotage any system; ION's goal is to make normal operations safe, auditable, and recoverable.

Primary outputs:

- `00_EXECUTIVE_SUMMARY.md`
- `01_AUTHORITY_ROLE_MODEL.md`
- `02_RLS_POLICY_DESIGN.md`
- `03_RPC_FUNCTIONS_AND_AI_OPERATIONS.md`
- `04_ADMIN_VARIANCE_AND_BREAK_GLASS.md`
- `05_INTEGRATION_WITH_ION_CARRIERS.md`
- `06_IMPLEMENTATION_SEQUENCE.md`
- `sql/002_dev_private_cockpit_read_policies.sql`
- `sql/003_ion_ops_authority_and_rpc.sql`
- `prompts/CODEX_SUPABASE_RLS_AUTHORITY_PROMPT.md`
- `prompts/SEV_PRO_SUPABASE_RLS_REVIEW_PROMPT.md`
