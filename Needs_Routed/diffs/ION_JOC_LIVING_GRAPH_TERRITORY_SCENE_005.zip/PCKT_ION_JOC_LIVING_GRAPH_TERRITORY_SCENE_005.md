# PCKT-ION-JOC-LIVING-GRAPH-TERRITORY-SCENE-005

Generated: 2026-05-12T14:17:42+00:00

## Posture

Candidate UI/JOC evolution patch. This packet does not claim accepted ION state, production deployment, live telemetry, live Action/MCP mutation, queue work, or Git push.

## Objective

Evolve the Living Operational Graph from a flat SVG graph workbench into a 2.5D/R3F-ready developer cockpit territory scene while keeping the existing JOC shell, static proof, and browser-capture proof gates intact.

## Patch

`ion_joc_living_graph_territory_scene_005.diff`

Patch stat:

```text
.../ion_living_graph_territory_projection.py       |  388 ++++++++++++++++++++
 .../kernel/ion_living_graph_view_model.py          |   35 ++
 .../kernel/ion_living_graph_visual_proof.py        |   24 +
 .../kernel/ion_living_graph_browser_capture.py     |   11 +
 .../LivingGraphWorkbenchPanel.tsx                  |  289 ++++++++++++---
 .../joc_cockpit_shell/ionRuntimeCockpitTypes.ts    |   95 +++++
 .../joc_cockpit_shell/ion-runtime-cockpit.css      |  171 +++++++++
 .../test_kernel_ion_living_graph_view_model.py     |   34 ++
 8 files changed, 976 insertions(+), 71 deletions(-)
```

## Files changed

```text
ION/04_packages/kernel/ion_living_graph_territory_projection.py
ION/04_packages/kernel/ion_living_graph_view_model.py
ION/04_packages/kernel/ion_living_graph_visual_proof.py
ION/04_packages/kernel/ion_living_graph_browser_capture.py
ION/08_ui/joc_cockpit_shell/LivingGraphWorkbenchPanel.tsx
ION/08_ui/joc_cockpit_shell/ionRuntimeCockpitTypes.ts
ION/08_ui/joc_cockpit_shell/ion-runtime-cockpit.css
ION/tests/test_kernel_ion_living_graph_view_model.py
```

## What changed

- Added `ion_living_graph_territory_projection.py`, a dependency-free 2.5D/R3F-ready scene projector.
- Added `territory_scene` to the Living Operational Graph view model.
- Projects:
  - domain district platforms,
  - node structures,
  - elevated authority roads,
  - timeline/proof traffic beacons,
  - R3F primitive hints,
  - territory proof contracts.
- Updated the React graph workbench to render the 2.5D scene inside the existing JOC shell.
- Added terrain inspector tab for selected-object geometry, roads, beacons, and R3F primitive hints.
- Extended static proof and browser-capture gates to verify territory fixtures.
- Kept all telemetry/data honesty labels in sample/candidate posture.

## Model proof summary

```json
{
  "elevated_structure_count": 45,
  "platform_count": 8,
  "proof_required_road_count": 48,
  "road_count": 72,
  "structure_count": 64,
  "traffic_beacon_count": 66
}
```

The mounted full sample still projects:

```text
64 structures
72 roads
66 traffic beacons
8 district platforms
```

## Validation

```text
patch apply check after 001-004: 0
py_compile: 0
targeted pytest: 0 / 18 passed
direct Vite build: 0
static visual proof: candidate_visual_static_pass
browser capture: candidate_browser_capture_pass
```

Browser gates:

```json
{
  "full_graph_nodes_rendered": true,
  "graph_viewport_present": true,
  "keyboard_node_selection": true,
  "keyboard_search_focus": true,
  "no_body_horizontal_monolith": true,
  "no_body_vertical_monolith": true,
  "no_page_errors": true,
  "required_fixtures_present": true,
  "required_zones_present": true,
  "right_inspector_present": true,
  "territory_beacons_rendered": true,
  "territory_roads_rendered": true,
  "territory_stage_present": true,
  "territory_structures_rendered": true,
  "timeline_events_rendered": true
}
```

## Apply order

```bash
git apply ion_joc_living_graph_view_model_panel_001.diff
git apply ion_joc_living_graph_source_mount_visual_proof_002.diff
git apply ion_joc_living_graph_browser_proof_interaction_003.diff
git apply ion_joc_living_graph_browser_capture_004.diff
git apply ion_joc_living_graph_territory_scene_005.diff
```

## Validation commands

```bash
PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH=ION/04_packages \
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 \
python3 -m pytest -q \
  ION/tests/test_kernel_ion_living_graph_view_model.py \
  ION/tests/test_kernel_ion_cockpit_view_model.py \
  ION/tests/test_kernel_ion_local_cockpit_app.py

python3 -m py_compile \
  ION/04_packages/kernel/ion_living_graph_territory_projection.py \
  ION/04_packages/kernel/ion_living_graph_view_model.py \
  ION/04_packages/kernel/ion_living_graph_visual_proof.py \
  ION/04_packages/kernel/ion_living_graph_browser_capture.py

cd ION/08_ui/joc_cockpit_shell
node node_modules/vite/bin/vite.js build

PYTHONPATH=ION/04_packages \
python3 -m kernel.ion_living_graph_visual_proof --root . --write

PYTHONPATH=ION/04_packages \
python3 -m kernel.ion_living_graph_browser_capture --root . --write --json
```

## Non-claims

- no accepted UI state
- no production deployment
- no git push
- no live telemetry claim
- no live Action/MCP mutation
- no queue workers
- browser capture is candidate visual proof only
- R3F-ready projection is not actual WebGL/Three.js runtime yet

## Recommended next packet

`PCKT-ION-JOC-LIVING-GRAPH-R3F-RUNTIME-006`

Scope:

- introduce the actual Three/R3F runtime or a staged equivalent only after dependency review;
- render the 005 territory primitives in WebGL/Canvas;
- preserve SVG fallback;
- update browser proof to validate both SVG fallback and R3F stage;
- do not connect live telemetry yet.
