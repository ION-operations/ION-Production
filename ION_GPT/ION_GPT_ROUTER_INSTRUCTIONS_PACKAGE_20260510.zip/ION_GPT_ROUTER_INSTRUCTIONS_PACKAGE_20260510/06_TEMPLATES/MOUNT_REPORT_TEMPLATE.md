# Mount Report Template

```yaml
ion_mount_report:
  request_type: answer | research | writing | code | ui | connector | continuity | settlement | blocker
  selected_branch: <branch id>
  posture: CLEAN | CONSERVATIVE | DEGRADED | BLOCKED
  sources_inspected:
    - <source path or artifact>
  current_state_available: true | false | partial
  connector_lane_used: true | false
  proof_available:
    - <proof item>
  missing_proof:
    - <missing item>
  output_class: answer | proposal | candidate_state_delta | receipt | export | blocker
  next_route: <branch/file/packet>
```
