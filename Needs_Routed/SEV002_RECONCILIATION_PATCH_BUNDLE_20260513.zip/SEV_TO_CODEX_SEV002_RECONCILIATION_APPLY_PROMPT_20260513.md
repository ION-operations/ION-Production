# CODEX-001 Apply Prompt — SEV-002 Reconciliation Patches

```text
packets:
  - PCKT-SEV002-B00-PY311-FSTRING-UNBLOCK-001
  - PCKT-ION-CARRIER-MOUNT-RECEIPT-MCP-PROJECTION-001
accepted_state_authority: false
production_authority: false
git_mutation_authority: false unless explicitly approved after validation
```

## Apply order

```bash
git apply SEV002_B00_PY311_FSTRING_UNBLOCK_20260513.patch

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=ION/04_packages PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest \
  ION/tests/test_kernel_ion_dual_codex_chat.py -k memory_visualization -q

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=ION/04_packages PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest \
  ION/tests --collect-only -q
```

Then apply the MCP projection patch:

```bash
git apply SEV_PHASE5_CARRIER_MOUNT_RECEIPT_MCP_INCREMENTAL_20260513.patch

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=ION/04_packages PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest \
  ION/tests/test_kernel_ion_mcp_local_bridge.py \
  ION/tests/test_kernel_ion_carrier_mount_receipt.py -q

git diff --check
```

## Optional local full-suite validation

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=ION/04_packages PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest ION/tests -q
```

## Return requested

```text
CONTEXT PROOF
PATCH APPLICATION PROOF
PYTHON VERSION
COLLECTION RESULT
TARGETED TEST RESULT
FULL SUITE RESULT OR TIMEOUT/FAILURE SUMMARY
MCP TOOL LIST CONFIRMATION FOR ion.carrier_mount.receipt and ion_carrier_mount_receipt
NON-CLAIMS
```

Do not stage, commit, push, settle, restart services, or promote raw Codex context in this packet unless separately authorized.
