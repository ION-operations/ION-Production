# Codex Prompt — PCKT-ION-LIVING-ENCYCLOPEDIA-COMPILER-001

You are CODEX_LOCAL_ION_MASON.

Active packet:
PCKT-ION-LIVING-ENCYCLOPEDIA-COMPILER-001

Goal:
Implement the first ION Living Encyclopedia Compiler foundation.

Core idea:
ION documentation should compile from lawful operations. Every material packet should emit structured deltas that can later produce the living encyclopedia, global canon, branch summaries, WisdomNET signals, ATLAS signals, cockpit notes, and context packages.

Authority:
- local repo edits allowed
- no production deployment
- no git push unless Braden approves later
- no queue workers
- no live Action/MCP mutation from ChatGPT
- no evidence deletion
- no accepted-state claim
- do not expose hidden chain-of-thought

Before editing:
Audit existing surfaces for:
- living encyclopedia
- documentation surfaces
- WisdomNET
- ATLAS
- context graph
- template registries
- receipt and settlement surfaces
- state-surface sync
- continuity bridge

Likely sources:
- ION_Continuity_Substrate_Explainer_v8_current_ion_evolution.md if present
- ION/02_architecture/
- ION/03_registry/
- ION/04_packages/kernel/
- ION/05_context/current/context_settlement/
- ION/05_context/current/agent_context_branches/
- ION/07_templates/
- workpackets/
- diffs/

Implement:
1. Protocol:
   ION/02_architecture/ION_LIVING_ENCYCLOPEDIA_COMPILER_PROTOCOL_V0_1.md

2. Registries:
   ION/03_registry/ion_documentation_surfaces.yaml
   ION/03_registry/ion_template_delta_registry.yaml

3. Templates:
   ION/07_templates/documentation_delta/ION_DOCUMENTATION_DELTA_TEMPLATE_V0_1.yaml
   ION/07_templates/documentation_delta/ION_WISDOMNET_SIGNAL_TEMPLATE_V0_1.yaml
   ION/07_templates/documentation_delta/ION_ATLAS_SIGNAL_TEMPLATE_V0_1.yaml
   ION/07_templates/documentation_delta/ION_CONTEXT_DELTA_TEMPLATE_V0_1.yaml

4. Kernel:
   ION/04_packages/kernel/ion_living_encyclopedia_compiler.py

5. Candidate folders:
   ION/05_context/current/living_encyclopedia/inbox/
   ION/05_context/current/living_encyclopedia/compiled/
   ION/05_context/current/living_encyclopedia/reports/
   ION/05_context/current/living_encyclopedia/settlement_requests/

6. Tests:
   ION/tests/test_kernel_ion_living_encyclopedia_compiler.py

Required behavior:
- validate documentation delta objects;
- reject hidden_reasoning_exposed true;
- reject accepted_state_claim true unless explicitly settled;
- preserve WisdomNET signals as structural metadata only;
- preserve ATLAS signals as comparative reference only;
- compile candidate drafts, never mutate accepted docs directly;
- write compile report JSON;
- write candidate settlement request.

Run:
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=ION/04_packages PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest -q ION/tests/test_kernel_ion_living_encyclopedia_compiler.py

Also:
- py_compile touched Python;
- YAML parse registries/templates;
- JSON parse generated reports.

Return:
### MOUNT PROOF
### EXISTING SURFACE AUDIT
### IMPLEMENTATION RESULT
### VALIDATION
### DIFF SUMMARY
### RISKS
### BLOCKERS
### RECOMMENDED COMMIT SPLIT
### NEXT PACKET
### NON-CLAIMS
