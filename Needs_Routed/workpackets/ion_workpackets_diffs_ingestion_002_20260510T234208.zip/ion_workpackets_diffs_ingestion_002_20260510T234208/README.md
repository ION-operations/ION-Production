# ION Workpackets + Diffs Ingestion Packet 002

This package continues from `ion_workpackets_diffs_ingestion_20260510T232520.zip`.

It does not apply diffs. It creates a read-only local content-proof scanner and settlement process for:

```text
ION_CODEX FULL/workpackets/
ION_CODEX FULL/diffs/
```

Start with:

1. `NEXT_PACKET_PCKT_ION_WORKPACKETS_DIFFS_INGEST_002.md`
2. `LOCAL_CONTENT_PROOF_RUNBOOK.md`
3. `ion_local_workpackets_diffs_ingest.py`
4. `SETTLEMENT_BATCHES_v2.md`
5. `ACCEPTANCE_AND_NON_PROMOTION_RULES.md`

The `seed_index_derived_bundle_001/` folder preserves the first candidate registry bundle as control evidence.
