# Workpackets, Diffs, and Current Branch Priorities

## Source-lane posture

`diffs/` and `workpackets/` are source-lane candidate evidence, not automatically accepted state.

The repo has been described by ION PRO and local audits as candidate-rich/conflict-prone. The main risk is not lack of code, but unsettled overlapping candidate work being mistaken for landed state.

## Important candidate diff/workpacket families

### Bootstrap Action/MCP repair stack

Already pushed or locally verified:

```text
ion_action_idempotency_no_receipt_repair_001
ion_direct_bounded_patch_lane_002
ion_codex_queue_duplicate_cleanup_003
ion_bounded_patch_apply_mcp_confirmation_fix_004
```

Status: functionally proven and pushed, with bounded patch apply smoke passing.

### Branch-capsule stack

Candidate evidence:

```text
agent_branch_capsule_runtime_001.diff
agent_branch_capsule_bootstrap_002.diff
agent_branch_capsule_guard_003.diff
agent_branch_capsule_settlement_intake_004.diff
agent_branch_capsule_reconciliation_005.diff
```

Codex reported local consolidation into:

```text
agent_branch_capsule_consolidated_006
PCKT-ION-BRANCH-CAPSULE-CONSOLIDATION-006
```

Status: treat as local candidate until commit/push proof.

### Extension selected request start repair

Candidate evidence:

```text
ION_EXTENSION_SELECTED_REQUEST_START_REPAIR_CANDIDATE_20260511.diff
```

Status: pending; should not precede branch-capsule + Codex Carrier OS cartography.

### DOM perception package

Candidate package exists in workpackets per earlier branch map:

```text
DOM_PERCEPTION_CONTEXT_PACKAGE_20260510_v0_1.zip
```

Status: pending ingestion/validation.

### dAimon / Gemini bridge

Recent migration:

```text
dAimon Gemini bridge moved from 8765 to 8795
ION MCP restored to 8765
```

Status: routing repair pushed in ION and dAimon repos.

## Proposed top-level priority order now

1. Codex Carrier OS Cartography and current infrastructure map.
2. Branch-capsule consolidation review/commit/push if not already done.
3. Codex session ↔ ION branch capsule sync design.
4. Codex subagent/domain model.
5. Codex hooks/slash commands/MCP plan.
6. ION Codex Cockpit UI/automation dashboard design.
7. Git orchestration reconciliation with existing ION Git/GitHub surfaces.
8. Extension selected-request start patch.
9. DOM perception package ingestion.
10. dAimon/Google agent lane integration beyond port repair.

## Why Codex Carrier OS becomes branch #1

Codex is no longer just a worker. It is now central to:

- local editing
- testing
- git staging/push
- service refresh
- bridge migration
- context/capsule synchronization
- future app/cockpit implementation
- local specialist agents and sessions

Before building more domain agents, ION must understand and govern Codex CLI/App natively.
