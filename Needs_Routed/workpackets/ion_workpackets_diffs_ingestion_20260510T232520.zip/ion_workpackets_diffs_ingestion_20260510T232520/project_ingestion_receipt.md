# Candidate Ingestion Receipt — Workpackets + Diffs

receipt_id: ION-WP-DIFF-INGEST-CANDIDATE-20260510T232520-0400
created_at: 2026-05-10T23:25:20.320229-04:00
status: CANDIDATE_RECEIPT
authority: sandbox-derived-report-only

## Action

Mounted ION Custom GPT carrier package in sandbox, ran `ion_status`, ran `ion_carrier_continue` for the workpackets/diffs ingestion objective, and generated candidate registries from router archive indexes.

## Evidence

- ion_status active-state verdict: `ION_ACTIVE_STATE_INTEGRITY_READY`
- ion_carrier_continue verdict: `ION_CARRIER_CONTINUE_READY`
- role sequence generated: steward → vizier → mason
- indexed full repo sha256: `8bc1c1b90780a1012fd3286930b76dc77b631d72d8e297e046d8045094362736`
- indexed workpacket rows: 48
- indexed diff rows: 13

## Outputs

- `MOUNT_AND_SOURCE_PROOF.json`
- `WORKPACKET_REGISTRY_CANDIDATE.json`
- `DIFF_REGISTRY_CANDIDATE.json`
- `WORKPACKET_DIFF_LINKS_CANDIDATE.json`
- `DOMAIN_CANDIDATE_MAP.json`
- `RISK_LEDGER_CANDIDATE.json`
- `SETTLEMENT_QUEUE_CANDIDATE.json`
- `ION_WORKPACKETS_DIFFS_INGESTION_PLAN.md`

## Non-claims

- The actual ION FULL DEVELOPMENT.zip was not present as an openable /mnt/data archive during this run.
- Workpacket and diff registries were generated from router package indexes, not from direct full-archive content inspection.
- No diff was applied.
- No workpacket or diff was promoted to accepted state.
- No live connector/local hub/GitHub/Codex external worker was invoked.

## Next packet

`PCKT-ION-WORKPACKETS-DIFFS-INGEST-001`
