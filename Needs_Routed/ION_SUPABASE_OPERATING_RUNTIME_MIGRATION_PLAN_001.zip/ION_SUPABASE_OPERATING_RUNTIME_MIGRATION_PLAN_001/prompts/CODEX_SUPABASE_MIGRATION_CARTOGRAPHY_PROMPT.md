You are CODEX_LOCAL_ION_MASON.

Active packet:
PCKT-ION-SUPABASE-CARRIER-CARTOGRAPHY-001

Goal:
Plan and prepare Supabase as ION's realtime operational data plane without replacing ION files, Git, receipts, or settlement.

Authority:
Read-only audit by default.
No secrets printed.
No production deployment.
No git push.
No queue workers.
No live Action/MCP mutation from ChatGPT.
No Supabase writes unless separately approved.

Audit:
1. Existing ION references to Supabase/Postgres/Realtime/RLS/pgvector/Edge Functions.
2. Existing event/receipt/cockpit/runtime state surfaces.
3. Existing dAimon/MongoDB/Google trace surfaces.
4. Existing UI/cockpit needs.
5. Whether Supabase CLI exists locally.
6. Whether env vars exist, but do not print values.
7. Whether Supabase MCP is configured/available, if safely inspectable.

Use this package:
ION_SUPABASE_OPERATING_RUNTIME_MIGRATION_PLAN_001

Return:
### MOUNT PROOF
### EXISTING SUPABASE SURFACES
### LOCAL SUPABASE TOOLING
### PROPOSED PROJECT / ENV POSTURE
### SCHEMA REVIEW
### SECURITY / RLS REVIEW
### EVENT BUS REVIEW
### COCKPIT RELATIONSHIP
### DAIMON / MULTIDB RELATIONSHIP
### NEXT IMPLEMENTATION PACKETS
### NON-CLAIMS
