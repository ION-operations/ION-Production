# Apply To Local

Suggested local staging target:

```text
ION/05_context/current/browser_perception/
ION/03_registry/domains/domain.browser_perception_core.domain.yaml
ION/03_registry/agents/browser_perception_agents.yaml
ION/03_registry/schemas/browser_perception/
```

This package is candidate-only. Local Codex/ION should:

1. Verify this manifest and SHA256.
2. Inspect all JSON files.
3. Stage docs/schemas under a candidate path.
4. Compare with queued local packet `DOM_PERCEPTION_001_DOMAIN_DESIGN`.
5. Return proof-gated task receipt.
6. Do not treat as accepted state until settled.
