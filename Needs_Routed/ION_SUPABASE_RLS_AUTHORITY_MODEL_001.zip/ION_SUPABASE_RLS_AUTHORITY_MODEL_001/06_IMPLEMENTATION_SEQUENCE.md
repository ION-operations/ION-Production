# 06 — Implementation Sequence

## Step 1 — Commit current migration files

Ensure:

- `001_initial_ion_ops.sql`
- seed file
- setup docs
- protocol docs

are committed.

## Step 2 — Split read policies

Move broad authenticated reads into:

```text
002_dev_private_cockpit_read_policies.sql
```

## Step 3 — Add authority helper/RPC migration

Add:

```text
003_ion_ops_authority_and_rpc.sql
```

with role-claim helpers and record functions.

## Step 4 — Test as admin

Apply migrations in Supabase SQL editor or CLI.

## Step 5 — Test as app user

When Supabase Auth users exist, verify:

- viewer can read views
- agent_writer can insert via RPC
- viewer cannot write
- no public/anon access unless explicitly chosen

## Step 6 — Build local ION adapter

Codex packet:

```text
PCKT-ION-SUPABASE-EVENT-MIRROR-001
```

Local adapter:

```text
ION/04_packages/kernel/ion_supabase_event_mirror.py
```

## Step 7 — Cockpit MVP

Read from:

- `v_cockpit_overview`
- `v_current_carrier_mounts`
- `v_latest_service_health`
- `v_recent_automation_events`
