# ION Codex Cockpit Requirements

Status: candidate UI/product requirements.

## Goal

Build a cockpit that makes ION’s Codex-powered operating system visible and controllable. The user should not need to infer from terminal logs which agents exist, what they know, what they changed, what is stale, what is blocked, and what is ready for settlement.

## Required panels

### 1. Project and Carrier Overview

Show:
- active project root,
- active Git branch,
- dirty tracked/untracked state,
- active service ports,
- Action Gateway/MCP/cockpit/dAimon health,
- current ION status verdict,
- current packet.

### 2. Agent Graph

Graph nodes:
- Codex sessions,
- ChatGPT browser carrier,
- ION PRO sandbox reviewer,
- extension/cockpit carrier,
- dAimon/Gemini bridge,
- GitHub mirror,
- branch capsules,
- work packets,
- receipts,
- settlements.

Graph edges:
- spawned,
- delegated,
- returned,
- blocked,
- superseded,
- depends_on,
- settled_into,
- conflicts_with,
- owns_write_scope.

### 3. Codex Session Manager

For each Codex session:
- session ID,
- agent tag,
- model lane,
- memory policy,
- current packet,
- branch capsule,
- write scope,
- last validation,
- last diff,
- last receipt,
- blockers,
- next lawful action.

### 4. Context Truth Panel

Show for selected agent:
- branch identity card,
- loaded refs,
- context package hashes,
- Codex memory bridge status,
- capsule hash,
- rolling context hash,
- stale-context warnings,
- accepted/candidate boundary.

### 5. Automation Timeline

A chronological view of:
- session start hooks,
- context mounts,
- tool calls,
- patch previews/applies,
- tests,
- commits,
- pushes,
- worker starts,
- blocked returns,
- receipts,
- settlement decisions,
- service restarts.

### 6. Drift and Consistency Dashboard

Detect and display:
- dirty working tree,
- stale `diffs/` and `workpackets/` indexes,
- duplicate work packets,
- superseded but preserved queue residue,
- missing receipts,
- blocked proof returns,
- branch capsule drift,
- write-scope collisions,
- stale Codex session vs branch capsule,
- port routing mismatches,
- service/tunnel mismatches,
- uncommitted runtime evidence,
- candidate work mistaken for accepted state.

### 7. Git and Settlement Board

Show:
- proposed commit splits,
- staged file sets,
- files excluded from stage,
- commit receipts,
- pushed commits,
- runtime evidence quarantine,
- settlement inbox items,
- accepted/deferred/rejected outcomes.

### 8. Work Packet Board

Show:
- active packet,
- queued packets,
- blocked packets,
- stale packets,
- next recommended packet,
- dependencies,
- associated agents/sessions.

### 9. Proof Console

Show:
- commands run,
- return codes,
- pytest logs,
- py_compile results,
- hashes,
- diff summaries,
- receipt paths,
- proof gate verdicts.

### 10. Service and Port Map

Show canonical local service ownership:
- 8765 ION MCP preview,
- 8777 Action Gateway,
- 8788 ION local cockpit,
- 8795 dAimon Gemini bridge,
- 8796 reserved dAimon secondary.

## AI-powered features

The cockpit should use AI only under ION law:
- summarize active work,
- detect likely drift causes,
- propose next lawful actions,
- classify Git file changes,
- draft settlement analysis,
- recommend agent routing,
- explain blockers,
- generate context packages,
- assist with UI proof review.

It must not accept state without receipts/settlement.

## Visual canon

UI must obey ION/JOC/OPUS canon: dense operational instrument panel, matte-black/DXL direction, no generic Material dashboard feel, no casual purple-blue defaults, and visual proof gates for UI claims.

## Transparency constraints

Show:
- visible messages,
- tool calls,
- commands,
- diffs,
- logs,
- receipts,
- context files,
- branch identity,
- decisions.

Do not claim to show hidden chain-of-thought. Provide model-visible plans and summaries instead.
