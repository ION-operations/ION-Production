# Implementation Packets

## PCKT-ION-SUPABASE-CARRIER-CARTOGRAPHY-001

Read-only audit.

Outputs:

- Supabase availability;
- MCP availability;
- local env/config posture;
- existing references in ION/dAimon;
- recommended dev project setup;
- security posture.

## PCKT-ION-SUPABASE-SCHEMA-PROTOTYPE-001

Add:

- `supabase/migrations/001_initial_ion_ops_schema.sql`
- schema docs
- tests for SQL parse/static checks

## PCKT-ION-SUPABASE-EVENT-MIRROR-001

Add:

- local event mirror module;
- dry-run mode;
- inserts automation_events / mount_receipts / health snapshots;
- tests with mock client.

## PCKT-ION-SUPABASE-COCKPIT-READMODEL-001

Add:

- cockpit query adapter;
- latest events;
- service health;
- agent sessions;
- drift summary.

## PCKT-ION-SUPABASE-REALTIME-COCKPIT-001

Add:

- Realtime subscriptions;
- UI live updates;
- event topics.

## PCKT-ION-DAIMON-SUPABASE-EVENT-BRIDGE-001

Add:

- dAimon trace/receipt projection into ION event model;
- Supabase mirror;
- cockpit lane.
