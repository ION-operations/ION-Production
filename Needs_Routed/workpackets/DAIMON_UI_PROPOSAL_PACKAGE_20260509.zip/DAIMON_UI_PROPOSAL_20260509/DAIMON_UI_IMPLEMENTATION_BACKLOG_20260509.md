# dAimon Implementation Backlog

```yaml
status: CANDIDATE_BACKLOG
authority: design_proposal_only
accepted_state_changed: false
```

## MVP: Read-only Review Cockpit

### DAIMON-001 — Static shell
Build the five-zone shell:

```text
TOP_BAR
LEFT_RAIL
MAIN_WORK_SURFACE
RIGHT_INSPECTOR
BOTTOM_TIMELINE
```

Acceptance:

```text
all zones visible
DXL matte-black discipline preserved
no emoji UI controls
no placeholder-only finished panels
```

### DAIMON-002 — Sample session loader
Load `DAIMON_UI_SAMPLE_SESSION_20260509.json`.

Acceptance:

```text
session state appears in top bar
dissents appear in ledger
release gate reflects blockers
```

### DAIMON-003 — Haunt screen
Render artifact claims and Daimon notes.

Acceptance:

```text
claim → note link visible
BLOCK note changes gate state
right inspector shows selected object authority and evidence
```

### DAIMON-004 — Dissent ledger
Track open/answered/escalated/settled dissent states.

Acceptance:

```text
open BLOCK dissent prevents clear-for-release state
primary response does not auto-settle dissent
```

### DAIMON-005 — Release gate
Render allowed outcomes.

Acceptance:

```text
CLEAR_FOR_NEMESIS unavailable when blockers remain
RETURN_TO_PRIMARY, ESCALATE_HUMAN, DEFER_WITH_RECEIPT visible
```

## Phase 2: Write-plane drafts

### DAIMON-006 — Review object writer
Create local JSON draft for notes, dissents, counterfactuals.

Acceptance:

```text
each object has schema_id, timestamp, authority, retrieval_zone, promotion_ceiling
```

### DAIMON-007 — Write receipt emitter
Emit a receipt whenever a review object is created.

Acceptance:

```text
receipt references source artifact hash
receipt marks object as CANDIDATE_OBJECT or CARTOGRAPHED_WITNESS
```

## Phase 3: ION packet integration

### DAIMON-008 — Import active work packet
Read an active work packet or uploaded packet JSON.

### DAIMON-009 — Export DAIMON_* signal drafts
Produce signal files without live mutation.

### DAIMON-010 — Settlement packet draft
Create settlement recommendation packet for Steward/human review.

## Phase 4: Multi-carrier review

### DAIMON-011 — Mirror input bundle
Compile identical bounded input set for Primary and Daimon carriers.

### DAIMON-012 — Draft comparator
Show overlap, divergence, unique evidence, and unresolved conflict.

### DAIMON-013 — Provider witness metadata
Record model/provider/source metadata without letting provider choice become authority.

## Explicit non-goals

```text
no autonomous release
no worker dispatch
no production mutation
no secrets
no browser control
no agent avatars
no full IDE editing
no generic chat-first UI
```
