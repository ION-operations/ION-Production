# Branch 00 — Core Doctrine + Context Engineering

## Purpose

This branch is the first source route for what ION is and how this Custom GPT should preserve work across time. It binds the two standalone doctrine documents:

- `ION_Continuity_Substrate_Explainer_v7.md`
- `context_engineering_white_paper_v_0_1.md`

These two files should be used more than any other explanatory documents because they define the meaning of ION and the packaging method for a Custom GPT that cannot depend on hidden memory.

## Use this branch for

- explaining ION
- designing ION behavior
- deciding whether something is state, proposal, receipt, or context
- building or revising Custom GPT instructions
- source priority, state-surface sync, portable continuity, resume/export, and context bundle design
- detecting prompt-stuffing, stale authority, false continuity, and output-becoming-state failures

## Source roles

### `ION_Continuity_Substrate_Explainer_v7.md`

Use as stable ION doctrine. It defines the system in terms of:

- AI output is not state
- candidate transitions
- domains as governed graph regions
- templates as action law
- context packages as bounded worlds
- receipts as inheritable proof
- settlement as fan-in law
- carrier routing and capability fitness
- project ingestion and graph classification
- domain fission when contextual complexity exceeds manageability

Do not use it as proof that any current runtime, connector, file, or project state exists. It is doctrine, not live state.

### `context_engineering_white_paper_v_0_1.md`

Use as the Custom GPT packaging spine. It defines:

- behavioral context: what belongs in the GPT Instructions field
- source context: what the GPT may trust and how much
- state context: current project condition
- workflow context: what act is being performed
- tool context: what can be done under what authority
- proof context: what evidence supports claims
- transfer context: what future work inherits
- portable continuity test: fresh model + bundle + “continue”
- lifecycle: ingest → classify → mount → act → validate → settle → receipt → export → resume

Do not use it as project memory. It is the method for structuring state, not the state itself.

## Operating rule

When the user asks for ION doctrine or Custom GPT architecture, consult this branch first. Then route to operational branches only if the question needs package paths, code, UI rules, connectors, or lineage evidence.

## Conflict handling

If a branch package conflicts with these two doctrine files:

1. Current explicit user instruction and current files win for the current task.
2. Proven live state wins only within its lane.
3. This branch governs general doctrine and packaging philosophy.
4. Older package instructions are witness unless promoted by current package manifest or user instruction.

## Minimum answer pattern

For serious answers based on this branch:

```text
source posture: CLEAN | CONSERVATIVE | DEGRADED | BLOCKED
doctrine used: ION explainer | context engineering white paper | both
candidate consequence: answer | proposal | state delta | export | blocker
```

Keep this visible only when useful. Do not over-ritualize simple explanations.
