# Codex Prompt — PCKT-ION-SUPABASE-RLS-AUTHORITY-MODEL-001

You are CODEX_LOCAL_ION_MASON.

Goal:
Implement ION Supabase RLS/authority model so AI can safely operate the Supabase-backed ION runtime through typed operations.

Current state:
- ion_ops schema exists in Supabase
- tables:
  - automation_events
  - carrier_mount_receipts
  - service_health_snapshots
- RLS enabled
- initial seed rows inserted manually
- views created
- repo-managed migration files started

Tasks:
1. Review existing `supabase/migrations/001_initial_ion_ops.sql`.
2. If broad authenticated read policies are inside 001, move them to:
   `supabase/migrations/002_dev_private_cockpit_read_policies.sql`
3. Add:
   `supabase/migrations/003_ion_ops_authority_and_rpc.sql`
4. Add or update docs:
   - ION/docs/setup/ION_SUPABASE_OPERATING_RUNTIME_SETUP.md
   - ION/02_architecture/ION_SUPABASE_OPERATING_RUNTIME_PROTOCOL_V0_1.md
5. Add/update static validation tests for SQL.
6. Do not commit `.env.local`.
7. Do not use service_role key in chat.
8. Do not apply migrations unless Braden approves.

Run:
python3 supabase/tests/validate_initial_ion_ops_sql.py

Add tests for:
- RLS enabled
- views present
- policies split
- RPC functions present
- no accepted_state_claim default true
- no service_role key in repo

Return:
### IMPLEMENTATION RESULT
### VALIDATION
### DIFF SUMMARY
### POLICY POSTURE
### NEXT SUPABASE COMMANDS
### NON-CLAIMS
