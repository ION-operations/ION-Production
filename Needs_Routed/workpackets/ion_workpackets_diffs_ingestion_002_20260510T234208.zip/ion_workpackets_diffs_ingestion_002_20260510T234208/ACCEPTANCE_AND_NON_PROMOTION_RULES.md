# Acceptance and Non-Promotion Rules

generated_at: 2026-05-10T23:43:38.236352-04:00
status: CANDIDATE_CONTROL_DOC

## Core boundary

All workpackets and diffs remain candidate material until a settlement act explicitly classifies them.

A local content scan proves only:

```text
file exists
hash
path
size
modified time
readable structure
affected paths for diffs
ZIP manifest where applicable
candidate links
risk/domain guesses
```

It does not prove:

```text
intent accepted
diff applied
source currentness
state promotion
test success
human approval
connector success
```

## Allowed during PCKT-002

```text
read files
hash files
parse text headings and references
parse diff affected paths
inspect ZIP manifests
write derived reports to output folder
draft receipt
prepare settlement queue
```

## Forbidden during PCKT-002

```text
apply .diff or .patch
edit source files under ION_CODEX FULL
delete or move source files
invoke connector/lhub/MCP/GitHub/browser extension
run production or live services
treat candidate workpacket as current law
treat automated workpacket-diff link as proof of acceptance
```

## Promotion gates

A candidate may move toward accepted state only when all applicable gates pass:

1. Content proof exists.
2. Source authority comparison is complete.
3. Risk class is assigned.
4. Affected paths are known for diffs.
5. Test/proof obligations are known.
6. Conflicts are recorded.
7. Steward/human settlement outcome is recorded.
8. Receipt names what future work may inherit.

## Settlement outcomes

```text
ACCEPTED_AS_IS
MERGE_PROPOSAL_REQUIRED
ESCALATE_REVIEW
DEFERRED
ABANDONED
```

## Human review required when

```text
risk_class in:
  production_or_live_connector_surface
  secret_or_auth_surface
  code_or_state_patch_candidate
  connector_schema_or_config_candidate
  instruction_surface_candidate
```

Also required when:

```text
affected paths overlap current authority files
candidate changes action schemas or auth behavior
candidate modifies instructions/router law
candidate claims tests or execution not reproduced
candidate crosses domain boundaries
candidate conflicts with current branch docs
```

## Receipt requirement

Every meaningful settlement must leave a receipt containing:

```text
candidate ids considered
evidence considered
conflicts found
settlement outcome
review authority
what was accepted/rejected/deferred
next packet or context package that inherits the result
```
