# ION Extension Mini-Helixion Context Package v0.1

## Purpose

Define the ChatGPT browser extension as the in-chat Mini-Helixion cockpit for ION/dAimon.

The full Living Operational Graph is the main city-scale app. The extension is the embedded control surface inside ChatGPT.

## Core Layout

### 1. Top Activity Ticker

A small top-bar element, already present or planned in the extension top-bar area, should show single-sentence operational updates.

It may use up to two rows of text.

Purpose:

```text
Keep the operator continuously oriented without opening a panel.
```

Examples:

```text
Queued GRAPH_001_CONTEXT_BUNDLE → waiting for Codex carrier.
Codex worker running: live graph schema validation, 02:14 elapsed.
Capsule reply received from codex_general; no queue sync started.
Proof gate accepted: custom GPT infrastructure repair.
```

Ticker fields:

```text
severity
lane
verb
object
status
timestamp
receipt_or_packet_ref
short_human_sentence
```

Ticker rules:

```text
one sentence preferred
two lines maximum
no secrets
no raw logs
no hidden chain of thought
click opens related bottom panel
```

### 2. Bottom Expandable Tab Dock

Bottom tabs sit above the ChatGPT input box. Each tab expands upward into a panel.

Purpose:

```text
Let the operator inspect the current ION work state without leaving the ChatGPT conversation.
```

Recommended tabs:

```text
Status
Actions
Queue
Agents
Comms
Worker
Context
Receipts
Graph
```

### 3. Relationship to Full App

The extension is the cockpit. The full app is the living operational city.

```text
Top ticker = what just happened.
Bottom tabs = inspect and control the current lane.
Full Helixion app = explore the entire graph/city.
```

## Panel Contracts

### Status

Current ION connection state, project lane, active packet, proof posture.

### Actions

MCP/Action calls with read/write/mutation labels, input summary, output summary, receipt refs.

### Queue

Active, queued, blocked, accepted, failed, priority, governance tier.

### Agents

Agent roster, running/queued specialist roles, latest returns, agent domain.

### Comms

Codex Capsule messages, carrier messages, ack/poll status.

### Worker

Live worker telemetry: PID, elapsed, heartbeat, run id, latest return, proof gate.

### Context

Mounted/generated context packages, candidate/accepted boundaries, local install targets.

### Receipts

Latest receipts, proof gates, settlement notes, accepted/rejected transitions.

### Graph

Mini-route view: current domain, packet path, carrier position, route to full app.

## Event Model

Every extension-visible update should be a cockpit event.

Events are witness until receipted.

Extension display does not make state accepted.

## Non-Claims

The extension is not ION authority.
The extension is not the full app.
A visible event is not accepted state.
Tool visibility is not permission.
