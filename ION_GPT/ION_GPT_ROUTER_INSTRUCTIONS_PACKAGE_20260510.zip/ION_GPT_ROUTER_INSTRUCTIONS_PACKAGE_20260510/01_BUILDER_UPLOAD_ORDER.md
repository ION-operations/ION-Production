# Builder Upload Order and Knowledge Layout

## Goal

Keep the Custom GPT Instructions field small. Put only `00_PASTE_MAIN_GLOBAL_INSTRUCTIONS_UNDER_8000_CHARS.txt` into the GPT Builder Instructions field. Upload this package and the source files as Knowledge.

## Recommended Knowledge upload order

### Tier 1 — router and indexes

1. `00_PASTE_MAIN_GLOBAL_INSTRUCTIONS_UNDER_8000_CHARS.txt`
2. `02_ROUTER_INDEX.md`
3. `05_INDEXES/UPLOADED_ARTIFACT_INDEX.md`
4. `05_INDEXES/HOT_FILE_INDEX.md`
5. `05_INDEXES/ARCHIVE_TREE_OVERVIEW.md`
6. `05_INDEXES/BRANCH_ROUTER_MAP.json`

### Tier 2 — branch instructions

Upload all files under `04_BRANCH_INSTRUCTIONS/`.

### Tier 3 — core doctrine

1. `ION_Continuity_Substrate_Explainer_v7.md`
2. `context_engineering_white_paper_v_0_1.md`

### Tier 4 — operational package and deep source

1. `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_7_CANDIDATE_20260509T224136Z.zip`
2. `ION FULL DEVELOPMENT.zip`

### Tier 5 — supporting/domain packs

1. `EXTENSION.zip`
2. `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7.zip`
3. `ATLAS.zip`
4. `AIM-ION.zip`
5. `dAimon3.zip`
6. `dAimon_ION3.zip`
7. `_ui_canon.zip`

## Why this order

The router and branch instructions tell the GPT how to use everything else. The two doctrine docs define the law. The Custom GPT carrier package and full repo provide operational source. The other packages become domain branches, not prompt bloat.

## Do not paste

Do not paste the old `001_GPT_INSTRUCTIONS_PASTE_8K.md` as the new Instructions field. It remains important, but it is now Branch 01 knowledge.
