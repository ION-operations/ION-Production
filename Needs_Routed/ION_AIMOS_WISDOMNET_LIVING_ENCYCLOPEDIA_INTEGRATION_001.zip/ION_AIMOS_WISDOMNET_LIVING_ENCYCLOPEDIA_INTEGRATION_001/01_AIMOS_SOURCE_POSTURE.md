# AIMOS / AIM-ION Source Posture

## Classification

AIM-OS/AIM-ION material should be classified as:

```text
source_type: lineage_witness
authority_status: candidate_reference_not_current_law
integration_mode: reconcile_before_promote
```

## Why

AIM-ION appears to preserve a deep north-star / encyclopedic / master-index family. This is not merely documentation density; it is a preserved navigation organ for complex AI operating systems.

The important AIMOS/AIM-ION organs to recover include:

```text
north_star_project/THE_NORTH_STAR_DOCUMENT.md
AIM_OS_NORTH_STAR.md
canon/north_star/AIM_OS_NORTH_STAR.md
docs/Aether-OS/MASTER_INDEX.md
canon/doctrine/AIMOS_MASTER_SYSTEM_INDEX.md
canon/doctrine/UNIFIED_MASTER_INDEX.md
canon/doctrine/VARIABLE_DENSITY_PLANNING.md
analysis/COMPLETE_SYSTEM_OVERVIEW.md
analysis/MASTER_INDEX.md
PROJECT_TRUTH/01_canonical_system_index.md
AGENT_CONTEXT_ARCHITECTURE.md
AIMOS_CONTEXT_INTEGRATION.md
TEMPLATE_DEVELOPMENT.md
```

## Working rule

```text
Do not import AIMOS as law.
Extract its organs into an anchor ledger.
Classify each organ by authority and current relevance.
Promote only through ION settlement.
```

## Integration target

The first integration target is not code. It is a source-governed lineage ledger:

```text
ION/05_context/current/aimos_lineage/
  AIMOS_SOURCE_POSTURE.md
  AIMOS_ANCHOR_LEDGER.json
  AIMOS_TO_ION_INTEGRATION_MATRIX.md
  AIMOS_VARIABLE_DENSITY_DOC_MODEL.md
  AIMOS_WISDOMNET_SIGNALS.md
```
