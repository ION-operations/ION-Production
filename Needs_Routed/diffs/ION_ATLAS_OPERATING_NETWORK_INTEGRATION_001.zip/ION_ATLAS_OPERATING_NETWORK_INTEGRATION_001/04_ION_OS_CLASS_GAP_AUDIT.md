# ION OS-Class Gap Audit

This audit uses ATLAS as the lens for treating ION as an operating network rather than an agent pile.

## 1. Kernel / runtime model

**Current:** ION has doctrine, kernel packages, MCP/Action surfaces, Codex runner, local daemons, and context systems.

**Gap:** ION needs a named runtime model:
- what is the kernel?
- what is the control plane?
- what is the data plane?
- what is a carrier?
- what is a session?
- what is a branch?
- what is a packet?
- what is a receipt?
- what is a settlement?

**Packet:** `PCKT-ION-RUNTIME-MODEL-CANON-001`

## 2. Control plane vs data plane

**Current:** MCP/Actions, Codex queue, carrier messages, and local service status act as control surfaces. Runtime JSON/receipts act as data/state surfaces.

**Gap:** Explicit split is missing.

**Proposed split:**
- Control plane: MCP tools, Action Gateway, Codex commands, Git operations, approvals, packet routing.
- Data plane: receipts, task returns, event logs, branch capsules, Supabase mirrors, Drive mirror manifests.

**Packet:** `PCKT-ION-CONTROL-DATA-PLANE-SEPARATION-001`

## 3. Scheduling and reconciliation

**Current:** Codex queue runner, operator queues, queued requests, manual starts.

**Gap:** Needs Kubernetes-like reconciliation vocabulary:
- desired state
- observed state
- diff
- act
- receipt
- convergence
- blocked state

**Packet:** `PCKT-ION-RECONCILIATION-LOOP-MODEL-001`

## 4. Service lifecycle

**Current:** Action Gateway, MCP preview, local cockpit, dAimon bridge. Port routing truth exists.

**Gap:** Services need first-class lifecycle records:
- owner
- port
- PID
- health endpoint
- restart command
- logs
- last known status
- drift findings
- service receipt

**Packet:** `PCKT-ION-SERVICE-LIFECYCLE-COCKPIT-001`

## 5. Namespace and identity

**Current:** Branch capsules, context instance IDs, carrier mount receipts, agent tags, carrier messages.

**Gap:** Needs a unified namespace model:
- carrier namespace
- agent namespace
- branch namespace
- packet namespace
- receipt namespace
- external app namespace
- Drive/Git/Supabase object namespace

**Packet:** `PCKT-ION-NAMESPACE-MODEL-001`

## 6. Security and authority

**Current:** bounded write roots, confirmation tokens, no production/live authority, branch material guard.

**Gap:** Needs graph-based capability model across all carriers:
- GPT/PRO
- Codex CLI
- Action Gateway
- MCP
- Drive
- Slack
- GitHub/GitLab
- Supabase
- dAimon
- browser extension

**Packet:** `PCKT-ION-AUTHORITY-CAPABILITY-GRAPH-001`

## 7. Packaging and distribution

**Current:** full project packages, context packages, Drive mirror, workpackets, diffs.

**Gap:** Needs formal package taxonomy:
- source repo snapshot
- context mirror
- branch return
- product package
- runtime evidence bundle
- settlement bundle
- external carrier package

**Packet:** `PCKT-ION-PACKAGE-TAXONOMY-001`

## 8. Observability

**Current:** receipts, statuses, test results, task returns, local logs.

**Gap:** Needs unified observability model:
- event schema
- service health
- drift findings
- proof gaps
- agent lifecycle
- git lifecycle
- settlement lifecycle

**Packet:** `PCKT-ION-OBSERVABILITY-EVENT-SCHEMA-001`

## 9. Cockpit

**Current:** local cockpit and UI/JOC/OPUS canon exist, but the full operating UI is not yet integrated with Supabase/Codex/Drive/dAimon.

**Gap:** Need OS cockpit UI with agent graph, service graph, event timeline, drift dashboard, git board, settlement board, and external carrier status.

**Packet:** `PCKT-ION-COCKPIT-OPERATING-UI-SPEC-001`

## 10. External carrier adaptation

**Current:** dAimon, Drive, Action Gateway, MCP, GitHub/GitLab/Slack plans.

**Gap:** Need generic carrier onboarding and app topology protocol.

**Packet:** `PCKT-ION-CHATGPT-APP-CARRIER-TOPOLOGY-001`
