# 00 — Executive Summary

ION needs Supabase to be AI-operable without being fragile.

The goal is not to prevent a database owner from deliberate sabotage. The goal is to ensure ordinary AI operations, admin variance, cockpit usage, and future user access happen through typed, auditable, low-risk lanes.

## Core thesis

```text
AI can operate the Supabase-backed ION runtime.
ION prevents operation from becoming sabotage.
```

## Supabase role in ION

```text
ION files/Git/receipts/settlement = truth
Supabase = operational mirror + queryable cockpit backend
```

Supabase should mirror selected operational state:

- carrier mount receipts
- automation events
- service health snapshots
- drift findings
- work packet indexes
- settlement candidates
- git events
- dAimon traces
- Slack/GitHub events

## First authority layers

1. **Core schema migration**
   - tables, indexes, triggers, views, RLS
   - no broad public writes

2. **Private cockpit read policies**
   - optional dev/private read access for authenticated users
   - separate migration so production can skip or revise it

3. **Typed RPC operations**
   - `record_automation_event`
   - `record_service_health_snapshot`
   - `record_carrier_mount_receipt`
   - later: drift, settlement, git, dAimon events

4. **Role/claim based authority**
   - `ion_viewer`
   - `ion_operator`
   - `ion_agent_writer`
   - `ion_steward`
   - `ion_admin`
   - `ion_break_glass`

5. **Append-first operational model**
   - agents insert evidence
   - views summarize state
   - destructive or authority-widening changes require migrations / receipts / review

## Immediate recommendation

Split permissions into two migrations:

```text
001_initial_ion_ops.sql
  schema/tables/views/RLS only

002_dev_private_cockpit_read_policies.sql
  private cockpit read policies for dev use

003_ion_ops_authority_and_rpc.sql
  helper functions + typed event/mount/health RPC insert lane
```

This lets ION move quickly without baking broad access into the core schema.
