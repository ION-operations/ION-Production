# Instructions

Use this file in the Custom GPT Instructions box:

```text
CURRENT_INSTRUCTIONS_TO_PASTE.md
```

Older versions are in:

```text
historical/
```
