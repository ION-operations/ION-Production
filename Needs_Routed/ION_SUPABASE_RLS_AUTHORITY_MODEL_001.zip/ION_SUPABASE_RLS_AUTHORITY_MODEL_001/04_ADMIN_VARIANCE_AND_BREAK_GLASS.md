# 04 — Admin Variance And Break-Glass

No database system can prevent a true owner/admin from deliberate sabotage. ION should not pretend otherwise.

ION should make normal operation safe and unusual destructive authority obvious.

## Break-glass rule

Any operation that:

- disables RLS
- drops/truncates tables
- deletes receipt rows
- grants broad public access
- widens write policies
- marks accepted state without settlement
- uses a service role outside a trusted server path

should create a break-glass receipt.

## Future break-glass table

```sql
ion_ops.break_glass_receipts
```

Fields:

- `break_glass_id`
- `actor`
- `reason`
- `operation_class`
- `affected_objects`
- `before_state`
- `after_state`
- `approval_ref`
- `created_at`

## Administrative design

- Schema changes live in Git migrations.
- Policy changes live in Git migrations.
- Manual dashboard changes are allowed only for bootstrap/debug and should be reconciled back into migrations.
- The cockpit should display "manual drift" when Supabase differs from repo migrations.

## Bad admin mitigation

ION mitigates admin error by:

- reducing the need for manual admin work
- using generated migrations
- using typed functions
- making access posture visible
- keeping local receipts as the final evidence trail
