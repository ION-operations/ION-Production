# Architecture Overview

## Data Plane Split

| Layer | Role | Truth Status |
|---|---|---|
| Git/local repo | source code, protocols, tests, docs | source truth |
| ION receipts/files | packets, receipts, context, settlement | continuity/state truth |
| Supabase | queryable realtime mirror | operational index |
| Cockpit | UI over Supabase + local ION/MCP | visibility/control surface |
| Codex CLI | local implementation carrier | executor |
| ION MCP/Actions | bounded live control | carrier interface |
| dAimon/MongoDB | Google/Gemini carrier lane | external lane / lineage |
| Slack | human/agent comms | witness/comms |
| GitHub/GitLab | source/review/project plane | durable source collaboration |
| Google Drive | optional context visibility mirror | read mirror |

## ION Operating Runtime Loop

```text
ION operation occurs
→ local receipt / packet / runtime file is written
→ event extractor emits normalized event
→ Supabase mirror stores/indexes event
→ Realtime broadcasts event to cockpit
→ cockpit shows status/drift/proof
→ operator or agent acts
→ new ION receipt remains the source of inheritance
```

## Supabase Is Not The Steward

Supabase may answer:

- What happened recently?
- Which agents are active?
- Which receipts exist?
- Which packets are blocked?
- Which services are healthy?
- Which drift findings are open?

Supabase may not answer alone:

- What is accepted ION state?
- Which candidate becomes law?
- Was this settlement accepted?
- What may future agents inherit?

Those remain ION settlement questions.
