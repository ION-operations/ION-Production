# 02 — RLS Policy Design

## Principle

RLS stays enabled on every exposed table.

Supabase's Data API works with Postgres access controls and RLS. ION should use that deliberately rather than treating the API as a trusted internal channel.

## Policy tiers

### Tier 0 — Locked schema

No client policies. SQL editor/admin only. Good for initial bootstrap.

### Tier 1 — Private cockpit read

Authenticated users with `ion_viewer` or better can read cockpit-safe tables/views.

### Tier 2 — Agent writer insert

Actors with `ion_agent_writer` can insert via RPC functions. Direct table inserts remain discouraged.

### Tier 3 — Steward settlement

Actors with `ion_steward` can update settlement rows later, not yet part of v001.

### Tier 4 — Admin migration

Schema and RLS policy changes happen through migration files, not ad hoc UI edits.

## Views

Views should be created with `security_invoker = true` where practical so underlying RLS is respected.

Example:

```sql
create or replace view ion_ops.v_current_carrier_mounts
with (security_invoker = true)
as
select ...
```

If the deployed Postgres version or syntax does not support this, keep view access server-side until corrected.

## Recommended first policies

For dev/private cockpit:

- allow `select` on base tables for `has_any_ion_role(['ion_viewer', 'ion_operator', 'ion_agent_writer', 'ion_steward', 'ion_admin'])`
- allow no direct insert/update/delete initially, unless explicitly using the RPC path

## Why separate from core schema?

The schema should be stable. Access posture changes faster.

Separate migrations allow:

```text
schema: stable
dev read policies: optional
production RLS: stricter later
```
