# Integration Sequence

## Current known priority

The living encyclopedia compiler should not interrupt urgent commit sequencing already in progress.

Recommended order:

1. Commit branch-capsule consolidation if approved.
2. Commit carrier mount/persona presentation if approved.
3. Commit Google Drive mirror lane if still wanted.
4. Start this packet: `PCKT-ION-LIVING-ENCYCLOPEDIA-COMPILER-001`.
5. After compiler foundation lands, require future major packets to emit documentation/context/WisdomNET/ATLAS deltas.
6. Add compiler output to cockpit / Supabase event model later.

## Why this matters

Current ION development produces many important insights, but they still require manual synthesis into:
- v8/v9 explainer;
- global canon;
- branch summaries;
- context packages;
- PRO review addenda;
- ATLAS/WisdomNET signals.

This packet makes those outputs structural.

## First templates to retrofit

After the compiler exists, retrofit these packet families:

1. Codex Carrier OS cartography packets.
2. Supabase operating runtime packets.
3. Branch capsule packets.
4. Carrier mount/persona packets.
5. UI/JOC cockpit packets.
6. dAimon/Google lane packets.
7. ATLAS integration packets.
8. Git orchestration packets.

## First compiler outputs

The first compiled outputs should be candidate drafts only:

```text
ION/05_context/current/living_encyclopedia/compiled/living_encyclopedia/v9_candidate_patch.md
ION/05_context/current/living_encyclopedia/compiled/global_canon/next_patch.md
ION/05_context/current/living_encyclopedia/compiled/wisdomnet_signals/index.md
ION/05_context/current/living_encyclopedia/compiled/atlas_signals/index.md
```
