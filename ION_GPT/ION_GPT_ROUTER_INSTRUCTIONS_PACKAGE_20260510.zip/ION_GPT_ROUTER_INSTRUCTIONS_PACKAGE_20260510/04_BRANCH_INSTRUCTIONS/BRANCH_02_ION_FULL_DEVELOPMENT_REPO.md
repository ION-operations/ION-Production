# Branch 02 — ION Full Development Repository

## Bound artifact

`ION FULL DEVELOPMENT.zip`

## Purpose

This is the broadest ION development repository snapshot. It is the deep source branch for implementation details, protocols, registries, templates, kernel code, sandbox files, workpackets, tests, diffs, and historical development context.

Use this branch when the question needs real source topology or implementation detail beyond the Custom GPT product pack.

## First files and folders to inspect

Use `05_INDEXES/HOT_FILE_INDEX.md` and `ARCHIVE_TREE_OVERVIEW.md` for exact paths. The usual hot route is:

1. `ION_CODEX FULL/README.md`
2. `ION_CODEX FULL/ION/REPO_AUTHORITY.md`
3. `ION_CODEX FULL/ION/README.md`
4. `ION_CODEX FULL/ION/00_BOOTSTRAP/`
5. `ION_CODEX FULL/ION/01_doctrine/`
6. `ION_CODEX FULL/ION/02_architecture/`
7. `ION_CODEX FULL/ION/03_registry/`
8. `ION_CODEX FULL/ION/04_agents/`
9. `ION_CODEX FULL/ION/04_packages/kernel/`
10. `ION_CODEX FULL/ION/05_context/current/`
11. `ION_CODEX FULL/ION/07_templates/`
12. `ION_CODEX FULL/ION_sandbox/`
13. `ION_CODEX FULL/workpackets/`

## Use this branch for

- source-level ION questions
- locating protocols and schemas
- implementation audits
- kernel and package code review
- carrier/runtime protocols
- domain/registry/template source lookup
- custom-GPT workpacket lineage
- resolving source conflicts by reading authority files
- generating development packets for Codex/local workers

## Do not use this branch for

- assuming repo snapshot is newer than uploaded Custom GPT package unless dates/receipts prove it
- treating `.git`, caches, pyc files, or old workpackets as hot authority
- claiming tests passed unless validation files or current execution prove it
- using archived context as current law

## Authority ladder inside this branch

1. `ION/REPO_AUTHORITY.md`
2. root `README.md` and `ION/README.md`
3. bootstrap locks and architecture protocols
4. registries and schemas
5. templates and active/current context
6. kernel code and validation artifacts
7. workpackets/diffs
8. archive and historical witness

## Branch output rule

When using this branch for implementation work, state:

```text
source path(s) inspected
authority posture
candidate change or finding
proof available / proof missing
next packet or blocker
```
