# Executive Plan

## Mission

Build the Supabase operating runtime as ION's realtime, queryable, UI-ready operational data plane while preserving ION's existing law:

> Supabase mirrors and indexes ION evidence. Supabase does not replace ION evidence.

## Why Supabase

ION currently holds truth in files, Git history, receipts, context packages, workpackets, and runtime JSON surfaces. That is strong for continuity and audit, but difficult for a live cockpit:

- file scans are slow;
- queues can be too large for MCP responses;
- runtime views need pagination;
- many agents/sessions/events need queryable indexes;
- UI wants realtime updates.

Supabase solves the runtime visibility problem:

- Postgres for relational operating state;
- Realtime for event streaming;
- RLS/Auth for controlled cockpit access;
- Edge Functions for safe server-side adapters;
- Storage for artifact references if needed;
- MCP for developer inspection and schema work when scoped/read-only.

## Principle

Do not migrate ION into Supabase.

Mirror selected ION operating events into Supabase and let the cockpit query them.

## First win

Start with three tables:

1. `automation_events`
2. `carrier_mount_receipts`
3. `service_health_snapshots`

Then build the cockpit over these.

## Avoid

- writing secrets;
- exposing raw private logs;
- using Supabase as accepted-state authority;
- migrating the whole file graph into tables;
- giving ChatGPT broad Supabase write access;
- connecting MCP to production data without read-only/project scoping.
