# Executive Integration

## Core decision

AIM-OS/AIM-ION should be treated as a lineage and source-bearing organism, not as a competing current law surface.

The integration target is:

```text
ION = current governing continuity / carrier / settlement substrate
AIM-OS / AIM-ION = preserved north-star, encyclopedic, context-architecture, and variable-density lineage
WisdomNET = structural intelligence evolution layer
ATLAS = comparative operating-systems / platform reference
dAimon = Google/Gemini carrier lineage
Codex Carrier OS = OpenAI/local execution carrier
Supabase = realtime operational mirror / cockpit backend
```

## What changes

The current ION plan should gain a formal lineage branch:

```text
B11 — AIMOS / AIM-ION / WisdomNET / Living Encyclopedia Integration
```

This branch owns the recovery and lawful integration of:

- AIM-ION north-star organs
- AIMOS context architecture
- variable-density planning
- master indexes
- template evolution law
- WisdomNET structural evolution
- living encyclopedia compiler inputs
- documentation levels and generated summaries

## Strong formulation

```text
AIM-ION preserves navigational depth.
WisdomNET preserves structural learning.
ION governs what may become state.
The living encyclopedia is compiled from lawful movement.
```
