# Codex Carrier Operating System Implementation Roadmap

Status: candidate implementation sequence.

## Phase 0 — Current stable base

Already completed or recently proven in live/local work:
- B00 idempotency/no-receipt repair pushed.
- Duplicate B00 supersession pushed.
- ION local port routing truth pushed.
- dAimon moved to 8795.
- MCP confirmation forwarding fix pushed.
- MCP preview restored on 8765.
- bounded patch preview/apply smoke passed and was reverted.

## Phase 1 — Cartography and domain definition

### PCKT-ION-CODEX-CARRIER-OPERATING-SYSTEM-CARTOGRAPHY-001_LOCAL_AUDIT

Read-only local Codex audit of:
- local `~/.codex` configuration,
- memories,
- sessions,
- commands,
- subagents,
- hooks,
- MCP config,
- app-server/remote-control support,
- existing ION Codex surfaces.

Output:
- local capability inventory,
- overlaps/partial emulations,
- security/capability risks,
- implementation packets.

### PCKT-ION-CODEX-CARRIER-DOMAIN-REGISTRY-002

Create a registry for Codex carrier domain objects:
- sessions,
- agent profiles,
- memory policies,
- hook policies,
- slash commands,
- subagent/domain mappings.

## Phase 2 — Session and memory integration

### PCKT-ION-CODEX-SESSION-REGISTRY-003

Add:
- `CODEX_SESSION_REGISTRY.json`,
- session record schema,
- helper to register/update session records.

### PCKT-ION-CODEX-MEMORY-CAPSULE-BRIDGE-004

Add:
- memory policy,
- branch capsule sync rules,
- redaction/secret handling,
- no-accepted-state boundary for memory.

### PCKT-ION-CODEX-ROLLING-CONTEXT-SYNC-005

Add:
- `ROLLING_CONTEXT.md` template,
- branch capsule sync helper,
- before-exit sync convention.

## Phase 3 — Agent/subagent domain system

### PCKT-ION-CODEX-SPECIALIST-REGISTRY-006

Map Codex agents to ION domains:
- mason,
- git steward,
- runtime cartographer,
- branch capsule architect,
- UI canonist,
- dAimon bridge specialist,
- proof nemesis.

### PCKT-ION-CODEX-SUBAGENT-FANOUT-FANIN-007

Define:
- when Codex subagents may spawn,
- how their returns are saved,
- how they settle back to parent branch.

## Phase 4 — Hooks and slash commands

### PCKT-ION-CODEX-HOOK-ENFORCEMENT-008

Extend hooks:
- SessionStart mount proof,
- branch identity card,
- protected path checks,
- write-scope preflight,
- rolling context sync.

### PCKT-ION-CODEX-SLASH-COMMAND-PACK-009

Implement or document:
- `/ion-mount`,
- `/ion-identity`,
- `/ion-packet`,
- `/ion-branch`,
- `/ion-sync`,
- `/ion-proof`,
- `/ion-git-plan`,
- `/ion-receipt`,
- `/ion-settlement`,
- `/ion-handoff`.

## Phase 5 — Cockpit and UI

### PCKT-ION-CODEX-COCKPIT-DATA-MODEL-010

Create cockpit data model:
- sessions,
- agents,
- branch capsules,
- receipts,
- automations,
- drift signals.

### PCKT-ION-CODEX-COCKPIT-UI-MVP-011

Build or extend UI:
- agent graph,
- session manager,
- context truth panel,
- automation timeline,
- proof console,
- Git/settlement board.

### PCKT-ION-CODEX-COCKPIT-DRIFT-DASHBOARD-012

Add:
- stale state,
- duplicate queue,
- service drift,
- proof drift,
- agent drift,
- git drift.

## Phase 6 — Governance and settlement

### PCKT-ION-CODEX-CARRIER-SETTLEMENT-LAW-013

Define how Codex carrier outputs become:
- abandoned,
- deferred,
- witness,
- candidate,
- accepted.

### PCKT-ION-CODEX-CARRIER-PORTABLE-CONTINUITY-TEST-014

Fresh carrier receives:
- context package,
- one word: `continue`.

It must recover state, next packet, and proof boundaries without prior chat.
