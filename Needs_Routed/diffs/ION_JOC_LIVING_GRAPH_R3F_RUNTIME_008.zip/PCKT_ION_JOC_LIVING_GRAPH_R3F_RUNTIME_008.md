# PCKT-ION-JOC-LIVING-GRAPH-R3F-RUNTIME-008

## Proof posture

Candidate UI/JOC evolution patch. Not accepted ION state. No production deployment. No Git push. No live telemetry. No Action/MCP mutation. No queue workers.

## Objective

Proceed from the dependency-gated R3F adapter contract in packet 007 into the first actual React Three Fiber runtime candidate for the Living Operational Graph cockpit, while preserving:

- 006 dependency-free canvas runtime;
- 005 SVG territory fallback;
- browser proof gates;
- JOC no-monolith shell behavior;
- sample/candidate honesty labels.

## Patch

```text
ion_joc_living_graph_r3f_runtime_008.diff
```

Apply after:

```text
ion_joc_living_graph_view_model_panel_001.diff
ion_joc_living_graph_source_mount_visual_proof_002.diff
ion_joc_living_graph_browser_proof_interaction_003.diff
ion_joc_living_graph_browser_capture_004.diff
ion_joc_living_graph_territory_scene_005.diff
ion_joc_living_graph_webgl_runtime_006.diff
ion_joc_living_graph_r3f_adapter_contract_007.diff
```

Patch stat:

```text
13 files changed, 1291 insertions(+), 104 deletions(-)
```

## What changed

Added:

```text
ION/04_packages/kernel/ion_living_graph_r3f_runtime_proof.py
ION/08_ui/joc_cockpit_shell/r3f/LivingGraphR3fStage.tsx
ION/08_ui/joc_cockpit_shell/r3f/livingGraphR3fAdapter.ts
ION/08_ui/joc_cockpit_shell/r3f/README_R3F_RUNTIME_CANDIDATE.md
```

Modified:

```text
ION/04_packages/kernel/ion_living_graph_r3f_adapter.py
ION/04_packages/kernel/ion_living_graph_view_model.py
ION/04_packages/kernel/ion_living_graph_visual_proof.py
ION/04_packages/kernel/ion_living_graph_browser_capture.py
ION/08_ui/joc_cockpit_shell/package.json
ION/08_ui/joc_cockpit_shell/package-lock.json
ION/08_ui/joc_cockpit_shell/LivingGraphWorkbenchPanel.tsx
ION/08_ui/joc_cockpit_shell/ion-runtime-cockpit.css
ION/tests/test_kernel_ion_living_graph_view_model.py
```

## Dependency declaration candidate

The patch declares:

```json
{
  "dependencies": {
    "@react-three/fiber": "^9.6.1",
    "three": "^0.184.0"
  },
  "devDependencies": {
    "@types/three": "^0.184.1"
  }
}
```

The package lock resolved:

```text
@react-three/fiber 9.6.1
three 0.184.0
@types/three 0.184.1
```

Local operator must run `npm install` after applying the patch before building the R3F runtime.

## Runtime behavior

The GRAPH route now has:

```text
R3F runtime host
R3F runtime status disclosure
actual R3F Canvas stage source
R3F primitive projection adapter
R3F stage deferred state when browser WebGL probe fails
canvas fallback preserved
SVG fallback preserved
```

The cockpit mounts the R3F stage only when:

```text
r3f dependencies are declared + locked + installed
source markers exist
browser WebGL probe succeeds
render mode requests R3F or hybrid
```

Otherwise it displays an explicit deferred state and keeps canvas/SVG fallbacks active.

## Validation

Summary:

```text
git apply --check after 001-007: passed
git apply after 001-007: passed
npm install --ignore-scripts --no-audit --no-fund: passed
py_compile: passed
pytest: 22 passed
direct Vite build: passed
static visual proof: candidate_visual_static_pass
R3F runtime static proof: candidate_r3f_runtime_static_pass
browser capture: candidate_browser_capture_pass
```

Known caveats:

```text
npm run build failed in sandbox because zip-extracted node_modules/.bin/vite is a plain text shim without a shebang/symlink behavior.
direct node node_modules/vite/bin/vite.js build passed.
npx tsc --noEmit still fails on existing non-packet TypeScript issues in older files.
sandbox Chromium reported WebGL unavailable, so R3F runtime was deferred in browser capture.
```

## Browser capture result

```text
browser status: candidate_browser_capture_pass
r3f runtime state: candidate_r3f_runtime_deferred_webgl_unavailable
r3f webgl ready: false
canvas runtime rendered: true
SVG fallback preserved: true
no body vertical monolith: true
no body horizontal monolith: true
no page errors: true
```

This is not a live R3F browser-render claim. It is a proof that the actual R3F source/runtime contract is present and the cockpit safely defers to proven fallbacks when WebGL is unavailable.

## Local apply route

```bash
git apply ion_joc_living_graph_view_model_panel_001.diff
git apply ion_joc_living_graph_source_mount_visual_proof_002.diff
git apply ion_joc_living_graph_browser_proof_interaction_003.diff
git apply ion_joc_living_graph_browser_capture_004.diff
git apply ion_joc_living_graph_territory_scene_005.diff
git apply ion_joc_living_graph_webgl_runtime_006.diff
git apply ion_joc_living_graph_r3f_adapter_contract_007.diff
git apply ion_joc_living_graph_r3f_runtime_008.diff
```

Install package changes:

```bash
cd ION/08_ui/joc_cockpit_shell
npm install --ignore-scripts --no-audit --no-fund
node node_modules/vite/bin/vite.js build
```

Validate:

```bash
cd ../../..

PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH=ION/04_packages \
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 \
python3 -m pytest -q \
  ION/tests/test_kernel_ion_living_graph_view_model.py \
  ION/tests/test_kernel_ion_cockpit_view_model.py \
  ION/tests/test_kernel_ion_local_cockpit_app.py

python3 -m py_compile \
  ION/04_packages/kernel/ion_living_graph_r3f_adapter.py \
  ION/04_packages/kernel/ion_living_graph_r3f_runtime_proof.py \
  ION/04_packages/kernel/ion_living_graph_view_model.py \
  ION/04_packages/kernel/ion_living_graph_visual_proof.py \
  ION/04_packages/kernel/ion_living_graph_browser_capture.py

PYTHONPATH=ION/04_packages \
python3 -m kernel.ion_living_graph_r3f_runtime_proof --root . --write --json

PYTHONPATH=ION/04_packages \
python3 -m kernel.ion_living_graph_visual_proof --root . --write

PYTHONPATH=ION/04_packages \
python3 -m kernel.ion_living_graph_browser_capture --root . --write --json
```

## Proof artifacts

```text
VALIDATION_REPORT_ION_JOC_LIVING_GRAPH_R3F_RUNTIME_008.json
R3F_ADAPTER_CONTRACT_CANDIDATE_008.json
R3F_RUNTIME_PROOF_CANDIDATE_008.json
ACTIVE_LIVING_GRAPH_VIEW_MODEL_008.json
ACTIVE_LIVING_GRAPH_VISUAL_PROOF_008.json
ACTIVE_LIVING_GRAPH_STATIC_PROOF_008.svg
BROWSER_CAPTURE_RESULT_CANDIDATE_008.json
BROWSER_CAPTURE_GRAPH_ROUTE_CANDIDATE_008.png
BROWSER_CAPTURE_GRAPH_ROUTE_SELECTED_NODE_CANDIDATE_008.png
```

## Non-claims

```text
no accepted UI state
no production deployment
no Git push
no live telemetry claim
no live Action/MCP mutation
no queue workers
no accepted settlement
browser capture is candidate visual proof only
no live R3F browser-render claim in this sandbox pass
```

## Recommended next packet

```text
PCKT-ION-JOC-LIVING-GRAPH-R3F-LIVE-WEBGL-PROOF-009
```

Scope:

```text
run the same capture harness in a browser environment with WebGL enabled
prove graph-r3f-runtime-stage and graph-r3f-runtime-canvas render
capture R3F primitive markers
preserve canvas/SVG fallback gates
add bundle/code-splitting review for the large R3F chunk
do not connect live telemetry yet
```
