# Hot File Index — First Files To Retrieve

Use these as route starters before falling into the full file index.

## AIM-ION.zip

| Priority | Path | Role | Zone |
|---:|---|---|---|
| 170 | `AIM-ION/canon/history/roundtables/START_HERE.md` | front_door | aim_canon |
| 155 | `AIM-ION/knowledge_architecture/README_DEVELOPMENT/INSTRUCTIONS_FOR_SONNET45_MAX.md` | instruction_prompt | aim_knowledge_architecture |
| 140 | `AIM-ION/canon/README.md` | front_door | aim_canon |
| 140 | `AIM-ION/canon/agents/README.md` | front_door | aim_canon |
| 140 | `AIM-ION/canon/apps/README.md` | front_door | aim_canon |
| 140 | `AIM-ION/canon/audits/README.md` | front_door | aim_canon |
| 140 | `AIM-ION/canon/builds/PACKAGE_MANIFEST.md` | manifest | aim_canon |
| 140 | `AIM-ION/canon/builds/README.md` | front_door | aim_canon |
| 140 | `AIM-ION/canon/builds/requirements.txt` | documentation | aim_canon |
| 140 | `AIM-ION/canon/builds/victus/README.md` | front_door | aim_canon |
| 140 | `AIM-ION/canon/constitution/README.md` | front_door | aim_canon |
| 140 | `AIM-ION/canon/doctrine/README.md` | front_door | aim_canon |
| 140 | `AIM-ION/canon/history/README.md` | front_door | aim_canon |
| 140 | `AIM-ION/canon/history/roundtables/README.md` | front_door | aim_canon |
| 140 | `AIM-ION/canon/north_star/README.md` | front_door | aim_canon |
| 140 | `AIM-ION/canon/systems/README.md` | front_door | aim_canon |
| 140 | `AIM-ION/canon/systems/ion/README.md` | front_door | aim_canon |
| 140 | `AIM-ION/canon/systems/mcp/README.md` | front_door | aim_canon |
| 140 | `AIM-ION/docs/readme_development/README_MANIFESTO_REBUILD_PLAN.md` | front_door | aim_docs |
| 140 | `AIM-ION/knowledge_architecture/AETHER_MEMORY/thought_journals/2025-10-23_readme_v4_manifesto.md` | front_door | aim_knowledge_architecture |
| 130 | `AIM-ION/PROJECT_TRUTH/01_canonical_system_index.md` | index | aim_project_truth |
| 130 | `AIM-ION/PROJECT_TRUTH/02_canonical_doc_index.md` | index | aim_project_truth |
| 130 | `AIM-ION/archive/docs_status_2026_03_11/AIM_OS_PRIME_CANON_INDEX_V1.md` | index | aim_archive |
| 130 | `AIM-ION/canon/INDEX.md` | index | aim_canon |
| 130 | `AIM-ION/canon/agents/opus/GENOME_PROTOCOL.md` | protocol | aim_canon |
| 130 | `AIM-ION/canon/agents/opus/protocol_ide_output.md` | protocol | aim_canon |
| 130 | `AIM-ION/canon/agents/workspaces/opus/indexes/domain_map.md` | agent_carrier | aim_canon |
| 130 | `AIM-ION/canon/bloat_registry/INDEX.md` | index | aim_canon |
| 130 | `AIM-ION/canon/doctrine/01_canonical_system_index.md` | index | aim_canon |
| 130 | `AIM-ION/canon/doctrine/02_canonical_doc_index.md` | index | aim_canon |
| 130 | `AIM-ION/canon/doctrine/AIMOS_MASTER_SYSTEM_INDEX.md` | index | aim_canon |
| 130 | `AIM-ION/canon/doctrine/UNIFIED_MASTER_INDEX.md` | index | aim_canon |
| 130 | `AIM-ION/canon/history/roundtables/CODEX1_NO_SOLO_ALIGNMENT_PROTOCOL_2026-03-05.md` | protocol | aim_canon |
| 130 | `AIM-ION/canon/history/roundtables/INDEX.md` | index | aim_canon |
| 130 | `AIM-ION/canon/north_star/MASTER_PLAN_INDEX.md` | index | aim_canon |
| 130 | `AIM-ION/docs/AIM_OS_PRIME_CANON_INDEX_V1.md` | index | aim_docs |
| 130 | `AIM-ION/knowledge_architecture/systems/hhni/components/hierarchical_index/README.md` | front_door | aim_knowledge_architecture |
| 125 | `AIM-ION/canon/audits/system_audits/OPUS1_BROWSER_SYSTEM_VALIDATION_REPORT_V1.md` | validation_test | aim_canon |
| 125 | `AIM-ION/canon/north_star/GOALS_PLANS_QUALITY_VALIDATION_REPORT.md` | validation_test | aim_canon |
| 125 | `AIM-ION/canon/north_star/GOAL_TREE_VALIDATION_REPORT.md` | validation_test | aim_canon |
| 125 | `AIM-ION/knowledge_architecture/systems/seg/components/graph_schema/README.md` | front_door | aim_knowledge_architecture |
| 120 | `AIM-ION/knowledge_architecture/PROTOCOLS/SAM_PROTOCOL_INDEX.md` | index | aim_knowledge_architecture |
| 120 | `AIM-ION/knowledge_architecture/systems/self_improvement_protocol/system.index.lucid.json5` | index | aim_knowledge_architecture |
| 115 | `AIM-ION/coordination/epic_standards_overhaul/artifacts/validation/SUPER_INDEX_GATE_2025-10-30.md` | index | aim_lineage |
| 115 | `AIM-ION/coordination/epic_standards_overhaul/artifacts/validation/SUPER_INDEX_GATE_FULL_2025-10-30.md` | index | aim_lineage |
| 115 | `AIM-ION/ide_orchestration/prototypes/dac/src/services/lucid-chat/validation/index.ts` | index | aim_lineage |
| 115 | `AIM-ION/knowledge_architecture/validation/SUPER_INDEX.validation.md` | index | aim_knowledge_architecture |
| 115 | `AIM-ION/knowledge_architecture/validation/SYSTEM_INDEX.validation.md` | index | aim_knowledge_architecture |
| 100 | `AIM-ION/cursor-addon/ARCHIVE_COMPLETE/failed_attempts/START_HERE.md` | front_door | aim_cursor_addon |
| 100 | `AIM-ION/cursor-addon/START_HERE.md` | front_door | aim_cursor_addon |
| 100 | `AIM-ION/docs/roundtable/START_HERE.md` | front_door | aim_docs |
| 100 | `AIM-ION/ideas/START_HERE.md` | front_door | aim_lineage |
| 100 | `AIM-ION/knowledge_architecture/NAVIGATION/NAVIGATION_START_HERE.md` | front_door | aim_knowledge_architecture |
| 100 | `AIM-ION/knowledge_architecture/NAVIGATION_START_HERE.md` | front_door | aim_knowledge_architecture |
| 100 | `AIM-ION/knowledge_architecture/systems/lucid-ide/backend-api-system/START_HERE.md` | front_door | aim_knowledge_architecture |
| 100 | `AIM-ION/knowledge_architecture/systems/plix/textbook/unified/START_HERE.md` | front_door | aim_knowledge_architecture |
| 85 | `AIM-ION/archive/GITHUB_SETUP_INSTRUCTIONS.md` | instruction_prompt | aim_archive |
| 85 | `AIM-ION/cursor-addon/ARCHIVE_COMPLETE/failed_attempts/EMERGENCY_INSTRUCTIONS.md` | instruction_prompt | aim_cursor_addon |
| 85 | `AIM-ION/cursor-addon/ARCHIVE_COMPLETE/failed_attempts/INSTALLATION_INSTRUCTIONS.md` | instruction_prompt | aim_cursor_addon |
| 85 | `AIM-ION/cursor-addon/ARCHIVE_COMPLETE/failed_attempts/REINSTALLATION_INSTRUCTIONS.md` | instruction_prompt | aim_cursor_addon |

## ATLAS.zip

| Priority | Path | Role | Zone |
|---:|---|---|---|
| 70 | `ATLAS/README.md` | front_door | atlas_reference |
| 60 | `ATLAS/indexes/systems_index.yaml` | index | atlas_index |
| 60 | `ATLAS/systems/debug-adapter-protocol/00_identity.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/debug-adapter-protocol/01_scope.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/debug-adapter-protocol/02_architecture.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/debug-adapter-protocol/03_components.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/debug-adapter-protocol/04_process_memory_namespace.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/debug-adapter-protocol/05_storage_network_ipc.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/debug-adapter-protocol/06_security_permissions.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/debug-adapter-protocol/07_extension_tooling.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/debug-adapter-protocol/08_build_deploy_update.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/debug-adapter-protocol/09_operator_surface.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/debug-adapter-protocol/10_observability.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/debug-adapter-protocol/11_lineage.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/debug-adapter-protocol/12_relation_map.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/debug-adapter-protocol/13_evidence_ledger.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/debug-adapter-protocol/14_documented_vs_inferred.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/debug-adapter-protocol/relations.json` | schema_data | atlas_system_package |
| 60 | `ATLAS/systems/debug-adapter-protocol/sources.yaml` | schema_data | atlas_system_package |
| 60 | `ATLAS/systems/debug-adapter-protocol/tags.yaml` | schema_data | atlas_system_package |
| 60 | `ATLAS/systems/language-server-protocol/00_identity.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/language-server-protocol/01_scope.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/language-server-protocol/02_architecture.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/language-server-protocol/03_components.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/language-server-protocol/04_process_memory_namespace.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/language-server-protocol/05_storage_network_ipc.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/language-server-protocol/06_security_permissions.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/language-server-protocol/07_extension_tooling.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/language-server-protocol/08_build_deploy_update.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/language-server-protocol/09_operator_surface.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/language-server-protocol/10_observability.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/language-server-protocol/11_lineage.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/language-server-protocol/12_relation_map.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/language-server-protocol/13_evidence_ledger.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/language-server-protocol/14_documented_vs_inferred.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/language-server-protocol/relations.json` | schema_data | atlas_system_package |
| 60 | `ATLAS/systems/language-server-protocol/sources.yaml` | schema_data | atlas_system_package |
| 60 | `ATLAS/systems/language-server-protocol/tags.yaml` | schema_data | atlas_system_package |
| 60 | `ATLAS/systems/model-context-protocol/00_identity.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/model-context-protocol/01_scope.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/model-context-protocol/02_architecture.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/model-context-protocol/03_components.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/model-context-protocol/04_process_memory_namespace.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/model-context-protocol/05_storage_network_ipc.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/model-context-protocol/06_security_permissions.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/model-context-protocol/07_extension_tooling.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/model-context-protocol/08_build_deploy_update.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/model-context-protocol/09_operator_surface.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/model-context-protocol/10_observability.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/model-context-protocol/11_lineage.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/model-context-protocol/12_relation_map.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/model-context-protocol/13_evidence_ledger.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/model-context-protocol/14_documented_vs_inferred.md` | documentation | atlas_system_package |
| 60 | `ATLAS/systems/model-context-protocol/relations.json` | schema_data | atlas_system_package |
| 60 | `ATLAS/systems/model-context-protocol/sources.yaml` | schema_data | atlas_system_package |
| 60 | `ATLAS/systems/model-context-protocol/tags.yaml` | schema_data | atlas_system_package |
| 55 | `ATLAS/_meta/package_schema.yaml` | schema_data | atlas_constitution |
| 0 | `ATLAS/_meta/evidence_tiers.md` | documentation | atlas_constitution |
| 0 | `ATLAS/scripts/scaffold_ingress_bootspec_wave.py` | code | atlas_reference |
| 0 | `ATLAS/scripts/scaffold_mesh_boot_wave.py` | code | atlas_reference |

## EXTENSION.zip

| Priority | Path | Role | Zone |
|---:|---|---|---|
| 70 | `ion_chatops_bridge/README.md` | front_door | extension_chatops_bridge |
| 70 | `ion_chatops_bridge/manifest.json` | manifest | extension_chatops_bridge |
| 55 | `ion_chatops_bridge/src/schema.ts` | schema_data | extension_chatops_bridge |

## ION FULL DEVELOPMENT.zip

| Priority | Path | Role | Zone |
|---:|---|---|---|
| 205 | `ION_CODEX FULL/ION/05_context/archive/root_witness_manifests/FILES_ADDED_V63_PROTOCOLIZATION_MCP_MOUNT_AND_FULL_OPERATIONALIZATION.txt` | protocol | ion_archive_witness |
| 205 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/archive/root_witness_manifests/FILES_ADDED_V63_PROTOCOLIZATION_MCP_MOUNT_AND_FULL_OPERATIONALIZATION.txt` | protocol | custom_gpt_embedded_ion_source |
| 205 | `ION_CODEX FULL/ION_sandbox/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_AI_ASSISTANT_WORK_TEMPLATE_INSTANCE_EXERCISES_CANDIDATE_20260508T154333Z/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_PRUNE_PASS_3_STARTER_STATE_CANDIDATE/ION/05_context/archive/root_witness_manifests/FILES_ADDED_V63_PROTOCOLIZATION_MCP_MOUNT_AND_FULL_OPERATIONALIZATION.txt` | protocol | ion_archive_witness |
| 200 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/020_ACTIVE_STATE_INDEX/ACTIVE_RECEIPT_TAIL.jsonl` | state | custom_gpt_active_state |
| 190 | `ION_CODEX FULL/ION/02_architecture/MOUNTED_AGENT_IDENTITY_SCHEMA_PROTOCOL.md` | schema_data | ion_architecture |
| 190 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/02_architecture/MOUNTED_AGENT_IDENTITY_SCHEMA_PROTOCOL.md` | schema_data | custom_gpt_embedded_ion_source |
| 190 | `ION_CODEX FULL/ION_sandbox/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_AI_ASSISTANT_WORK_TEMPLATE_INSTANCE_EXERCISES_CANDIDATE_20260508T154333Z/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_PRUNE_PASS_3_STARTER_STATE_CANDIDATE/ION/02_architecture/MOUNTED_AGENT_IDENTITY_SCHEMA_PROTOCOL.md` | schema_data | ion_architecture |
| 185 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/docs/validation/V1_4_PRUNE_PASS_4_MANIFEST_REPAIR_RECEIPT_20260507.json` | manifest | custom_gpt_embedded_ion_source |
| 185 | `ION_CODEX FULL/ION_sandbox/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_AI_ASSISTANT_WORK_TEMPLATE_INSTANCE_EXERCISES_CANDIDATE_20260508T154333Z/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_PRUNE_PASS_3_STARTER_STATE_CANDIDATE/ION/docs/validation/V1_4_PRUNE_PASS_4_MANIFEST_REPAIR_RECEIPT_20260507.json` | manifest | ion_sandbox |
| 160 | `ION_CODEX FULL/ION/05_context/current/CONTAINMENT_RECEIPT_V123_ROOT_AUTHORITY_BUNDLE_START_HERE.json` | front_door | ion_current_context |
| 160 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_5_saved_files/01_core_mount/ION_CUSTOM_GPT_INSTRUCTIONS_V2_5.md` | instruction_prompt | custom_gpt_embedded_ion_source |
| 160 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/030_CUSTOM_GPT_ADAPTER/v2_5_saved_files/01_core_mount/ION_CUSTOM_GPT_INSTRUCTIONS_V2_5.md` | instruction_prompt | custom_gpt_product_adapter |
| 160 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/current/CONTAINMENT_RECEIPT_V123_ROOT_AUTHORITY_BUNDLE_START_HERE.json` | front_door | custom_gpt_embedded_ion_source |
| 160 | `ION_CODEX FULL/ION_sandbox/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_AI_ASSISTANT_WORK_TEMPLATE_INSTANCE_EXERCISES_CANDIDATE_20260508T154333Z/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_PRUNE_PASS_3_STARTER_STATE_CANDIDATE/ION/05_context/current/CONTAINMENT_RECEIPT_V123_ROOT_AUTHORITY_BUNDLE_START_HERE.json` | front_door | ion_current_context |
| 145 | `ION_CODEX FULL/ION/05_context/archive/root_witness_manifests/FILES_ADDED_V110_PACKAGE_MOUNTABILITY_AND_OPTIONAL_EVIDENCE_STATUS.txt` | documentation | ion_archive_witness |
| 145 | `ION_CODEX FULL/ION/05_context/comms/kernel_router_runs/2026-04-12_phase1_disagreement_drill_browser_mount_boundary/README.md` | front_door | ion_full_repo |
| 145 | `ION_CODEX FULL/ION/05_context/comms/kernel_router_runs/2026-04-12_phase1_mount_proof_and_context_feed/README.md` | front_door | ion_full_repo |
| 145 | `ION_CODEX FULL/ION/05_context/signals/v78_canonical_mount_demo_packet_20260427.json` | schema_data | ion_full_repo |
| 145 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/archive/root_witness_manifests/FILES_ADDED_V110_PACKAGE_MOUNTABILITY_AND_OPTIONAL_EVIDENCE_STATUS.txt` | agent_carrier | custom_gpt_embedded_ion_source |
| 145 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/comms/kernel_router_runs/2026-04-12_phase1_disagreement_drill_browser_mount_boundary/README.md` | front_door | custom_gpt_embedded_ion_source |
| 145 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/comms/kernel_router_runs/2026-04-12_phase1_mount_proof_and_context_feed/README.md` | front_door | custom_gpt_embedded_ion_source |
| 145 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/signals/v78_canonical_mount_demo_packet_20260427.json` | schema_data | custom_gpt_embedded_ion_source |
| 145 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/receipts/CUSTOM_GPT_CARRIER_PACKAGE_V2_6_4_8K_INSTRUCTIONS_RECEIPT_20260508T230345Z.json` | instruction_prompt | custom_gpt_embedded_ion_source |
| 145 | `ION_CODEX FULL/ION_sandbox/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_AI_ASSISTANT_WORK_TEMPLATE_INSTANCE_EXERCISES_CANDIDATE_20260508T154333Z/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_PRUNE_PASS_3_STARTER_STATE_CANDIDATE/ION/05_context/archive/root_witness_manifests/FILES_ADDED_V110_PACKAGE_MOUNTABILITY_AND_OPTIONAL_EVIDENCE_STATUS.txt` | template | ion_archive_witness |
| 145 | `ION_CODEX FULL/ION_sandbox/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_AI_ASSISTANT_WORK_TEMPLATE_INSTANCE_EXERCISES_CANDIDATE_20260508T154333Z/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_PRUNE_PASS_3_STARTER_STATE_CANDIDATE/ION/05_context/comms/kernel_router_runs/2026-04-12_phase1_disagreement_drill_browser_mount_boundary/README.md` | front_door | ion_sandbox |
| 145 | `ION_CODEX FULL/ION_sandbox/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_AI_ASSISTANT_WORK_TEMPLATE_INSTANCE_EXERCISES_CANDIDATE_20260508T154333Z/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_PRUNE_PASS_3_STARTER_STATE_CANDIDATE/ION/05_context/comms/kernel_router_runs/2026-04-12_phase1_mount_proof_and_context_feed/README.md` | front_door | ion_sandbox |
| 145 | `ION_CODEX FULL/ION_sandbox/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_AI_ASSISTANT_WORK_TEMPLATE_INSTANCE_EXERCISES_CANDIDATE_20260508T154333Z/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_PRUNE_PASS_3_STARTER_STATE_CANDIDATE/ION/05_context/signals/v78_canonical_mount_demo_packet_20260427.json` | schema_data | ion_sandbox |
| 140 | `ION_CODEX FULL/ION/05_context/archive/root_witness_manifests/FILES_ADDED_V94_CURSOR_CANONICAL_WORKFLOW_UNIFICATION.txt` | documentation | ion_archive_witness |
| 140 | `ION_CODEX FULL/ION/05_context/archive/root_witness_manifests/README.md` | front_door | ion_archive_witness |
| 140 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/020_ACTIVE_STATE_INDEX/ACTIVE_ACTION_SURFACE_INDEX.md` | index | custom_gpt_active_state |
| 140 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/020_ACTIVE_STATE_INDEX/ACTIVE_DOMAIN_AGENT_INDEX.json` | index | custom_gpt_active_state |
| 140 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/020_ACTIVE_STATE_INDEX/ACTIVE_STATE_SUMMARY.md` | state | custom_gpt_active_state |
| 140 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/archive/root_witness_manifests/FILES_ADDED_V94_CURSOR_CANONICAL_WORKFLOW_UNIFICATION.txt` | agent_carrier | custom_gpt_embedded_ion_source |
| 140 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/archive/root_witness_manifests/README.md` | front_door | custom_gpt_embedded_ion_source |
| 140 | `ION_CODEX FULL/ION_sandbox/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_AI_ASSISTANT_WORK_TEMPLATE_INSTANCE_EXERCISES_CANDIDATE_20260508T154333Z/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_PRUNE_PASS_3_STARTER_STATE_CANDIDATE/ION/05_context/archive/root_witness_manifests/FILES_ADDED_V94_CURSOR_CANONICAL_WORKFLOW_UNIFICATION.txt` | template | ion_archive_witness |
| 140 | `ION_CODEX FULL/ION_sandbox/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_AI_ASSISTANT_WORK_TEMPLATE_INSTANCE_EXERCISES_CANDIDATE_20260508T154333Z/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_PRUNE_PASS_3_STARTER_STATE_CANDIDATE/ION/05_context/archive/root_witness_manifests/README.md` | front_door | ion_archive_witness |
| 135 | `ION_CODEX FULL/ION/00_BOOTSTRAP/V63_ION_MCP_MOUNT_AND_ACCOUNT_CONNECTION_PROTOCOL_LOCK.md` | protocol | ion_bootstrap_lock |
| 135 | `ION_CODEX FULL/ION/02_architecture/FRONT_DOOR_SELF_MOUNT_BINDING_PROTOCOL.md` | protocol | ion_architecture |
| 135 | `ION_CODEX FULL/ION/02_architecture/ION_CURSOR_FULL_WORKFLOW_MOUNT_PROTOCOL.md` | protocol | ion_architecture |
| 135 | `ION_CODEX FULL/ION/02_architecture/ION_MCP_FRONT_DOOR_AND_MOUNT_SESSION_PROTOCOL.md` | protocol | ion_architecture |
| 135 | `ION_CODEX FULL/ION/02_architecture/ROLE_CHASSIS_MOUNT_PROTOCOL.md` | protocol | ion_architecture |
| 135 | `ION_CODEX FULL/ION/02_architecture/SELF_MOUNT_FRONT_DOOR_BINDING_PROTOCOL.md` | protocol | ion_architecture |
| 135 | `ION_CODEX FULL/ION/02_architecture/SELF_MOUNT_GRAPH_INTEGRATION_PROTOCOL.md` | protocol | ion_architecture |
| 135 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/00_BOOTSTRAP/V63_ION_MCP_MOUNT_AND_ACCOUNT_CONNECTION_PROTOCOL_LOCK.md` | protocol | custom_gpt_embedded_ion_source |
| 135 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/02_architecture/FRONT_DOOR_SELF_MOUNT_BINDING_PROTOCOL.md` | protocol | custom_gpt_embedded_ion_source |
| 135 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/02_architecture/ION_CURSOR_FULL_WORKFLOW_MOUNT_PROTOCOL.md` | protocol | custom_gpt_embedded_ion_source |
| 135 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/02_architecture/ION_MCP_FRONT_DOOR_AND_MOUNT_SESSION_PROTOCOL.md` | protocol | custom_gpt_embedded_ion_source |
| 135 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/02_architecture/ROLE_CHASSIS_MOUNT_PROTOCOL.md` | protocol | custom_gpt_embedded_ion_source |
| 135 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/02_architecture/SELF_MOUNT_FRONT_DOOR_BINDING_PROTOCOL.md` | protocol | custom_gpt_embedded_ion_source |
| 135 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/02_architecture/SELF_MOUNT_GRAPH_INTEGRATION_PROTOCOL.md` | protocol | custom_gpt_embedded_ion_source |
| 135 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/current/execution_cycles/2026-05-08T034831Z0000_carrier_continue_mount_ion_and_start_the_self_knowledge_domain_state_workpack_recover_existing_se/01_steward_context_load_receipt.json` | state | custom_gpt_embedded_ion_source |
| 135 | `ION_CODEX FULL/ION/06_intelligence/orchestration/custom_gpt/v2_6_packaging/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/current/execution_cycles/2026-05-08T034831Z0000_carrier_continue_mount_ion_and_start_the_self_knowledge_domain_state_workpack_recover_existing_se/02_vestige_context_load_receipt.json` | state | custom_gpt_embedded_ion_source |
| 135 | `ION_CODEX FULL/ION_sandbox/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_AI_ASSISTANT_WORK_TEMPLATE_INSTANCE_EXERCISES_CANDIDATE_20260508T154333Z/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_PRUNE_PASS_3_STARTER_STATE_CANDIDATE/ION/00_BOOTSTRAP/V63_ION_MCP_MOUNT_AND_ACCOUNT_CONNECTION_PROTOCOL_LOCK.md` | protocol | ion_bootstrap_lock |
| 135 | `ION_CODEX FULL/ION_sandbox/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_AI_ASSISTANT_WORK_TEMPLATE_INSTANCE_EXERCISES_CANDIDATE_20260508T154333Z/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_PRUNE_PASS_3_STARTER_STATE_CANDIDATE/ION/02_architecture/FRONT_DOOR_SELF_MOUNT_BINDING_PROTOCOL.md` | protocol | ion_architecture |
| 135 | `ION_CODEX FULL/ION_sandbox/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_AI_ASSISTANT_WORK_TEMPLATE_INSTANCE_EXERCISES_CANDIDATE_20260508T154333Z/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_PRUNE_PASS_3_STARTER_STATE_CANDIDATE/ION/02_architecture/ION_CURSOR_FULL_WORKFLOW_MOUNT_PROTOCOL.md` | protocol | ion_architecture |
| 135 | `ION_CODEX FULL/ION_sandbox/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_AI_ASSISTANT_WORK_TEMPLATE_INSTANCE_EXERCISES_CANDIDATE_20260508T154333Z/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_PRUNE_PASS_3_STARTER_STATE_CANDIDATE/ION/02_architecture/ION_MCP_FRONT_DOOR_AND_MOUNT_SESSION_PROTOCOL.md` | protocol | ion_architecture |
| 135 | `ION_CODEX FULL/ION_sandbox/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_AI_ASSISTANT_WORK_TEMPLATE_INSTANCE_EXERCISES_CANDIDATE_20260508T154333Z/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_PRUNE_PASS_3_STARTER_STATE_CANDIDATE/ION/02_architecture/ROLE_CHASSIS_MOUNT_PROTOCOL.md` | protocol | ion_architecture |
| 135 | `ION_CODEX FULL/ION_sandbox/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_AI_ASSISTANT_WORK_TEMPLATE_INSTANCE_EXERCISES_CANDIDATE_20260508T154333Z/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_PRUNE_PASS_3_STARTER_STATE_CANDIDATE/ION/02_architecture/SELF_MOUNT_FRONT_DOOR_BINDING_PROTOCOL.md` | protocol | ion_architecture |
| 135 | `ION_CODEX FULL/ION_sandbox/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_AI_ASSISTANT_WORK_TEMPLATE_INSTANCE_EXERCISES_CANDIDATE_20260508T154333Z/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_PRUNE_PASS_3_STARTER_STATE_CANDIDATE/ION/02_architecture/SELF_MOUNT_GRAPH_INTEGRATION_PROTOCOL.md` | protocol | ion_architecture |
| 135 | `ION_CODEX FULL/ION_sandbox/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_AI_ASSISTANT_WORK_TEMPLATE_INSTANCE_EXERCISES_CANDIDATE_20260508T154333Z/ION_FULL_GPT_SANDBOX_AGENT_PACKAGE_v1_4_PRUNE_PASS_3_STARTER_STATE_CANDIDATE/ION/05_context/current/execution_cycles/2026-05-08T034831Z0000_carrier_continue_mount_ion_and_start_the_self_knowledge_domain_state_workpack_recover_existing_se/01_steward_context_load_receipt.json` | state | ion_current_context |

## ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7.zip

| Priority | Path | Role | Zone |
|---:|---|---|---|
| 125 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_demo_packet_runner/schemas/tool_manifest.py` | manifest | agent_framework_research |
| 125 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_langgraph_packet_lifecycle/schemas/tool_manifest.py` | manifest | agent_framework_research |
| 125 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/validation_manifest.json` | manifest | agent_framework_research |
| 125 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/validation_manifest_v0_2.json` | manifest | agent_framework_research |
| 125 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/validation_manifest_v0_3.json` | manifest | agent_framework_research |
| 125 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/validation_manifest_v0_4.json` | manifest | agent_framework_research |
| 125 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/validation_manifest_v0_5.json` | manifest | agent_framework_research |
| 125 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/validation_manifest_v0_6.json` | manifest | agent_framework_research |
| 125 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/validation_manifest_v0_7.json` | manifest | agent_framework_research |
| 125 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/validation_manifest_v0_8.json` | manifest | agent_framework_research |
| 125 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/validation_manifest_v0_9.json` | manifest | agent_framework_research |
| 125 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/validation_manifest_v1_0.json` | manifest | agent_framework_research |
| 125 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/validation_manifest_v1_0.md` | manifest | agent_framework_research |
| 125 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/validation_manifest_v1_1.json` | manifest | agent_framework_research |
| 125 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/validation_manifest_v1_2.json` | manifest | agent_framework_research |
| 125 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/validation_manifest_v1_3.json` | manifest | agent_framework_research |
| 125 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/validation_manifest_v1_4.json` | manifest | agent_framework_research |
| 125 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/validation_manifest_v1_5.json` | manifest | agent_framework_research |
| 125 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/validation_manifest_v1_6.json` | manifest | agent_framework_research |
| 125 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/validation_manifest_v1_7.json` | manifest | agent_framework_research |
| 115 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_demo_packet_runner/schemas/receipt.py` | receipt | agent_framework_research |
| 115 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_langgraph_packet_lifecycle/schemas/receipt.py` | receipt | agent_framework_research |
| 70 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/README.md` | front_door | agent_framework_research |
| 70 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_continuity_bridge_demo/README.md` | front_door | agent_framework_research |
| 70 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_demo_packet_runner/README.md` | front_door | agent_framework_research |
| 70 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_demo_packet_runner/examples/mcp_tool_manifest_demo.json` | manifest | agent_framework_research |
| 70 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_file_continuity_bridge_mvp/README.md` | front_door | agent_framework_research |
| 70 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_file_continuity_bridge_mvp/sample_inputs/source_manifest.csv` | manifest | agent_framework_research |
| 70 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_hitl_settlement_gate/README.md` | front_door | agent_framework_research |
| 70 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_langgraph_packet_lifecycle/README.md` | front_door | agent_framework_research |
| 70 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_langgraph_packet_lifecycle/examples/mcp_tool_manifest_demo.json` | manifest | agent_framework_research |
| 70 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_langgraph_packet_lifecycle/outputs/export_manifest.json` | manifest | agent_framework_research |
| 70 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_langgraph_packet_lifecycle/requirements_optional.txt` | agent_carrier | agent_framework_research |
| 70 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_wrapper_options/README.md` | front_door | agent_framework_research |
| 70 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/source_manifest.csv` | manifest | agent_framework_research |
| 70 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/source_manifest.json` | manifest | agent_framework_research |
| 70 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/source_manifest_v0_3.csv` | manifest | agent_framework_research |
| 70 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/source_manifest_v0_3.json` | manifest | agent_framework_research |
| 65 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/AFR_002_source_authority_coverage_expansion_report_v0_3.md` | authority | agent_framework_research |
| 65 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_file_continuity_bridge_mvp/outputs/state_surface_sync_report.json` | state | agent_framework_research |
| 65 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/source_authority_policy_v0_3.md` | authority | agent_framework_research |
| 65 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/source_authority_table_v0_3.csv` | authority | agent_framework_research |
| 65 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/source_authority_table_v0_3.json` | authority | agent_framework_research |
| 65 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/state_surface_sync_report_v1_2.md` | state | agent_framework_research |
| 65 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/state_surface_sync_report_v1_3.md` | state | agent_framework_research |
| 65 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/state_surface_sync_report_v1_5.md` | state | agent_framework_research |
| 60 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/AFR_004_deep_comparator_state_memory_receipts_settlement_report_v0_5.md` | state | agent_framework_research |
| 60 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_continuity_bridge_demo/outputs/bridge_receipt_candidate.json` | receipt | agent_framework_research |
| 60 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_demo_packet_runner/outputs/receipt_candidate.json` | receipt | agent_framework_research |
| 60 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_demo_packet_runner/runner/create_receipt_candidate.py` | receipt | agent_framework_research |
| 60 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_file_continuity_bridge_mvp/outputs/bridge_receipt_candidate.json` | receipt | agent_framework_research |
| 60 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_file_continuity_bridge_mvp/sample_inputs/prior_receipt_candidate.json` | receipt | agent_framework_research |
| 60 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_hitl_settlement_gate/outputs/settlement_receipt_candidates.json` | receipt | agent_framework_research |
| 60 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_langgraph_packet_lifecycle/outputs/receipt_candidate.json` | receipt | agent_framework_research |
| 60 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/ion_langgraph_packet_lifecycle/runner/create_receipt_candidate.py` | receipt | agent_framework_research |
| 60 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/receipt_candidate.json` | receipt | agent_framework_research |
| 60 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/receipt_candidate.md` | receipt | agent_framework_research |
| 60 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/receipt_candidate_AFR_001_v0_2.json` | receipt | agent_framework_research |
| 60 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/receipt_candidate_AFR_001_v0_2.md` | receipt | agent_framework_research |
| 60 | `ION_AGENT_FRAMEWORK_RESEARCH_CONTEXT_PACKAGE_v1_7/receipt_candidate_AFR_002_v0_3.json` | receipt | agent_framework_research |

## ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_7_CANDIDATE_20260509T224136Z.zip

| Priority | Path | Role | Zone |
|---:|---|---|---|
| 205 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/archive/root_witness_manifests/FILES_ADDED_V63_PROTOCOLIZATION_MCP_MOUNT_AND_FULL_OPERATIONALIZATION.txt` | protocol | custom_gpt_embedded_ion_source |
| 200 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/020_ACTIVE_STATE_INDEX/ACTIVE_RECEIPT_TAIL.jsonl` | state | custom_gpt_active_state |
| 190 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/02_architecture/MOUNTED_AGENT_IDENTITY_SCHEMA_PROTOCOL.md` | schema_data | custom_gpt_embedded_ion_source |
| 185 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/docs/validation/V1_4_PRUNE_PASS_4_MANIFEST_REPAIR_RECEIPT_20260507.json` | manifest | custom_gpt_embedded_ion_source |
| 160 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/030_CUSTOM_GPT_ADAPTER/v2_5_saved_files/01_core_mount/ION_CUSTOM_GPT_INSTRUCTIONS_V2_5.md` | instruction_prompt | custom_gpt_product_adapter |
| 160 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/current/CONTAINMENT_RECEIPT_V123_ROOT_AUTHORITY_BUNDLE_START_HERE.json` | front_door | custom_gpt_embedded_ion_source |
| 145 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/archive/root_witness_manifests/FILES_ADDED_V110_PACKAGE_MOUNTABILITY_AND_OPTIONAL_EVIDENCE_STATUS.txt` | agent_carrier | custom_gpt_embedded_ion_source |
| 145 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/comms/kernel_router_runs/2026-04-12_phase1_disagreement_drill_browser_mount_boundary/README.md` | front_door | custom_gpt_embedded_ion_source |
| 145 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/comms/kernel_router_runs/2026-04-12_phase1_mount_proof_and_context_feed/README.md` | front_door | custom_gpt_embedded_ion_source |
| 145 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/signals/v78_canonical_mount_demo_packet_20260427.json` | schema_data | custom_gpt_embedded_ion_source |
| 140 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/020_ACTIVE_STATE_INDEX/ACTIVE_ACTION_SURFACE_INDEX.md` | index | custom_gpt_active_state |
| 140 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/020_ACTIVE_STATE_INDEX/ACTIVE_DOMAIN_AGENT_INDEX.json` | index | custom_gpt_active_state |
| 140 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/020_ACTIVE_STATE_INDEX/ACTIVE_STATE_SUMMARY.md` | state | custom_gpt_active_state |
| 140 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/archive/root_witness_manifests/FILES_ADDED_V94_CURSOR_CANONICAL_WORKFLOW_UNIFICATION.txt` | agent_carrier | custom_gpt_embedded_ion_source |
| 140 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/archive/root_witness_manifests/README.md` | front_door | custom_gpt_embedded_ion_source |
| 135 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/00_BOOTSTRAP/V63_ION_MCP_MOUNT_AND_ACCOUNT_CONNECTION_PROTOCOL_LOCK.md` | protocol | custom_gpt_embedded_ion_source |
| 135 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/02_architecture/FRONT_DOOR_SELF_MOUNT_BINDING_PROTOCOL.md` | protocol | custom_gpt_embedded_ion_source |
| 135 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/02_architecture/ION_CURSOR_FULL_WORKFLOW_MOUNT_PROTOCOL.md` | protocol | custom_gpt_embedded_ion_source |
| 135 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/02_architecture/ION_MCP_FRONT_DOOR_AND_MOUNT_SESSION_PROTOCOL.md` | protocol | custom_gpt_embedded_ion_source |
| 135 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/02_architecture/ROLE_CHASSIS_MOUNT_PROTOCOL.md` | protocol | custom_gpt_embedded_ion_source |
| 135 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/02_architecture/SELF_MOUNT_FRONT_DOOR_BINDING_PROTOCOL.md` | protocol | custom_gpt_embedded_ion_source |
| 135 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/02_architecture/SELF_MOUNT_GRAPH_INTEGRATION_PROTOCOL.md` | protocol | custom_gpt_embedded_ion_source |
| 135 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/current/execution_cycles/2026-05-08T034831Z0000_carrier_continue_mount_ion_and_start_the_self_knowledge_domain_state_workpack_recover_existing_se/01_steward_context_load_receipt.json` | state | custom_gpt_embedded_ion_source |
| 135 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/current/execution_cycles/2026-05-08T034831Z0000_carrier_continue_mount_ion_and_start_the_self_knowledge_domain_state_workpack_recover_existing_se/02_vestige_context_load_receipt.json` | state | custom_gpt_embedded_ion_source |
| 130 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/02_architecture/CANON_PROMOTION_AND_RATIFICATION_PROTOCOL.md` | protocol | custom_gpt_embedded_ion_source |
| 130 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/02_architecture/ION_CURSOR_CANONICAL_WORKFLOW_UNIFICATION_PROTOCOL.md` | protocol | custom_gpt_embedded_ion_source |
| 130 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/02_architecture/ION_JOC_OPERATOR_REVIEWED_EXPORT_HANDOFF_MANIFEST_PREVIEW_PROTOCOL.md` | manifest | custom_gpt_embedded_ion_source |
| 130 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/02_architecture/MANIFEST_AND_ROUTE_STATE_PROTOCOL.md` | manifest | custom_gpt_embedded_ion_source |
| 130 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/03_registry/cursor_subagent_role_mount.schema.json` | schema_data | custom_gpt_embedded_ion_source |
| 130 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/03_registry/front_door_self_mount_binding.schema.json` | schema_data | custom_gpt_embedded_ion_source |
| 130 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/03_registry/ion_mcp_mount_session.schema.json` | schema_data | custom_gpt_embedded_ion_source |
| 130 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/03_registry/mounted_agent_identity.schema.json` | schema_data | custom_gpt_embedded_ion_source |
| 130 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/03_registry/self_mount_graph_integration.schema.json` | schema_data | custom_gpt_embedded_ion_source |
| 130 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/archive/root_witness_manifests/FILES_ADDED_V71_HOSTED_MCP_STORAGE_RECEIPT_LEDGER_ALPHA.txt` | receipt | custom_gpt_embedded_ion_source |
| 130 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/archive/root_witness_manifests/FULL_PROJECT_CONSOLIDATION_RECEIPT_V100_20260501.txt` | receipt | custom_gpt_embedded_ion_source |
| 130 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/archive/root_witness_manifests/FULL_PROJECT_CONSOLIDATION_RECEIPT_V102_20260502.txt` | receipt | custom_gpt_embedded_ion_source |
| 130 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/archive/root_witness_manifests/FULL_PROJECT_CONSOLIDATION_RECEIPT_V103_20260502.txt` | receipt | custom_gpt_embedded_ion_source |
| 130 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/archive/root_witness_manifests/FULL_PROJECT_CONSOLIDATION_RECEIPT_V104_20260502.txt` | receipt | custom_gpt_embedded_ion_source |
| 130 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/signals/v94_cursor_canonical_workflow_unification_receipt_20260430.txt` | receipt | custom_gpt_embedded_ion_source |
| 130 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/06_intelligence/orchestration/2026-04-10_bootstrap_manifest_protocol_next_packet.md` | manifest | custom_gpt_embedded_ion_source |
| 130 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/06_intelligence/orchestration/corpus_recovery/32_single_carrier_full_spectrum_protocol_landing/README.md` | front_door | custom_gpt_embedded_ion_source |
| 125 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/060_ACTION_SCHEMAS/CONNECTION_SURFACE_MANIFEST_V2_6_7.md` | manifest | custom_gpt_action_schema |
| 125 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/060_ACTION_SCHEMAS/README.md` | front_door | custom_gpt_action_schema |
| 125 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/060_ACTION_SCHEMAS/README_V2_6_ACTION_SCHEMAS.md` | front_door | custom_gpt_action_schema |
| 125 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/060_ACTION_SCHEMAS/action_gateway/README.md` | front_door | custom_gpt_action_schema |
| 125 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/060_ACTION_SCHEMAS/mcp_json_rpc/README.md` | front_door | custom_gpt_action_schema |
| 125 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/090_VALIDATION/PACKAGE_MANIFEST.json` | manifest | custom_gpt_root |
| 125 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/03_registry/ion_lifecycle_package_manifest.schema.json` | manifest | custom_gpt_embedded_ion_source |
| 125 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/03_registry/joc_export_handoff_manifest_view_model.schema.json` | manifest | custom_gpt_embedded_ion_source |
| 125 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/05_context/comms/kernel_router_runs/2026-04-10_m14_continuation_bundle_takeover_entry_activation_validation/README.md` | front_door | custom_gpt_embedded_ion_source |
| 125 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/06_intelligence/specs/T09_ManifestRouteStateSchema.spec.md` | manifest | custom_gpt_embedded_ion_source |
| 125 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/product/data_schema/README.md` | front_door | custom_gpt_product_adapter |
| 125 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/product/data_schema/migrations/README.md` | front_door | custom_gpt_product_adapter |
| 125 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/product/data_schema/schemas/artifact_manifest.schema.json` | manifest | custom_gpt_product_adapter |
| 125 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/product/data_schema/schemas/ion_data_manifest.schema.json` | manifest | custom_gpt_product_adapter |
| 125 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/product/package_guides/seeded_base_domains_reference/ION_DATA_SCHEMA/README.md` | front_door | custom_gpt_product_adapter |
| 125 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/product/package_guides/seeded_base_domains_reference/ION_DATA_SCHEMA/migrations/README.md` | front_door | custom_gpt_product_adapter |
| 125 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/product/package_guides/seeded_base_domains_reference/ION_DATA_SCHEMA/schemas/artifact_manifest.schema.json` | manifest | custom_gpt_product_adapter |
| 125 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/product/package_guides/seeded_base_domains_reference/ION_DATA_SCHEMA/schemas/ion_data_manifest.schema.json` | manifest | custom_gpt_product_adapter |
| 120 | `ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508/ION/02_architecture/APPROVED_CONTEXT_INDEX_PROTOCOL.md` | index | custom_gpt_embedded_ion_source |

## _ui_canon.zip

| Priority | Path | Role | Zone |
|---:|---|---|---|
| 140 | `_ui_canon_bundle/JOC_UI_REQUIREMENTS.md` | documentation | ui_joc_opus_canon |
| 70 | `_ui_canon_bundle/CANON_JOC_UI_ARCHITECTURE.md` | documentation | ui_joc_opus_canon |
| 70 | `_ui_canon_bundle/OPUS1_JOC_ARCHITECTURE.md` | documentation | ui_joc_opus_canon |
| 70 | `_ui_canon_bundle/OPUS1_JOC_COMPUTE_AND_IDE_LAYOUT.md` | documentation | ui_joc_opus_canon |
| 70 | `_ui_canon_bundle/OPUS1_JOC_GOALS_AND_ROADMAP.md` | documentation | ui_joc_opus_canon |
| 70 | `_ui_canon_bundle/OPUS1_JOC_MASTER_VISION.md` | documentation | ui_joc_opus_canon |
| 70 | `_ui_canon_bundle/OPUS1_JOC_UI_DESIGN.md` | documentation | ui_joc_opus_canon |
| 70 | `_ui_canon_bundle/OPUS_VISUAL_CANON_CONTEXT_PROMPT.md` | instruction_prompt | ui_joc_opus_canon |
| 70 | `_ui_canon_bundle/OPUS_VISUAL_EDITOR_ARCHITECTURE.md` | documentation | ui_joc_opus_canon |
| 70 | `_ui_canon_bundle/OPUS_VISUAL_EDITOR_CANON.md` | documentation | ui_joc_opus_canon |
| 70 | `_ui_canon_bundle/OPUS_VISUAL_SETTINGS_CANON.md` | documentation | ui_joc_opus_canon |
| 70 | `_ui_canon_bundle/ULTIMATE_OPUS_VISUAL_INTERFACE_CANON.md` | documentation | ui_joc_opus_canon |
| 70 | `_ui_canon_bundle/ui_evolution_plan.md` | documentation | ui_joc_opus_canon |
| 70 | `_ui_canon_bundle/uishader.txt` | documentation | ui_joc_opus_canon |

## dAimon3.zip

| Priority | Path | Role | Zone |
|---:|---|---|---|
| 70 | `dAimon/README.md` | front_door | daimon |
| 70 | `dAimon/agent_builder/agent_tool_manifest.yaml` | manifest | daimon |
| 70 | `dAimon/docs/ui_canon_product_plan.md` | documentation | daimon |
| 70 | `dAimon/ion_kernel/requirements.txt` | documentation | daimon |
| 60 | `dAimon/ion_kernel/receipt_chain.py` | receipt | daimon |
| 60 | `dAimon/orchestration/receipt_registry.json` | receipt | daimon |
| 60 | `dAimon/sample_outputs/live_vertical_slice_receipt.json` | receipt | daimon |
| 60 | `dAimon/sample_outputs/receipt_candidate.json` | receipt | daimon |
| 55 | `dAimon/ion_kernel/schemas.py` | schema_data | daimon |
| 55 | `dAimon/mcp/mongodb_atlas_schema_contract_v0_8.json` | schema_data | daimon |
| 55 | `dAimon/sample_outputs/agent_builder_mcp_trace_validation.json` | validation_test | daimon |
| 55 | `dAimon/sample_outputs/mongodb_contract_validation.json` | validation_test | daimon |
| 55 | `dAimon/sample_outputs/orchestration_validation.json` | validation_test | daimon |
| 0 | `dAimon/agent_builder/openapi_tools_contract.json` | schema_data | daimon |
| 0 | `dAimon/mcp/mongodb_mcp_visibility_contract.json` | schema_data | daimon |
| 0 | `dAimon/sample_outputs/gemini_candidate_output.json` | schema_data | daimon |
| 0 | `dAimon/sample_outputs/gemini_handoff_context_bundle.json` | schema_data | daimon |
| 0 | `dAimon/sample_outputs/gemini_handoff_request.json` | schema_data | daimon |
| 0 | `dAimon/sample_outputs/gemini_handoff_response.json` | schema_data | daimon |
| 0 | `dAimon/sample_outputs/gemini_handoff_summary.json` | schema_data | daimon |
| 0 | `dAimon/sample_outputs/mongodb_adapter_contract_demo.json` | schema_data | daimon |
| 0 | `dAimon/scripts/run_adapter_contract_demo.py` | code | daimon |
| 0 | `dAimon/scripts/run_gemini_handoff_demo.py` | code | daimon |
| 0 | `dAimon/scripts/validate_mongodb_contract.py` | code | daimon |

## dAimon_ION3.zip

| Priority | Path | Role | Zone |
|---:|---|---|---|
| 125 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/validation_manifest_v1_0.json` | manifest | daimon |
| 70 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/FILE_MANIFEST_SHA256.json` | manifest | daimon |
| 70 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/MANIFEST.json` | manifest | daimon |
| 70 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/README.md` | front_door | daimon |
| 70 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/evidence/source_v1_0_snapshots/README.md.ORIGINAL_v1_0` | front_door | daimon |
| 70 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/evidence/source_v1_0_snapshots/repo_scaffold__ion-continuity-bridge__README.md.ORIGINAL_v1_0` | front_door | daimon |
| 70 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/repo_scaffold/ion-continuity-bridge/README.md` | front_door | daimon |
| 70 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/repo_scaffold/ion-continuity-bridge/agent_builder/agent_tool_manifest.yaml` | manifest | daimon |
| 70 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/repo_scaffold/ion-continuity-bridge/ion_kernel/requirements.txt` | agent_carrier | daimon |
| 70 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/source_audit/PREVIOUS_INCOMPLETE_V1_1_MANIFEST.json` | manifest | daimon |
| 60 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/receipt_candidate_RAH_010_v1_0.json` | receipt | daimon |
| 60 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/receipt_candidate_RAH_011A_v1_1_full.json` | receipt | daimon |
| 60 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/repo_scaffold/ion-continuity-bridge/ion_kernel/receipt_chain.py` | receipt | daimon |
| 60 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/repo_scaffold/ion-continuity-bridge/sample_outputs/receipt_candidate.json` | receipt | daimon |
| 55 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/repo_scaffold/ion-continuity-bridge/ion_kernel/schemas.py` | schema_data | daimon |
| 55 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/repo_scaffold/ion-continuity-bridge/mcp/mongodb_atlas_schema_contract_v0_8.json` | schema_data | daimon |
| 55 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/repo_scaffold/ion-continuity-bridge/sample_outputs/mongodb_contract_validation.json` | validation_test | daimon |
| 55 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/source_audit/PREVIOUS_INCOMPLETE_V1_1_VALIDATION_NOTE.json` | validation_test | daimon |
| 55 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/validation/LOCAL_VALIDATION_SUMMARY.md` | validation_test | daimon |
| 55 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/validation/RAH_011A_LOCAL_HARNESS_VALIDATION_20260509T175737Z.json` | validation_test | daimon |
| 55 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/validation/VALIDATION_NOTE.json` | validation_test | daimon |
| 0 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/RAH_038_capability_graph_dashboard_trace_spec_v1_0.md` | agent_carrier | daimon |
| 0 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/handoff/NEXT_CARRIER_BOOTSTRAP.md` | agent_carrier | daimon |
| 0 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/mcp_trace/MONGODB_MCP_TRACE_HARNESS_SPEC.json` | schema_data | daimon |
| 0 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/mcp_trace/MONGODB_MCP_TRACE_HARNESS_SPEC.md` | agent_carrier | daimon |
| 0 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/repo_scaffold/ion-continuity-bridge/agent_builder/openapi_tools_contract.json` | schema_data | daimon |
| 0 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/repo_scaffold/ion-continuity-bridge/mcp/mongodb_mcp_visibility_contract.json` | schema_data | daimon |
| 0 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/repo_scaffold/ion-continuity-bridge/sample_outputs/mongodb_adapter_contract_demo.json` | schema_data | daimon |
| 0 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/repo_scaffold/ion-continuity-bridge/scripts/run_adapter_contract_demo.py` | agent_carrier | daimon |
| 0 | `dAimon_ION/DAIMON_ION_RAPID_AGENT_HACKATHON_ENTRY_PACKAGE_v1_1_FULL_CANDIDATE_2026-05-09T172524Z/repo_scaffold/ion-continuity-bridge/scripts/validate_mongodb_contract.py` | agent_carrier | daimon |

