# dAimon, Codex, Supabase, Drive, and ION

## dAimon

dAimon is the Google/Gemini carrier lineage. It represents the first major attempt to project ION-like infrastructure into:

- Gemini / Google agent runtime
- Google Cloud / Agent Builder
- MongoDB / trace persistence
- proof and inheritance logic

dAimon should not be collapsed into ION core. It should be a carrier/domain lane integrated through receipts and cockpit visibility.

## Codex Carrier OS

Codex is the OpenAI/local execution carrier.

It should own:
- local repo edits
- tests
- commits/pushes with approval
- Codex sessions
- Codex memory/rolling context
- Codex subagents/domains
- local service refresh
- implementation work

ION should govern Codex through mount receipts, branch capsules, write scopes, and settlement.

## Supabase

Supabase should be the operational realtime data plane.

It should mirror/index:
- carrier mount receipts
- automation events
- Codex sessions
- branch capsules
- receipts
- drift findings
- service health
- git events
- settlement items
- dAimon traces

Supabase does not replace ION files, Git, or settlement.

## Google Drive

Google Drive solves GPT/PRO visibility.

The live repo remains local. Drive holds a readable mirror so GPT-001, Sev/PRO, and other GPTs can inspect the project without manual ZIP uploads.

Drive is a context visibility carrier, not the working tree.

## Slack / GitHub / GitLab

Slack is the human/agent communication rail.

GitHub/GitLab are source reference/review carriers and eventually CI/issue/PR carriers.

ION should register these as carriers with source posture and authority profiles.

## Unified operating network

```text
ION law + receipts + settlement
  ├── Codex Carrier OS
  ├── dAimon / Google lane
  ├── Supabase data plane
  ├── Drive context mirror
  ├── Slack comms rail
  ├── GitHub/GitLab source/review plane
  └── Cockpit UI
```
