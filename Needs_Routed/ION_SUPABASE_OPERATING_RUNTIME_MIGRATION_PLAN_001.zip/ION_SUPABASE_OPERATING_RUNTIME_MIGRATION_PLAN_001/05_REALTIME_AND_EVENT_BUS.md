# Realtime And Event Bus

## Principle

ION emits local events first, then mirrors selected events to Supabase.

## Event Families

- `carrier`
- `agent`
- `codex`
- `packet`
- `tool`
- `patch`
- `test`
- `git`
- `receipt`
- `settlement`
- `drift`
- `service`
- `drive`
- `slack`
- `github`
- `daimon`
- `wisdomnet`
- `atlas`

## Broadcast Strategy

Initial cockpit can use Postgres changes for simplicity.

Later, use database-triggered Realtime Broadcast for curated event topics:

```text
topic:project:<project_id>
topic:branch:<branch_id>
topic:agent:<agent_tag>
topic:service:<service_name>
topic:settlement
topic:drift
```

## Event Contract

Every event row should carry:

- event type;
- source system;
- source receipt path/hash;
- source posture;
- accepted-state claim false unless settlement proves otherwise;
- payload.

## Retention

Supabase can hold operational indexes and recent event history. ION files/Git hold durable truth.

Suggested retention:

- raw operational event rows: 90 days or configurable;
- receipt indexes: long-lived;
- service snapshots: roll up daily;
- audit exports: materialized to ION receipts if important.
