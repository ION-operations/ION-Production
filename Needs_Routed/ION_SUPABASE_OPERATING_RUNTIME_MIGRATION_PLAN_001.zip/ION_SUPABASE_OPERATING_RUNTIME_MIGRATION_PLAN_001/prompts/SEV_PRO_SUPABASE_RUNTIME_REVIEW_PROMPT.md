Sev / ION PRO:

Mount this package as candidate architecture:
ION_SUPABASE_OPERATING_RUNTIME_MIGRATION_PLAN_001

Review Supabase as ION's realtime operational data plane.

Do not treat Supabase as ION truth.
Do not assume production access.
Distinguish evidence, inference, and recommendation.

Return:
### MOUNT RECEIPT
### AGREEMENT / DISAGREEMENT
### SUPABASE ARCHITECTURE REVIEW
### DATA MODEL REVIEW
### SECURITY / RLS REVIEW
### COCKPIT / REALTIME REVIEW
### DAIMON / MULTI-DB REVIEW
### GAPS
### PRIORITIZED PACKETS
### RISKS
### NON-CLAIMS
