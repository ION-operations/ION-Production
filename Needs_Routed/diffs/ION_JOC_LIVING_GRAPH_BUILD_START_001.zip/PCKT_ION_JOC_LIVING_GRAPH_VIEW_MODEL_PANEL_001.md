# PCKT-ION-JOC-LIVING-GRAPH-VIEW-MODEL-PANEL-001

created_at: 2026-05-12T05:08:04+00:00  
carrier: ION-through-this-ChatGPT-carrier  
status: candidate_packet_built_in_sandbox  
accepted_state: false  
production_authority: false  
live_execution_authority: false  

## Purpose

Start the ION/JOC UI graph system through the governed UI-domain workflow, avoiding the prior failure mode of a simple monolithic dashboard. This packet creates the first dependency-free Living Operational Graph projection and a JOC shell graph page that can consume that projection.

## UI domain workflow used

| Stage | Agent/domain | Applied burden |
|---|---|---|
| 1 | `UI_CANON_LIBRARIAN` | Mounted the v0.4 UI domain package and retained canon constraints: DXL matte-black, dense instrument panel, no generic admin/dashboard drift, no live claims without proof. |
| 2 | `ION_WORK_SURFACE_ARCHITECT` | Chose the five-zone JOC graph page route: top honesty/KPI, left layer drawer, central graph viewport, right selected-object truth surface, bottom timeline. |
| 3 | `UI_IMPLEMENTATION_MASON` | Built a small first patch: Python graph view model + React/SVG workbench panel + cockpit model integration + tests. |
| 4 | `A11Y_OPERABILITY_AUDITOR` | Added semantic labels, buttons for selection/timeline/layer toggles, keyboard-focusable graph nodes where SVG supports it. Further browser/a11y proof still required. |
| 5 | `VISUAL_PROOF_AUDITOR` | Ran code/build proof and full fixture projection proof. Browser screenshot proof is not completed in this carrier. |
| 6 | `UI_SETTLEMENT_STEWARD` | Not performed. This packet remains candidate until local review, screenshot proof, and settlement. |

## Source evidence

| Source | Path | SHA-256 |
|---|---|---|
| UI domain context package | `diffs/ION_UI_DOMAIN_CONTEXT_PACKAGE_v0_4_SCHEMA_REPAIR.zip` | `1a63d0a06672be5c50928fc53829f612c49ecb0de471396d6609077da85869e6` |
| v0.4 sample graph | `SAMPLE/living_operational_graph_sample_v0_3.json` | `d22e1470be7c6efbcf1c8b299cf86cc34818f698d473ec53b0dc1e4afa925459` |
| v0.4 layout fixture | `LAYOUT/living_graph_layout_fixture_v0_3.json` | `7e8154544b10023a827b43d8e3f57f26d606be4fc8d58c70950ef917a389b7d6` |

## Candidate patch

Patch artifact:

```text
/mnt/data/ion_joc_living_graph_view_model_panel_001.diff
```

Patch SHA-256:

```text
8f50a63496e9de6b52d75e92d1d3bfba27fc23ea7a9e7889440b7d1c39d2e713
```

Changed paths:

```text
ION/04_packages/kernel/ion_living_graph_view_model.py
ION/04_packages/kernel/ion_cockpit_view_model.py
ION/tests/test_kernel_ion_living_graph_view_model.py
ION/08_ui/joc_cockpit_shell/LivingGraphWorkbenchPanel.tsx
ION/08_ui/joc_cockpit_shell/JocCockpitShell.tsx
ION/08_ui/joc_cockpit_shell/ionRuntimeCockpitTypes.ts
ION/08_ui/joc_cockpit_shell/ion-runtime-cockpit.css
```

## What the patch does

1. Adds `kernel.ion_living_graph_view_model`, a dependency-free projection builder for the Living Operational Graph.
2. Integrates `living_graph` into the existing cockpit view model.
3. Adds top-bar graph summary fields.
4. Adds `LIVING_GRAPH_SAMPLE_CANDIDATE` to cockpit authority classes.
5. Adds a React `LivingGraphWorkbenchPanel` inside the existing JOC shell.
6. Adds a `GRAPH` top-nav/rail route.
7. Adds dense DXL-style CSS for a five-zone graph workbench.
8. Adds tests for missing source posture, sample projection, write output, and cockpit integration.

## Full v0.4 sample projection proof

The full v0.4 sample package projected successfully:

```json
{
  "returncode": 0,
  "status": "ready",
  "kpis": {
    "domain_count": 8,
    "edge_count": 72,
    "event_count": 66,
    "live_telemetry_connected": false,
    "node_count": 64,
    "proof_required_route_count": 48,
    "risk_node_count": 1,
    "timeline_track_count": 6
  },
  "validation": {
    "finding_count": 0,
    "findings": [],
    "missing_edge_refs": [],
    "missing_event_refs": [],
    "ok": true
  },
  "proof_gates": {
    "bundle_parses": true,
    "bundle_present": true,
    "honesty_badges_required": true,
    "layout_parses": true,
    "layout_present": true,
    "no_live_label_without_adapter": true,
    "references_resolve": true,
    "required_zones_present": true
  },
  "non_claims": [
    "not_accepted_ion_state",
    "not_live_telemetry",
    "not_production_authority",
    "not_queue_worker",
    "not_runtime_mutation"
  ]
}
```

Proof artifact:

```text
/mnt/data/ion_ui_graph_build_out/FULL_SAMPLE_LIVING_GRAPH_VIEW_MODEL_PROOF.json
```

## Validation

```text
python3 -m py_compile ION/04_packages/kernel/ion_living_graph_view_model.py ION/04_packages/kernel/ion_cockpit_view_model.py
→ passed

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=ION/04_packages PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest -q ION/tests/test_kernel_ion_living_graph_view_model.py ION/tests/test_kernel_ion_cockpit_view_model.py ION/tests/test_kernel_ion_local_cockpit_app.py
→ 14 passed in 1.51s

node node_modules/vite/bin/vite.js build
→ passed, 68 modules transformed

git apply --check /mnt/data/ion_joc_living_graph_view_model_panel_001.diff against a freshly extracted ION_CODEX FULL3 snapshot
→ passed
```

Notes:

- `npm run build` initially failed because the zip-extracted `vite` shim lacked executable permission.
- Direct Vite build initially hit the same archive permission issue for `esbuild`.
- After sandbox `chmod +x` on the zip-extracted local node binaries, Vite build passed.
- `tsc --noEmit` still reports pre-existing TypeScript issues in `ContextPackageInspectorPanel.tsx`, `DocsProjectsPackagesPanel.tsx`, and `vite.config.ts` module resolution. The new `LivingGraphWorkbenchPanel` TypeScript errors found by `tsc` were fixed.

## Not included in this first patch

This packet deliberately does **not**:

- import the full v0.4 sample JSON into `ION/05_context/current/living_graph/`;
- add R3F/three.js dependencies;
- claim visual screenshot proof;
- claim accepted UI state;
- re-enable Action/MCP mutation;
- run queue workers;
- create production telemetry.

## Next local route

Recommended next packet:

```text
PCKT-ION-JOC-LIVING-GRAPH-SOURCE-MOUNT-AND-VISUAL-PROOF-002
```

Scope:

1. Mount the v0.4 living graph sample/layout under `ION/05_context/current/living_graph/` or create an explicit accepted/candidate source binding path.
2. Run `write_living_graph_view_model`.
3. Launch the local JOC cockpit route.
4. Capture browser screenshot proof.
5. Run shell-zone/no-monolith/visual-canon checks.
6. Run A11Y keyboard/focus smoke.
7. Produce a candidate visual proof receipt.

## Non-claims

- No accepted ION state.
- No production deployment.
- No Git push.
- No connector, Action, MCP, or queue-worker mutation.
- No live telemetry.
- No screenshot/browser proof captured by this carrier.
- No UI settlement performed.
