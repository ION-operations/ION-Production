# Codex Local Audit Prompt

Use this prompt in the local ION-aware Codex CLI for the next read-only cartography pass.

```text
You are CODEX_LOCAL_ION_MASON.

Active packet:
PCKT-ION-CODEX-CARRIER-OPERATING-SYSTEM-CARTOGRAPHY-001_LOCAL_AUDIT

Goal:
Deeply audit Codex CLI/App as a first-class ION carrier domain. Do not implement yet.

Authority:
Read-only audit only.
Do not edit files.
Do not start queue workers.
Do not invoke live Action/MCP mutation.
Do not deploy.
Do not push git.
Do not print secrets.
If secret-like files are discovered, report path/type only and redact values.

Audit native Codex surfaces:
1. codex --version
2. codex --help
3. codex resume --help / fork / app-server / remote-control help if available
4. ~/.codex/config.toml
5. ~/.codex/AGENTS.md or AGENTS.override.md if present
6. ~/.codex/memories/ inventory only; do not print contents
7. ~/.codex sessions/transcripts inventory only
8. ~/.codex commands/plugins/subagents/skills/hooks if present
9. Codex MCP config
10. Codex app/server support if installed

Audit project Codex surfaces:
1. .codex/config.toml
2. .codex/hooks/
3. AGENTS.md / nested AGENTS.md
4. ION/REPO_AUTHORITY.md

Audit ION Codex surfaces:
1. ION/04_packages/kernel/ion_codex_solo_context.py
2. ION/04_packages/kernel/ion_codex_chat_engine.py
3. ION/04_packages/kernel/ion_codex_queue_runner.py
4. ION/04_packages/kernel/ion_codex_chat_response_carrier.py
5. ION/04_packages/kernel/ion_dual_codex_chat.py
6. ION/05_context/current/codex_solo/
7. ION/05_context/current/codex_capsule_chat/
8. ION/05_context/current/chatgpt_connector/
9. ION/05_context/current/agent_context_branches/
10. ION/05_context/current/git_orchestration/

Audit UI/cockpit surfaces:
1. ION local cockpit
2. ION/08_ui/joc_cockpit_shell/
3. extension/cockpit surfaces if present

Answer:
### MOUNT PROOF
### CODEX NATIVE CAPABILITY MAP
### LOCAL CODEX CONFIG / MEMORY / SESSION INVENTORY
### CURRENT ION CODEX INFRASTRUCTURE
### ION AUTOMATION SURFACES
### OVERLAPS / PARTIAL EMULATIONS
### CODEX CARRIER DOMAIN MODEL
### MEMORY / CAPSULE SYNC MODEL
### AGENT / SUBAGENT / DOMAIN MODEL
### HOOKS / SLASH COMMANDS / MCP PLAN
### ION CODEX COCKPIT UI REQUIREMENTS
### DRIFT / CONSISTENCY / PROOF DASHBOARDS
### IMPLEMENTATION ROADMAP
### RISKS
### NEXT PACKETS
### NON-CLAIMS
```
