-- ION Supabase Operating Runtime
-- Migration 002: Dev/private cockpit read policies
--
-- Purpose:
--   Optional private cockpit read access for authenticated users with ION roles.
--   Keep separate from the core schema so production can replace it.
--
-- Requires:
--   ion_ops schema and tables from 001_initial_ion_ops.sql.

-- ---------------------------------------------------------------------
-- Role helper functions
-- ---------------------------------------------------------------------

create or replace function ion_ops.ion_roles()
returns text[]
language sql
stable
as $$
  select coalesce(
    array(
      select jsonb_array_elements_text(
        coalesce(auth.jwt() -> 'app_metadata' -> 'ion_roles', '[]'::jsonb)
      )
    ),
    array[]::text[]
  );
$$;

create or replace function ion_ops.has_ion_role(required_role text)
returns boolean
language sql
stable
as $$
  select required_role = any(ion_ops.ion_roles());
$$;

create or replace function ion_ops.has_any_ion_role(required_roles text[])
returns boolean
language sql
stable
as $$
  select exists (
    select 1
    from unnest(required_roles) r
    where ion_ops.has_ion_role(r)
  );
$$;

-- ---------------------------------------------------------------------
-- Optional private cockpit SELECT policies
-- ---------------------------------------------------------------------

drop policy if exists automation_events_private_cockpit_read
  on ion_ops.automation_events;

create policy automation_events_private_cockpit_read
on ion_ops.automation_events
for select
to authenticated
using (
  ion_ops.has_any_ion_role(array[
    'ion_viewer',
    'ion_operator',
    'ion_agent_writer',
    'ion_steward',
    'ion_admin'
  ])
);

drop policy if exists carrier_mount_receipts_private_cockpit_read
  on ion_ops.carrier_mount_receipts;

create policy carrier_mount_receipts_private_cockpit_read
on ion_ops.carrier_mount_receipts
for select
to authenticated
using (
  ion_ops.has_any_ion_role(array[
    'ion_viewer',
    'ion_operator',
    'ion_agent_writer',
    'ion_steward',
    'ion_admin'
  ])
);

drop policy if exists service_health_snapshots_private_cockpit_read
  on ion_ops.service_health_snapshots;

create policy service_health_snapshots_private_cockpit_read
on ion_ops.service_health_snapshots
for select
to authenticated
using (
  ion_ops.has_any_ion_role(array[
    'ion_viewer',
    'ion_operator',
    'ion_agent_writer',
    'ion_steward',
    'ion_admin'
  ])
);

-- ---------------------------------------------------------------------
-- Grants for private cockpit use
-- ---------------------------------------------------------------------

grant usage on schema ion_ops to authenticated;
grant select on ion_ops.automation_events to authenticated;
grant select on ion_ops.carrier_mount_receipts to authenticated;
grant select on ion_ops.service_health_snapshots to authenticated;

grant select on ion_ops.v_current_carrier_mounts to authenticated;
grant select on ion_ops.v_latest_service_health to authenticated;
grant select on ion_ops.v_recent_automation_events to authenticated;
grant select on ion_ops.v_cockpit_overview to authenticated;
