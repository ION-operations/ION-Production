#!/usr/bin/env python3
"""
ION Workpackets + Diffs Local Content-Proof Ingest

Purpose:
  Read-only scan of a local ION_CODEX FULL root, specifically:
    - ION_CODEX FULL/workpackets/
    - ION_CODEX FULL/diffs/

Outputs:
  - CONTENT_PROOF_MANIFEST.json
  - WORKPACKET_REGISTRY_CONTENT_PROVEN.json/csv
  - DIFF_REGISTRY_CONTENT_PROVEN.json/csv
  - WORKPACKET_DIFF_LINKS_CONTENT_PROVEN.json/csv
  - ORPHAN_WORKPACKETS_REPORT.md
  - ORPHAN_DIFFS_REPORT.md
  - SETTLEMENT_QUEUE_CONTENT_PROVEN.json/csv
  - LOCAL_INGEST_RECEIPT_DRAFT.md

Safety:
  This script does not apply patches, edit source files, run tests, invoke connectors,
  or promote any candidate into accepted state. It only reads files and writes derived
  reports to the requested output folder.

Usage:
  python ion_local_workpackets_diffs_ingest.py --ion-root "C:/path/to/ION_CODEX FULL" --output "./ingest_out"
  python ion_local_workpackets_diffs_ingest.py --ion-root "/path/to/ION_CODEX FULL" --candidate-bundle "./ion_workpackets_diffs_ingestion_20260510T232520.zip" --output "./ingest_out"

Exit codes:
  0 = completed with reports
  2 = missing required local folders
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import sys
import zipfile
from collections import Counter, defaultdict
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple


TEXT_EXTS = {".md", ".txt", ".yaml", ".yml", ".json", ".toml", ".csv", ".py", ".js", ".ts", ".html", ".css"}
DIFF_EXTS = {".diff", ".patch"}
ZIP_EXTS = {".zip"}
MAX_TEXT_BYTES = 2_000_000
MAX_ZIP_LIST = 5000


DOMAIN_RULES = [
    ("custom_gpt_carrier", [
        "custom_gpt", "custom gpt", "gpt builder", "gpt_native", "portable_package",
        "sole_gpt", "anti_theater", "capsule_system"
    ]),
    ("extension_browser_cockpit", [
        "extension", "dom_perception", "dom perception", "cockpit", "artifact_file_lane",
        "macro_automation", "chatgpt image"
    ]),
    ("action_gateway_mcp_connector", [
        "gateway", "mcp", "openapi", "cloudflare", "tunnel", "actions", "bridge",
        "local_pc_vm", "chatops"
    ]),
    ("codex_cli_local_worker", [
        "codex", "cli", "ide", "local_codex"
    ]),
    ("ui_joc_opus", [
        "ui", "joc", "opus", "domain_context_package"
    ]),
    ("context_graph_living_graph", [
        "living_graph", "context_graph", "dynamic_domain", "persona", "domain_agent"
    ]),
    ("self_knowledge_doctrine", [
        "self_knowledge", "continuity_substrate", "ontological_journal", "encyclopedia",
        "knowledge_mount", "self_audit", "monolith_context_export", "architecture_canvas"
    ]),
    ("carrier_runtime_governance", [
        "carrier_friction", "action_hang", "runtime", "friction_ledger"
    ]),
    ("aim_ion_lineage", [
        "aimos", "aimion", "aether", "lineage"
    ]),
    ("daimon_product_line", [
        "daimon", "wisdomnet"
    ]),
]


RISK_RULES = [
    ("production_or_live_connector_surface", ["production", "deploy", "cloudflare", "tunnel", "external account"]),
    ("secret_or_auth_surface", ["auth", "oauth", "token", "secret", "credential", "user_routing_auth"]),
    ("connector_schema_or_config_candidate", [".yaml", ".yml", "openapi", "config", ".toml"]),
    ("instruction_surface_candidate", ["instructions", "dropin", "prompt", "builder"]),
    ("code_or_state_patch_candidate", [".diff", ".patch"]),
    ("context_package_bundle_candidate", [".zip", "context_package", "capsule"]),
    ("binary_or_media_evidence", [".png", ".jpg", ".jpeg", ".gif", ".webp"]),
    ("documentation_or_work_intent_candidate", [".md", ".txt", "workpack", "packet"]),
]


@dataclass
class FileEvidence:
    surface_type: str
    path: str
    relative_path: str
    file_name: str
    extension: str
    size_bytes: int
    sha256: str
    modified_time_utc: str
    domain_guess: str
    risk_class_guess: str
    status_guess: str
    content_summary: Dict[str, Any]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def iso_mtime(path: Path) -> str:
    return datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc).isoformat()


def safe_read_text(path: Path, max_bytes: int = MAX_TEXT_BYTES) -> Tuple[Optional[str], Optional[str]]:
    try:
        size = path.stat().st_size
        if size > max_bytes:
            with path.open("rb") as f:
                raw = f.read(max_bytes)
            return raw.decode("utf-8", errors="replace"), f"truncated_to_{max_bytes}_bytes_from_{size}"
        return path.read_text(encoding="utf-8", errors="replace"), None
    except Exception as exc:
        return None, f"read_error:{type(exc).__name__}:{exc}"


def normalized_tokens(text: str) -> List[str]:
    parts = re.split(r"[^A-Za-z0-9]+", text.lower())
    stop = {
        "", "ion", "full", "workpackets", "diffs", "candidate", "package", "context", "the",
        "and", "for", "with", "2026", "20260507", "20260508", "20260509", "20260510",
        "v0", "v1", "v2", "md", "zip", "diff", "patch", "json", "yaml", "txt"
    }
    return [p for p in parts if len(p) >= 3 and p not in stop]


def guess_domain(path_text: str, content_text: str = "") -> str:
    hay = (path_text + "\n" + content_text[:5000]).lower()
    scores = {}
    for domain, terms in DOMAIN_RULES:
        score = sum(1 for t in terms if t in hay)
        if score:
            scores[domain] = score
    if scores:
        return sorted(scores.items(), key=lambda kv: (-kv[1], kv[0]))[0][0]
    return "unclassified_candidate"


def guess_risk(path: Path, content_text: str = "") -> str:
    hay = (str(path).lower() + "\n" + content_text[:5000].lower())
    ext = path.suffix.lower()
    if ext in DIFF_EXTS:
        return "code_or_state_patch_candidate"
    if ext in ZIP_EXTS:
        return "context_package_bundle_candidate"
    if ext in {".png", ".jpg", ".jpeg", ".gif", ".webp"}:
        return "binary_or_media_evidence"
    for risk, terms in RISK_RULES:
        for t in terms:
            if t.startswith(".") and ext == t:
                return risk
            if t in hay:
                return risk
    return "documentation_or_work_intent_candidate"


def extract_text_summary(path: Path) -> Dict[str, Any]:
    text, note = safe_read_text(path)
    summary: Dict[str, Any] = {
        "content_type": "text",
        "read_note": note,
        "top_heading": None,
        "headings": [],
        "frontmatter_present": False,
        "json_valid": None,
        "packet_ids": [],
        "dates": [],
        "references": [],
        "line_count": None,
    }
    if text is None:
        return summary
    lines = text.splitlines()
    summary["line_count"] = len(lines)
    for line in lines[:300]:
        if line.strip().startswith("#"):
            h = line.strip()
            summary["headings"].append(h[:240])
            if summary["top_heading"] is None:
                summary["top_heading"] = h[:240]
    summary["headings"] = summary["headings"][:20]
    if lines and lines[0].strip() == "---":
        try:
            end_idx = next(i for i, line in enumerate(lines[1:], 1) if line.strip() == "---")
            summary["frontmatter_present"] = True
            summary["frontmatter_lines"] = end_idx + 1
        except StopIteration:
            summary["frontmatter_present"] = False

    if path.suffix.lower() == ".json":
        try:
            json.loads(text)
            summary["json_valid"] = True
        except Exception as exc:
            summary["json_valid"] = False
            summary["json_error"] = f"{type(exc).__name__}:{exc}"

    summary["packet_ids"] = sorted(set(re.findall(r"\b(?:PCKT|PACKET|WORKPACKET)[-_A-Z0-9]{3,}\b", text)))[:50]
    summary["dates"] = sorted(set(re.findall(r"\b20\d{6}(?:T\d{6}Z?)?|\b20\d{2}-\d{2}-\d{2}\b", text)))[:50]
    # Capture likely references to diff/zip/context packages.
    refs = re.findall(r"[A-Za-z0-9_./ -]{4,120}\.(?:diff|patch|zip|json|yaml|md|toml)", text, re.I)
    summary["references"] = sorted(set(r.strip() for r in refs))[:100]
    return summary


def parse_diff(path: Path) -> Dict[str, Any]:
    text, note = safe_read_text(path, max_bytes=10_000_000)
    summary: Dict[str, Any] = {
        "content_type": "diff",
        "read_note": note,
        "affected_paths": [],
        "diff_git_pairs": [],
        "additions": 0,
        "deletions": 0,
        "hunks": 0,
        "binary_files": [],
        "file_modes": [],
    }
    if text is None:
        return summary

    affected = set()
    pairs = []
    for line in text.splitlines():
        if line.startswith("diff --git "):
            m = re.match(r"diff --git a/(.*?) b/(.*)$", line)
            if m:
                a, b = m.group(1), m.group(2)
                pairs.append({"a": a, "b": b})
                affected.add(a)
                affected.add(b)
        elif line.startswith("--- "):
            p = line[4:].strip()
            if p != "/dev/null":
                affected.add(p[2:] if p.startswith("a/") else p)
        elif line.startswith("+++ "):
            p = line[4:].strip()
            if p != "/dev/null":
                affected.add(p[2:] if p.startswith("b/") else p)
        elif line.startswith("@@"):
            summary["hunks"] += 1
        elif line.startswith("+") and not line.startswith("+++"):
            summary["additions"] += 1
        elif line.startswith("-") and not line.startswith("---"):
            summary["deletions"] += 1
        elif line.startswith("Binary files "):
            summary["binary_files"].append(line[:500])
        elif " file mode " in line or line.startswith("new file mode") or line.startswith("deleted file mode"):
            summary["file_modes"].append(line[:500])

    summary["affected_paths"] = sorted(affected)
    summary["diff_git_pairs"] = pairs
    return summary


def inspect_zip(path: Path) -> Dict[str, Any]:
    summary: Dict[str, Any] = {
        "content_type": "zip",
        "zip_valid": None,
        "entry_count": None,
        "listed_entries": [],
        "extension_counts": {},
        "total_uncompressed_bytes": 0,
        "dangerous_paths": [],
        "read_error": None,
    }
    try:
        with zipfile.ZipFile(path, "r") as zf:
            infos = zf.infolist()
            summary["zip_valid"] = True
            summary["entry_count"] = len(infos)
            ext_counter = Counter()
            total = 0
            entries = []
            for info in infos[:MAX_ZIP_LIST]:
                name = info.filename
                total += info.file_size
                ext_counter[Path(name).suffix.lower() or "[no_ext]"] += 1
                if name.startswith("/") or re.match(r"^[A-Za-z]:", name) or ".." in Path(name).parts:
                    summary["dangerous_paths"].append(name)
                entries.append({
                    "name": name,
                    "size": info.file_size,
                    "compress_size": info.compress_size,
                    "is_dir": name.endswith("/"),
                })
            summary["listed_entries"] = entries[:500]
            summary["extension_counts"] = dict(ext_counter)
            summary["total_uncompressed_bytes"] = total
            if len(infos) > MAX_ZIP_LIST:
                summary["list_note"] = f"truncated_listing_to_{MAX_ZIP_LIST}_entries"
    except Exception as exc:
        summary["zip_valid"] = False
        summary["read_error"] = f"{type(exc).__name__}:{exc}"
    return summary


def inspect_binary(path: Path) -> Dict[str, Any]:
    summary = {"content_type": "binary_or_media", "note": "hash_and_metadata_only"}
    # Try PNG dimensions without dependency.
    try:
        if path.suffix.lower() == ".png":
            with path.open("rb") as f:
                sig = f.read(24)
            if sig.startswith(b"\x89PNG\r\n\x1a\n") and len(sig) >= 24:
                width = int.from_bytes(sig[16:20], "big")
                height = int.from_bytes(sig[20:24], "big")
                summary["png_dimensions"] = {"width": width, "height": height}
    except Exception as exc:
        summary["media_probe_error"] = f"{type(exc).__name__}:{exc}"
    return summary


def inspect_file(path: Path, surface_type: str, root: Path) -> FileEvidence:
    rel = str(path.relative_to(root)).replace("\\", "/")
    text_probe = ""
    summary: Dict[str, Any]
    ext = path.suffix.lower()
    if ext in DIFF_EXTS:
        summary = parse_diff(path)
        text_probe = "\n".join(summary.get("affected_paths", []))
    elif ext in ZIP_EXTS:
        summary = inspect_zip(path)
        text_probe = " ".join([e["name"] for e in summary.get("listed_entries", [])[:100]])
    elif ext in TEXT_EXTS:
        summary = extract_text_summary(path)
        text_probe = " ".join([
            str(summary.get("top_heading") or ""),
            " ".join(summary.get("packet_ids") or []),
            " ".join(summary.get("references") or []),
        ])
    else:
        summary = inspect_binary(path)

    d = guess_domain(rel, text_probe)
    r = guess_risk(path, text_probe)
    status = "CONTENT_PROVEN_CANDIDATE"
    if path.name.upper().startswith("README"):
        status = "FRONT_DOOR_WITNESS"
    elif "INDEX" in path.name.upper() and ext == ".json":
        status = "INDEX_WITNESS"
    return FileEvidence(
        surface_type=surface_type,
        path=str(path),
        relative_path=rel,
        file_name=path.name,
        extension=ext or "[no_ext]",
        size_bytes=path.stat().st_size,
        sha256=sha256_file(path),
        modified_time_utc=iso_mtime(path),
        domain_guess=d,
        risk_class_guess=r,
        status_guess=status,
        content_summary=summary,
    )


def write_json(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, sort_keys=False), encoding="utf-8")


def write_csv(path: Path, rows: List[Dict[str, Any]], fields: List[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for row in rows:
            w.writerow({k: json.dumps(row.get(k), ensure_ascii=False) if isinstance(row.get(k), (dict, list)) else row.get(k) for k in fields})


def maybe_load_seed(candidate_bundle: Optional[Path]) -> Dict[str, Any]:
    if not candidate_bundle:
        return {"present": False, "note": "no candidate bundle supplied"}
    if not candidate_bundle.exists():
        return {"present": False, "note": f"candidate bundle path not found: {candidate_bundle}"}
    seed = {"present": True, "path": str(candidate_bundle), "loaded_files": []}
    try:
        if candidate_bundle.is_dir():
            for name in ["WORKPACKET_REGISTRY_CANDIDATE.json", "DIFF_REGISTRY_CANDIDATE.json", "WORKPACKET_DIFF_LINKS_CANDIDATE.json"]:
                p = candidate_bundle / name
                if p.exists():
                    seed[name] = json.loads(p.read_text(encoding="utf-8"))
                    seed["loaded_files"].append(name)
        elif candidate_bundle.suffix.lower() == ".zip":
            with zipfile.ZipFile(candidate_bundle, "r") as zf:
                for zi in zf.infolist():
                    base = Path(zi.filename).name
                    if base in ["WORKPACKET_REGISTRY_CANDIDATE.json", "DIFF_REGISTRY_CANDIDATE.json", "WORKPACKET_DIFF_LINKS_CANDIDATE.json"]:
                        seed[base] = json.loads(zf.read(zi).decode("utf-8"))
                        seed["loaded_files"].append(zi.filename)
    except Exception as exc:
        seed["load_error"] = f"{type(exc).__name__}:{exc}"
    return seed


def token_set_from_record(rec: Dict[str, Any]) -> set:
    text_bits = [
        rec.get("relative_path", ""),
        rec.get("file_name", ""),
        rec.get("domain_guess", ""),
    ]
    summary = rec.get("content_summary") or {}
    if isinstance(summary, dict):
        for key in ["top_heading"]:
            if summary.get(key):
                text_bits.append(str(summary[key]))
        for key in ["packet_ids", "dates", "references", "affected_paths", "listed_entries"]:
            val = summary.get(key)
            if isinstance(val, list):
                for item in val[:200]:
                    if isinstance(item, dict):
                        text_bits.append(" ".join(str(x) for x in item.values()))
                    else:
                        text_bits.append(str(item))
    return set(normalized_tokens(" ".join(text_bits)))


def link_workpackets_to_diffs(workpackets: List[Dict[str, Any]], diffs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    wp_tokens = [(wp, token_set_from_record(wp)) for wp in workpackets]
    links = []
    for diff in diffs:
        dtoks = token_set_from_record(diff)
        candidates = []
        affected = []
        cs = diff.get("content_summary") or {}
        if isinstance(cs, dict):
            affected = cs.get("affected_paths") or []
        for wp, wtoks in wp_tokens:
            overlap = sorted(dtoks & wtoks)
            score = 0.0
            if diff.get("domain_guess") == wp.get("domain_guess"):
                score += 0.35
            if overlap:
                score += min(0.45, 0.045 * len(overlap))
            # Boost when affected path tokens overlap with workpacket tokens.
            aff_toks = set(normalized_tokens(" ".join(affected)))
            aff_overlap = sorted(aff_toks & wtoks)
            if aff_overlap:
                score += min(0.25, 0.05 * len(aff_overlap))
            # Penalize weak generic only overlaps.
            generic = {"candidate", "context", "package", "packet", "workpack", "patch"}
            meaningful = [t for t in overlap if t not in generic]
            if score >= 0.25 and meaningful:
                candidates.append({
                    "workpacket_path": wp.get("relative_path"),
                    "workpacket_id_or_slug": Path(wp.get("relative_path", "")).stem,
                    "domain_guess": wp.get("domain_guess"),
                    "overlap_tokens": meaningful[:25],
                    "affected_path_overlap_tokens": aff_overlap[:25],
                    "link_confidence_score": round(score, 3),
                })
        candidates.sort(key=lambda x: (-x["link_confidence_score"], x["workpacket_path"]))
        status = "ORPHAN_UNLINKED" if not candidates else (
            "STRONG_LINK_CANDIDATE" if candidates[0]["link_confidence_score"] >= 0.7 else "CANDIDATE_LINK_NEEDS_REVIEW"
        )
        links.append({
            "diff_path": diff.get("relative_path"),
            "diff_id_or_slug": Path(diff.get("relative_path", "")).stem,
            "diff_domain_guess": diff.get("domain_guess"),
            "affected_paths": affected,
            "candidate_workpacket_links": candidates[:8],
            "link_status": status,
            "proof_status": "content_inspected_read_only_no_apply",
        })
    return links


def build_settlement_queue(records: List[Dict[str, Any]], links: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    priority_order = {
        "production_or_live_connector_surface": 0,
        "secret_or_auth_surface": 1,
        "code_or_state_patch_candidate": 2,
        "connector_schema_or_config_candidate": 3,
        "instruction_surface_candidate": 4,
        "context_package_bundle_candidate": 5,
        "binary_or_media_evidence": 6,
        "documentation_or_work_intent_candidate": 7,
    }
    link_by_diff = {l["diff_path"]: l for l in links}
    queue = []
    for rec in records:
        risk = rec.get("risk_class_guess")
        surface = rec.get("surface_type")
        item = {
            "surface_type": surface,
            "path": rec.get("relative_path"),
            "domain_guess": rec.get("domain_guess"),
            "risk_class_guess": risk,
            "status_guess": rec.get("status_guess"),
            "sha256": rec.get("sha256"),
            "size_bytes": rec.get("size_bytes"),
            "requires_human_review": risk in {
                "production_or_live_connector_surface",
                "secret_or_auth_surface",
                "code_or_state_patch_candidate",
                "connector_schema_or_config_candidate",
                "instruction_surface_candidate",
            },
            "recommended_settlement_action": "inspect_and_classify",
            "non_claim": "content was inspected read-only; no apply/merge/acceptance performed",
        }
        if surface == "diff":
            link = link_by_diff.get(rec.get("relative_path"))
            if link:
                item["link_status"] = link["link_status"]
                item["affected_path_count"] = len(link.get("affected_paths") or [])
                item["candidate_link_count"] = len(link.get("candidate_workpacket_links") or [])
            item["recommended_settlement_action"] = "affected_path_review_then_steward_settlement"
        elif risk in {"instruction_surface_candidate", "connector_schema_or_config_candidate", "secret_or_auth_surface"}:
            item["recommended_settlement_action"] = "compare_against_current_authority_before_any_promotion"
        queue.append(item)

    def key(x: Dict[str, Any]):
        return (
            priority_order.get(x.get("risk_class_guess"), 99),
            0 if x.get("requires_human_review") else 1,
            x.get("domain_guess") or "",
            x.get("path") or "",
        )
    return sorted(queue, key=key)


def write_reports(out: Path, manifest: Dict[str, Any], workpackets: List[Dict[str, Any]], diffs: List[Dict[str, Any]], links: List[Dict[str, Any]], queue: List[Dict[str, Any]]) -> None:
    orphan_diffs = [l for l in links if l["link_status"] == "ORPHAN_UNLINKED"]
    linked_wp_paths = {c["workpacket_path"] for l in links for c in l.get("candidate_workpacket_links", [])}
    orphan_wps = [wp for wp in workpackets if wp["relative_path"] not in linked_wp_paths and wp["file_name"].upper() not in {"README.MD"} and "INDEX" not in wp["file_name"].upper()]

    md = [
        "# ION Local Workpackets + Diffs Content-Proof Ingest Report",
        "",
        f"generated_at: {manifest['generated_at_utc']}",
        f"ion_root: `{manifest['ion_root']}`",
        "",
        "## Counts",
        "",
        f"- workpackets scanned: {len(workpackets)}",
        f"- diffs scanned: {len(diffs)}",
        f"- diff link records: {len(links)}",
        f"- orphan diffs: {len(orphan_diffs)}",
        f"- workpackets without candidate diff link: {len(orphan_wps)}",
        "",
        "## Non-claims",
        "",
        "- No diff was applied.",
        "- No source file was edited.",
        "- No candidate was promoted to accepted state.",
        "- This report is proof for read-only inspection and classification only.",
    ]
    (out / "LOCAL_CONTENT_PROOF_REPORT.md").write_text("\n".join(md) + "\n", encoding="utf-8")

    od = ["# Orphan Diffs Report", "", "Diffs without a candidate workpacket link after content/name/path matching.", ""]
    for l in orphan_diffs:
        od.append(f"- `{l['diff_path']}` domain=`{l['diff_domain_guess']}` affected_paths={len(l.get('affected_paths') or [])}")
    (out / "ORPHAN_DIFFS_REPORT.md").write_text("\n".join(od) + "\n", encoding="utf-8")

    ow = ["# Orphan Workpackets Report", "", "Workpackets without a candidate diff link. This does not mean they are invalid; many are docs, plans, or context packages.", ""]
    for wp in orphan_wps:
        ow.append(f"- `{wp['relative_path']}` domain=`{wp['domain_guess']}` risk=`{wp['risk_class_guess']}`")
    (out / "ORPHAN_WORKPACKETS_REPORT.md").write_text("\n".join(ow) + "\n", encoding="utf-8")

    receipt = [
        "# LOCAL_INGEST_RECEIPT_DRAFT",
        "",
        f"generated_at_utc: {manifest['generated_at_utc']}",
        "receipt_status: DRAFT_CANDIDATE",
        "authority: read_only_local_content_inspection",
        "",
        "## What happened",
        "",
        "Scanned local `workpackets/` and `diffs/` folders, hashed files, inspected readable content, parsed diff affected paths, inspected ZIP manifests, and generated content-proven candidate registries.",
        "",
        "## What did not happen",
        "",
        "- No patch application.",
        "- No file mutation outside the chosen output folder.",
        "- No live connector invocation.",
        "- No accepted-state promotion.",
        "",
        "## Produced artifacts",
        "",
    ]
    for name in sorted(p.name for p in out.iterdir() if p.is_file()):
        receipt.append(f"- `{name}`")
    receipt += [
        "",
        "## Required settlement",
        "",
        "A Steward/human review must classify each queued candidate as ACCEPTED_AS_IS, MERGE_PROPOSAL_REQUIRED, ESCALATE_REVIEW, DEFERRED, or ABANDONED before inheritance.",
    ]
    (out / "LOCAL_INGEST_RECEIPT_DRAFT.md").write_text("\n".join(receipt) + "\n", encoding="utf-8")


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Read-only ION workpackets/diffs content-proof ingest.")
    ap.add_argument("--ion-root", required=True, help="Path to local 'ION_CODEX FULL' root.")
    ap.add_argument("--candidate-bundle", help="Optional path to prior candidate ingestion bundle .zip or extracted folder.")
    ap.add_argument("--output", required=True, help="Output folder for derived reports.")
    args = ap.parse_args(argv)

    ion_root = Path(args.ion_root).expanduser().resolve()
    out = Path(args.output).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)

    work_dir = ion_root / "workpackets"
    diff_dir = ion_root / "diffs"
    errors = []
    if not ion_root.exists():
        errors.append(f"ion_root_not_found:{ion_root}")
    if not work_dir.exists():
        errors.append(f"workpackets_dir_not_found:{work_dir}")
    if not diff_dir.exists():
        errors.append(f"diffs_dir_not_found:{diff_dir}")
    if errors:
        write_json(out / "LOCAL_INGEST_BLOCKER.json", {
            "generated_at_utc": datetime.now(timezone.utc).isoformat(),
            "errors": errors,
            "non_claim": "local content scan did not run",
        })
        print("BLOCKED:", "; ".join(errors), file=sys.stderr)
        return 2

    seed = maybe_load_seed(Path(args.candidate_bundle).expanduser().resolve() if args.candidate_bundle else None)

    work_files = sorted([p for p in work_dir.rglob("*") if p.is_file()])
    diff_files = sorted([p for p in diff_dir.rglob("*") if p.is_file()])

    work_records = [asdict(inspect_file(p, "workpacket", ion_root)) for p in work_files]
    diff_records = [asdict(inspect_file(p, "diff", ion_root)) for p in diff_files]
    links = link_workpackets_to_diffs(work_records, diff_records)
    queue = build_settlement_queue(work_records + diff_records, links)

    domain_counts = defaultdict(lambda: {"workpacket": 0, "diff": 0})
    for rec in work_records + diff_records:
        domain_counts[rec["domain_guess"]][rec["surface_type"]] += 1

    manifest = {
        "schema": "ion.local_workpackets_diffs_content_proof_manifest.v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "ion_root": str(ion_root),
        "workpackets_dir": str(work_dir),
        "diffs_dir": str(diff_dir),
        "script_non_claims": [
            "read-only inspection only",
            "no patch application",
            "no source mutation",
            "no accepted-state promotion",
            "no live connector invocation",
        ],
        "counts": {
            "workpacket_files": len(work_records),
            "diff_files": len(diff_records),
            "settlement_queue_items": len(queue),
        },
        "domain_counts": dict(domain_counts),
        "candidate_seed": {
            "present": seed.get("present"),
            "loaded_files": seed.get("loaded_files", []),
            "note": seed.get("note"),
            "load_error": seed.get("load_error"),
        },
    }

    write_json(out / "CONTENT_PROOF_MANIFEST.json", manifest)
    write_json(out / "WORKPACKET_REGISTRY_CONTENT_PROVEN.json", work_records)
    write_json(out / "DIFF_REGISTRY_CONTENT_PROVEN.json", diff_records)
    write_json(out / "WORKPACKET_DIFF_LINKS_CONTENT_PROVEN.json", links)
    write_json(out / "SETTLEMENT_QUEUE_CONTENT_PROVEN.json", queue)

    flat_fields = ["surface_type", "relative_path", "file_name", "extension", "size_bytes", "sha256", "modified_time_utc", "domain_guess", "risk_class_guess", "status_guess", "content_summary"]
    write_csv(out / "WORKPACKET_REGISTRY_CONTENT_PROVEN.csv", work_records, flat_fields)
    write_csv(out / "DIFF_REGISTRY_CONTENT_PROVEN.csv", diff_records, flat_fields)
    write_csv(out / "SETTLEMENT_QUEUE_CONTENT_PROVEN.csv", queue, ["surface_type", "path", "domain_guess", "risk_class_guess", "status_guess", "sha256", "size_bytes", "requires_human_review", "recommended_settlement_action", "link_status", "affected_path_count", "candidate_link_count", "non_claim"])

    write_reports(out, manifest, work_records, diff_records, links, queue)

    print(f"ION local content-proof ingest completed. Reports written to: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
