# ATLAS Systems Inventory

## Top-level inventory

- Systems indexed: `189`
- Package status counts: `{"seeded": 189}`
- Comparative docs: `10`
- Graphs: `lineage.mmd, relation_clusters.mmd`

## Primary kind counts

- protocol: 82
- cluster-orchestrator: 21
- c-runtime: 13
- container-runtime: 10
- linux-distribution: 9
- ai-runtime: 9
- programming-language: 9
- toolchain: 9
- service-manager: 5
- kernel: 4
- research-os: 3
- cxx-runtime: 3
- gpu-compute-stack: 3
- dev-environment: 2
- historical-system: 1
- mobile-os: 1
- microvm: 1
- vmm: 1
- control-plane: 1
- declarative-os: 1
- cxx-abi-runtime: 1

## Why this matters for ION

The variety of ATLAS systems shows what ION must eventually be able to reason about:

- kernels and runtimes
- service managers
- containers and orchestrators
- cloud control planes
- protocols
- AI runtimes
- toolchains
- edge/mesh/CDN surfaces
- packaging/distribution formats
- security models
- observability/debug stacks

ION's future users will not all use the same stack. ATLAS helps ION translate between stacks.

## ATLAS AI/runtime systems already present

Relevant AI/runtime/protocol packages in the index include:

```text
openai-agents-chatgpt-public-runtime
anthropic-claude-code-agent-sdk
gemini-api
deepseek-api
model-context-protocol
microsoft-agent-framework
openhands
aim-os
nvidia-triton-inference-server
vllm
```

## Missing or newly-needed ATLAS packages

The current ATLAS index should be expanded with packages for the systems now central to ION:

```text
openai-codex-cli-app
chatgpt-apps-and-connectors
chatgpt-google-drive-sync
chatgpt-slack-app
supabase-platform
supabase-mcp-server
github-chatgpt-app
gitlab-ai-devops-carrier
ion-intelligent-operating-network
daimon-google-agent-lane
ion-browser-extension-carrier
ion-mcp-action-gateway
```

These packages should use ATLAS evidence tiers and package schema rather than informal notes.
