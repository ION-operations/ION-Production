# ION UI Domain Context Package v0.1

created_at: 2026-05-10T15:13:37Z  
status: candidate_context_package_started  
posture: CONSERVATIVE  

This package starts a bounded ION-native UI domain/agent context package from the uploaded `_ui_canon.zip` and the mounted ION Custom GPT carrier package.

## Contents

- `ION_UI_DOMAIN_CONTEXT_PACKAGE_V0_1.json` — main context package
- `ION_UI_CANON_DIGEST_V0_1.md/json` — compressed UI law and reusable canon digest
- `ION_UI_DOMAIN_AGENT_ROSTER_V0_1.md` — candidate specialist agents and subdomains
- `SOURCE_LEDGER.md/json/csv` — inspected source manifest and hashes
- `NEXT_PACKET_ION_UI_PACKET_001.md` — first next work packet
- `ION_UI_CONTEXT_START_RECEIPT.json` — receipt for this context-package start

## Authority

Candidate only. This export does not mutate the ION registry, prove live connector status, or accept the new domain into canon. It is ready for Steward review or a bounded implementation packet.
