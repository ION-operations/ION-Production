# Sev Codex Carrier OS Phase 3 Report

Packet: `PCKT-ION-CODEX-SOURCE-BUNDLE-STAGE-REVIEW-003`

## Input proof reconciled

CODEX-001 reported Phase 2 applied locally under active root:

```text
/home/sev/ION - Production/ION_CODEX FULL
```

Reported Phase 2 status:

```text
verdict: ION_CODEX_COMMIT_BOUNDARY_AUDIT_PARTIAL
ok: true
ready_for_source_commit_bundle: true
blocking_findings: none
warnings:
  - runtime_residue_paths_present
  - unknown_owner_surface_paths_present
  - untracked_paths_require_owner_review
```

Reported local bundle counts:

```text
source_protocol_schema_tests: 52
generated_projection_or_local_evidence: 36
runtime_residue_exclude: 3
untracked_review_required: 41
preexisting_dirty_or_unknown: 2
private_or_secret_risk_exclude: 0
deletion_review_required: 0
```

## Phase 3 scope

Phase 3 narrows the commit-boundary audit into a first source/protocol/schema/test stage proposal.

It does **not** run:

```text
git add
git commit
git push
service restart
settlement
raw Codex memory/session/transcript export
```

## Added source surfaces

```text
ION/02_architecture/CODEX_SOURCE_BUNDLE_STAGE_REVIEW_PROTOCOL.md
ION/03_registry/ion_codex_source_bundle_stage_review.schema.json
ION/04_packages/kernel/ion_codex_source_bundle_stage_review.py
ION/tests/test_kernel_ion_codex_source_bundle_stage_review.py
```

Modified:

```text
ION/04_packages/kernel/ion_codex_carrier_os.py
ION/04_packages/kernel/ion_mcp_local_bridge.py
```

## New CLI surface

Read-only projection:

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=ION/04_packages python3 -S -m kernel.ion_codex_source_bundle_stage_review \
  --ion-root . \
  --json
```

Write candidate review artifacts:

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=ION/04_packages python3 -S -m kernel.ion_codex_source_bundle_stage_review \
  --ion-root . \
  --write \
  --confirmation ION_CODEX_SOURCE_BUNDLE_STAGE_REVIEW_WRITE_CONFIRMED \
  --json
```

Candidate outputs:

```text
ION/05_context/current/codex_carrier/commit_boundary/CODEX_SOURCE_BUNDLE_STAGE_REVIEW.json
ION/05_context/current/codex_carrier/commit_boundary/CODEX_SOURCE_BUNDLE_STAGE_MANIFEST.candidate.json
```

## New MCP projection

```text
ion.codex.source_bundle.stage_review
```

This projection is read-only. It returns the source-bundle review through the local MCP bridge and does not mutate Git.

## Carrier OS source-map update

The Codex Carrier OS source map now includes:

```text
control plane: source_bundle_stage_review
slash command: /ion-source-bundle
Drive/context mirror default refs include CODEX_SOURCE_BUNDLE_STAGE_REVIEW.json
```

## Validation

```text
git apply --check after Phase 2: passed
py_compile selected modules: passed
focused pytest: 20 passed in 11.37s
```

Focused pytest set:

```text
ION/tests/test_kernel_ion_codex_source_bundle_stage_review.py
ION/tests/test_kernel_ion_codex_commit_boundary_audit.py
ION/tests/test_kernel_ion_codex_carrier_os.py
ION/tests/test_kernel_ion_mcp_local_bridge.py
```

## Local use

Apply after Phase 2:

```bash
git apply SEV_CODEX_CARRIER_OS_PHASE3_SOURCE_BUNDLE_STAGE_REVIEW_INCREMENTAL_20260512.patch
```

Validate:

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=ION/04_packages PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest \
  ION/tests/test_kernel_ion_codex_source_bundle_stage_review.py \
  ION/tests/test_kernel_ion_codex_commit_boundary_audit.py \
  ION/tests/test_kernel_ion_codex_carrier_os.py \
  ION/tests/test_kernel_ion_mcp_local_bridge.py -q

git diff --check
```

Generate the local review:

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=ION/04_packages python3 -S -m kernel.ion_codex_source_bundle_stage_review \
  --ion-root . \
  --write \
  --confirmation ION_CODEX_SOURCE_BUNDLE_STAGE_REVIEW_WRITE_CONFIRMED \
  --json
```

Return the generated review and manifest to Sev/GPT PRO. Do not stage, commit, push, or promote raw Codex context in this packet.

## Non-claims

```text
No accepted ION state claimed.
No production authority claimed.
No live execution authority claimed.
No Git staging performed.
No Git commit performed.
No Git push performed.
No GitHub mutation performed.
No raw Codex context promoted.
```
