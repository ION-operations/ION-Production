# Cockpit Requirements

## MVP Screens

1. Service Health
   - MCP 8765
   - Action Gateway 8777
   - Local Cockpit 8788
   - dAimon bridge 8795
   - Supabase connectivity
   - GitHub/GitLab/Slack/Drive status

2. Automation Timeline
   - recent events
   - source receipt links
   - severity/status filters

3. Carrier Mounts
   - GPT-001
   - Sev/GPT PRO
   - Codex agents
   - dAimon/Gemini agents
   - Slack/GitHub carriers

4. Codex Sessions
   - session id
   - agent/domain
   - current packet
   - branch capsule
   - last validation
   - blockers

5. Work Packet Board
   - queued
   - active
   - blocked
   - superseded
   - settlement pending

6. Git / Commit Board
   - staged plans
   - commits
   - push receipts
   - dirty runtime state warnings

7. Drift / Consistency Console
   - stale indexes
   - wrong mount
   - duplicate packets
   - uncommitted runtime
   - proof gaps

8. Settlement Queue
   - branch returns
   - conflicts
   - accepted/rejected/deferred
   - next settlement act

## Graph View

Supabase gives the graph enough queryable state to render:

```text
agents ↔ sessions ↔ packets ↔ receipts ↔ commits ↔ settlement
```

ION/ATLAS supplies the OS-class layout and entity taxonomy.
