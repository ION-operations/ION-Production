# ATLAS-Guided Cockpit Requirements

The cockpit should display ION as an operating network, not as a chat log.

## OS-class cockpit panels

### 1. Control plane health

- MCP preview
- Action Gateway
- Codex queue runner
- local cockpit
- dAimon bridge
- Supabase mirror
- Drive mirror sync
- Slack/GitHub/GitLab apps

### 2. Data plane health

- receipt ledger
- branch capsules
- task returns
- automation events
- Supabase event mirror
- Drive mirror manifest
- source maps
- workpacket/diff indexes

### 3. Agent and carrier graph

Nodes:
- GPT-001
- Sev / ION PRO
- Codex sessions
- dAimon/Gemini agents
- Slack channels
- GitHub/GitLab repos
- Supabase project
- Drive mirror
- browser extension

Edges:
- mounted
- delegated
- returned
- blocked
- superseded
- settled
- mirrored
- pushed
- notified

### 4. Namespace / identity graph

- carrier IDs
- agent tags
- context instance IDs
- branch IDs
- session IDs
- packet IDs
- receipt IDs

### 5. Drift dashboard

- dirty git tree
- stale indexes
- stale Drive mirror
- stale Supabase mirror
- queue duplicates
- service port mismatch
- missing mount receipt
- context-source mismatch
- runtime state uncommitted
- branch capsule not synced

### 6. Proof dashboard

- last tests
- task return status
- proof gate failures
- receipts created
- blocked returns
- settlement queue
- accepted/rejected/deferred items

### 7. Git and package board

- staged paths
- untracked evidence
- commit plans
- pushed commits
- package exports
- Drive mirrors
- full repo snapshots

### 8. dAimon / external carrier panel

- Gemini bridge status
- Google lane traces
- dAimon receipts
- MongoDB/Agent Builder references
- ION projection status

## UI canon note

The cockpit should obey the ION UI/JOC/OPUS canon:
- operational instrument panel
- dense but legible
- not generic SaaS dashboard
- status/proof first
- visual drift and authority cues
