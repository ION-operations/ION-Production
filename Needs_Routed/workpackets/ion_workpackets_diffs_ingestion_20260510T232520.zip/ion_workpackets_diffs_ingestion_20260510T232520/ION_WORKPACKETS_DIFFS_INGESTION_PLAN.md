# ION Workpackets + Diffs Ingestion and Consolidation Plan

generated_at: 2026-05-10T23:25:20.320229-04:00
source_posture: CONSERVATIVE
carrier_lane: GPT sandbox/package
production_authority: false
live_execution_authority: false

## 0. Mount proof

- Mounted package root: `/mnt/data/ion_mount/ION_CUSTOM_GPT_CARRIER_PACKAGE_v2_6_CANDIDATE_20260508`
- `ion_status` active-state verdict: `ION_ACTIVE_STATE_INTEGRITY_READY`
- Missing state surfaces: `[]`
- `ion_carrier_continue` verdict: `ION_CARRIER_CONTINUE_READY`
- ION-generated role sequence: steward → vizier → mason
- Generated execution-cycle surface: `ION/05_context/current/execution_cycles/2026-05-11T032442Z0000_carrier_continue_mount_ion_in_gpt_sandbox_and_plan_read_only_ingestion_consolidation_of_ion_codex`

## 1. Source posture

The router/index package contains an indexed `ION FULL DEVELOPMENT.zip` artifact with:

- top root: `ION_CODEX FULL`
- internal files: `22214`
- indexed sha256: `8bc1c1b90780a1012fd3286930b76dc77b631d72d8e297e046d8045094362736`

Current sandbox limitation:

- actual full development ZIP present as an openable `/mnt/data` archive: `False`
- therefore all workpacket/diff rows below are **index-derived candidate registry entries**, not content-inspected accepted state.

## 2. Indexed scope

- `ION_CODEX FULL/workpackets/`: 48 indexed rows
- `ION_CODEX FULL/diffs/`: 13 indexed rows

## 3. Non-claims

- The actual ION FULL DEVELOPMENT.zip was not present as an openable /mnt/data archive during this run.
- Workpacket and diff registries were generated from router package indexes, not from direct full-archive content inspection.
- No diff was applied.
- No workpacket or diff was promoted to accepted state.
- No live connector/local hub/GitHub/Codex external worker was invoked.

## 4. Doctrine-bound ingestion rule

Treat every workpacket and diff as an untrusted or candidate graph object until classified.

```text
external/indexed material
→ quarantine
→ manifest
→ structural cartography
→ context graph genesis
→ domain partition
→ template binding
→ risk and authority classification
→ first context packages
→ receipts
→ governed work loop
```

Workpackets and diffs must not be flattened into "old files to clean up." They are different object types:

```text
workpacket = intent / bounded work proposal / role route
diff = proposed state delta / patch or context-package evidence
receipt = what actually landed, was rejected, or remains deferred
```

## 5. Domain candidate map

| Domain | Workpackets | Diffs | Recommended custody | Top risk classes |
|---|---:|---:|---|---|
| `action_gateway_mcp_connector` | 10 | 0 | Connector gateway steward | connector_runtime_design_candidate:8, connector_schema_or_config_candidate:2 |
| `aim_ion_lineage` | 2 | 0 | Lineage librarian | documentation_or_work_intent_candidate:2 |
| `carrier_runtime_governance` | 1 | 1 | Runtime cartographer | documentation_or_work_intent_candidate:1, code_or_state_patch_candidate:1 |
| `codex_cli_local_worker` | 3 | 0 | Codex local worker steward | connector_schema_or_config_candidate:1, documentation_or_work_intent_candidate:1, connector_runtime_design_candidate:1 |
| `context_graph_living_graph` | 2 | 1 | Context cartographer | documentation_or_work_intent_candidate:1, governance_protocol_candidate:1, context_package_bundle_candidate:1 |
| `custom_gpt_carrier` | 6 | 3 | Custom GPT carrier / instruction steward | instruction_surface_candidate:3, code_or_state_patch_candidate:3, documentation_or_work_intent_candidate:2, context_package_bundle_candidate:1 |
| `daimon_product_line` | 1 | 0 | dAimon product steward | documentation_or_work_intent_candidate:1 |
| `extension_browser_cockpit` | 10 | 1 | Extension / DOM / cockpit steward | connector_runtime_design_candidate:8, context_package_bundle_candidate:2, connector_schema_or_config_candidate:1 |
| `self_knowledge_doctrine` | 6 | 0 | Canon librarian / IONOLOGIST | documentation_or_work_intent_candidate:6 |
| `ui_joc_opus` | 1 | 4 | UI canon steward | context_package_bundle_candidate:5 |
| `unclassified_candidate` | 6 | 3 | Ingestion triage | documentation_or_work_intent_candidate:3, governance_protocol_candidate:2, schema_data_candidate:2, context_package_bundle_candidate:1 |

## 6. Candidate diff-to-workpacket links

These links are name/index based only. They are triage hints, not proof.

| Diff/context package | Domain | Link status | Top candidate workpacket | Score |
|---|---|---|---|---:|
| `ION_LIVING_GRAPH_CONTEXT_PACKAGE_20260510_v0_2.zip` | `context_graph_living_graph` | ORPHAN_UNLINKED_BY_INDEX_ONLY | `—` |  |
| `ION_UI_DOMAIN_CONTEXT_PACKAGE_v0_1.zip` | `ui_joc_opus` | CANDIDATE_NAME_BASED_ONLY | `DAIMON_UI_PROPOSAL_PACKAGE_20260509.zip` | 0.45 |
| `ION_UI_DOMAIN_CONTEXT_PACKAGE_v0_1_1.zip` | `ui_joc_opus` | CANDIDATE_NAME_BASED_ONLY | `DAIMON_UI_PROPOSAL_PACKAGE_20260509.zip` | 0.444 |
| `ChatGPT Image May 10, 2026, 12_14_44 PM.png` | `unclassified_candidate` | ORPHAN_UNLINKED_BY_INDEX_ONLY | `—` |  |
| `ION_UI_DOMAIN_CONTEXT_PACKAGE_v0_4_SCHEMA_REPAIR.zip` | `ui_joc_opus` | CANDIDATE_NAME_BASED_ONLY | `DAIMON_UI_PROPOSAL_PACKAGE_20260509.zip` | 0.363 |
| `ION_EXTENSION_MINI_HELIXION_CONTEXT_PACKAGE_20260510_v0_1.zip` | `extension_browser_cockpit` | CANDIDATE_NAME_BASED_ONLY | `DOM_PERCEPTION_CONTEXT_PACKAGE_20260510_v0_1.zip` | 0.373 |
| `ION_UI_DOMAIN_CONTEXT_PACKAGE_v0_3_BUILD_PREP.zip` | `ui_joc_opus` | CANDIDATE_NAME_BASED_ONLY | `DAIMON_UI_PROPOSAL_PACKAGE_20260509.zip` | 0.37 |
| `README.md` | `unclassified_candidate` | ORPHAN_UNLINKED_BY_INDEX_ONLY | `—` |  |
| `DIFF_INDEX_20260508T190626Z.json` | `unclassified_candidate` | CANDIDATE_NAME_BASED_ONLY | `WORKPACKET_INDEX_20260508T190626Z.json` | 0.987 |
| `ION_CARRIER_FRICTION_LEDGER_PATCH_20260507.diff` | `carrier_runtime_governance` | CANDIDATE_NAME_BASED_ONLY | `ION_CARRIER_FRICTION_LEDGER_AND_ACTION_HANG_TRIAGE_WORKPACK_20260507.md` | 0.671 |
| `ION_SOLE_GPT_PORTABLE_PACKAGE_V0_1_PATCH_20260507.diff` | `custom_gpt_carrier` | CANDIDATE_NAME_BASED_ONLY | `ION_SOLE_GPT_PORTABLE_PACKAGE_V0_1_CODEX_WORKPACK_20260507.md` | 1.0 |
| `ION_GPT_NATIVE_PORTABLE_ENGINE_PACKAGE_v0_2_PATCH_20260507.diff` | `custom_gpt_carrier` | CANDIDATE_NAME_BASED_ONLY | `ION_SOLE_GPT_PORTABLE_PACKAGE_V0_1_CODEX_WORKPACK_20260507.md` | 0.603 |
| `ION_CUSTOM_GPT_ANTI_THEATER_PATCH_20260507.diff` | `custom_gpt_carrier` | CANDIDATE_NAME_BASED_ONLY | `CUSTOM_GPT_INSTRUCTIONS_ANTI_THEATER_DROPIN_20260507.md` | 0.769 |

## 7. Settlement order

| Priority | Surface | Domain | Risk | Path | Human review |
|---:|---|---|---|---|---|
| 1 | diff | `carrier_runtime_governance` | `code_or_state_patch_candidate` | `ION_CODEX FULL/diffs/ION_CARRIER_FRICTION_LEDGER_PATCH_20260507.diff` | true |
| 2 | diff | `custom_gpt_carrier` | `code_or_state_patch_candidate` | `ION_CODEX FULL/diffs/ION_CUSTOM_GPT_ANTI_THEATER_PATCH_20260507.diff` | true |
| 3 | diff | `custom_gpt_carrier` | `code_or_state_patch_candidate` | `ION_CODEX FULL/diffs/ION_GPT_NATIVE_PORTABLE_ENGINE_PACKAGE_v0_2_PATCH_20260507.diff` | true |
| 4 | diff | `custom_gpt_carrier` | `code_or_state_patch_candidate` | `ION_CODEX FULL/diffs/ION_SOLE_GPT_PORTABLE_PACKAGE_V0_1_PATCH_20260507.diff` | true |
| 5 | workpacket | `action_gateway_mcp_connector` | `connector_schema_or_config_candidate` | `ION_CODEX FULL/workpackets/ION_ACTION_GATEWAY_OPENAPI_V0_3_CANDIDATE.yaml` | true |
| 6 | workpacket | `action_gateway_mcp_connector` | `connector_schema_or_config_candidate` | `ION_CODEX FULL/workpackets/ion_custom_gpt_action_openapi_ion_bridge_v0_2_candidate.yaml` | true |
| 7 | workpacket | `codex_cli_local_worker` | `connector_schema_or_config_candidate` | `ION_CODEX FULL/workpackets/ION_CODEX_CLI_CONFIG_CANDIDATE.toml` | true |
| 8 | workpacket | `extension_browser_cockpit` | `connector_schema_or_config_candidate` | `ION_CODEX FULL/workpackets/ion_custom_gpt_action_openapi_ion_chatops_bridge.yaml` | true |
| 9 | workpacket | `action_gateway_mcp_connector` | `connector_runtime_design_candidate` | `ION_CODEX FULL/workpackets/ION_ACTIONS_CODEX_IDE_FULL_EXECUTION_PLAN_2026-05-07.md` | true |
| 10 | workpacket | `action_gateway_mcp_connector` | `connector_runtime_design_candidate` | `ION_CODEX FULL/workpackets/ION_CLOUDFLARE_TUNNEL_RUNBOOK_ACTION_GATEWAY_2026-05-07.md` | true |
| 11 | workpacket | `action_gateway_mcp_connector` | `connector_runtime_design_candidate` | `ION_CODEX FULL/workpackets/ION_CODEX_CLI_PACKET_001_ACTION_GATEWAY_MVP_2026-05-07.md` | true |
| 12 | workpacket | `action_gateway_mcp_connector` | `connector_runtime_design_candidate` | `ION_CODEX FULL/workpackets/ION_CODEX_CLI_PROMPT_ACTION_GATEWAY_MVP.txt` | true |
| 13 | workpacket | `action_gateway_mcp_connector` | `connector_runtime_design_candidate` | `ION_CODEX FULL/workpackets/ION_CUSTOM_GPT_ACTIONS_LOCAL_ION_BRIDGE_STRATEGY_2026-05-07.md` | true |
| 14 | workpacket | `action_gateway_mcp_connector` | `connector_runtime_design_candidate` | `ION_CODEX FULL/workpackets/ION_CUSTOM_GPT_BUILDER_INSTRUCTIONS_ACTIONS_BRIDGE_2026-05-07.md` | true |
| 15 | workpacket | `action_gateway_mcp_connector` | `connector_runtime_design_candidate` | `ION_CODEX FULL/workpackets/PCKT-LOCAL-PC-VM-GATEWAY-001_CODEX_WORKPACK.md` | true |
| 16 | workpacket | `action_gateway_mcp_connector` | `connector_runtime_design_candidate` | `ION_CODEX FULL/workpackets/PCKT-LOCAL-PC-VM-GATEWAY-003_USER_ROUTING_AUTH_CODEX_WORKPACK.md` | true |
| 17 | workpacket | `codex_cli_local_worker` | `connector_runtime_design_candidate` | `ION_CODEX FULL/workpackets/ION_Helixion_IDE_Bridge_v0_Workpacket.md` | true |
| 18 | workpacket | `extension_browser_cockpit` | `connector_runtime_design_candidate` | `ION_CODEX FULL/workpackets/ION_Two_Channel_Extension_Cosigned_Gateway_Architecture_v0_1_CANDIDATE.md` | true |
| 19 | workpacket | `extension_browser_cockpit` | `connector_runtime_design_candidate` | `ION_CODEX FULL/workpackets/PCKT-GATEWAY-EXTENSION-COSIGN-004_CODEX_WORKPACK.md` | true |
| 20 | workpacket | `extension_browser_cockpit` | `connector_runtime_design_candidate` | `ION_CODEX FULL/workpackets/ion_extension_work_packets/ION_EXT_ARTIFACT_FILE_LANE_PACKET.md` | true |
| 21 | workpacket | `extension_browser_cockpit` | `connector_runtime_design_candidate` | `ION_CODEX FULL/workpackets/ion_extension_work_packets/ION_EXT_CODEX_AGENT_COCKPIT_PACKET.md` | true |
| 22 | workpacket | `extension_browser_cockpit` | `connector_runtime_design_candidate` | `ION_CODEX FULL/workpackets/ion_extension_work_packets/ION_EXT_DOM_ACTION_REGISTRY_PACKET.md` | true |
| 23 | workpacket | `extension_browser_cockpit` | `connector_runtime_design_candidate` | `ION_CODEX FULL/workpackets/ion_extension_work_packets/ION_EXT_DOM_COCKPIT_SHELL_PACKET.md` | true |
| 24 | workpacket | `extension_browser_cockpit` | `connector_runtime_design_candidate` | `ION_CODEX FULL/workpackets/ion_extension_work_packets/ION_EXT_GUARDED_MACRO_AUTOMATION_PACKET.md` | true |
| 25 | workpacket | `extension_browser_cockpit` | `connector_runtime_design_candidate` | `ION_CODEX FULL/workpackets/ion_extension_work_packets/README.md` | true |
| 26 | workpacket | `custom_gpt_carrier` | `instruction_surface_candidate` | `ION_CODEX FULL/workpackets/CUSTOM_GPT_INSTRUCTIONS_ANTI_THEATER_DROPIN_20260507.md` | true |
| 27 | workpacket | `custom_gpt_carrier` | `instruction_surface_candidate` | `ION_CODEX FULL/workpackets/ION_Custom_GPT_Instructions_v2_0_CANDIDATE.md` | true |
| 28 | workpacket | `custom_gpt_carrier` | `instruction_surface_candidate` | `ION_CODEX FULL/workpackets/ION_Custom_GPT_Instructions_v2_5_USER_ROUTING_AUTH_PASTE_CANDIDATE.md` | true |
| 29 | workpacket | `context_graph_living_graph` | `governance_protocol_candidate` | `ION_CODEX FULL/workpackets/ion_monolith_context_export_protocol_v_0_1.md` | true |
| 30 | workpacket | `unclassified_candidate` | `governance_protocol_candidate` | `ION_CODEX FULL/workpackets/ION_COMPUTE_AT_WRITE_SPEC_20260509.md` | true |

## 8. Full process

### Phase A — Quarantine and structural cartography

1. Preserve the full archive as immutable input.
2. Generate archive-level manifest, file tree index, path normalization report, and checksums.
3. Split material into:
   - hot repo authority surfaces
   - workpackets
   - diffs / patches
   - context-package ZIPs
   - media evidence
   - indexes/front doors
   - historical/witness material
4. Record non-claims: no patch applied, no state promoted, no connector invoked.

### Phase B — Workpacket registry

For each workpacket:

1. Extract packet identity, date, objective, proposed carrier/role, allowed paths, forbidden paths, proof owed, target domain, and status language.
2. Classify as one of:
   - `CURRENT_ACCEPTED`
   - `CANDIDATE_UNSETTLED`
   - `APPLIED_BUT_UNRECEIPTED`
   - `SUPERSEDED`
   - `HISTORICAL_WITNESS`
   - `CONFLICT_NEEDS_SETTLEMENT`
   - `INDEX_OR_FRONT_DOOR`
3. Attach it to a candidate domain.
4. If it is an instruction surface, connector surface, code/runtime surface, or governance protocol, mark human/steward review required.

### Phase C — Diff registry

For each diff or context-package bundle:

1. If `.diff`, parse affected files and patch hunks.
2. If `.zip`, inspect manifest/README/roots and classify as context package, source pack, media pack, or patch bundle.
3. If media, classify as evidence only.
4. Link to likely originating packet(s).
5. Mark apply status as `UNKNOWN_DO_NOT_APPLY` until settlement.
6. Require proof before any patch is replayed or imported.

### Phase D — Link graph

Create the graph edges:

```text
workpacket PROPOSES diff
diff TOUCHES file/domain
diff CLAIMS proof
receipt ACCEPTS/REJECTS/DEFERS diff
domain OWNS packet/diff
```

This becomes `WORKPACKET_DIFF_LINKS.json` plus a graph-readable `DOMAIN_CANDIDATE_MAP`.

### Phase E — Domain partition and fission pressure

Initial domains should remain candidate until actual content inspection completes:

- `custom_gpt_carrier`
- `extension_browser_cockpit`
- `action_gateway_mcp_connector`
- `codex_cli_local_worker`
- `ui_joc_opus`
- `context_graph_living_graph`
- `daimon_product_line`
- `aim_ion_lineage`
- `self_knowledge_doctrine`
- `carrier_runtime_governance`
- `unclassified_candidate`

If a domain has mixed authority surfaces, repeated connector/runtime risk, or many cross-domain links, create a fission note rather than forcing it into one bucket.

### Phase F — Risk ledger

Use the risk ledger to keep high-risk material from being accidentally absorbed:

1. connector/runtime/action surfaces
2. code/state patch candidates
3. schemas/configs
4. instruction surfaces
5. governance protocols
6. context-package bundles
7. documentation/witness material
8. media evidence

### Phase G — Settlement queue

Settle in batches:

1. indexes and READMEs
2. instruction surfaces
3. connector/runtime/action surfaces
4. code/state diffs
5. context package ZIPs
6. UI/media packages
7. doctrine/self-knowledge docs
8. unclassified or orphan material

Each settlement outputs:

```text
accepted_as_witness | accepted_as_current | superseded | deferred | rejected | needs_human_review
```

### Phase H — Receipts and export

Every meaningful settlement gets a receipt with:

- source paths
- domain
- authority posture
- evidence inspected
- decision
- non-claims
- next packet or blocker

The successor export should include at minimum:

```text
MOUNT_AND_SOURCE_PROOF.json
WORKPACKET_REGISTRY_CANDIDATE.json
DIFF_REGISTRY_CANDIDATE.json
WORKPACKET_DIFF_LINKS_CANDIDATE.json
DOMAIN_CANDIDATE_MAP.json
RISK_LEDGER_CANDIDATE.json
SETTLEMENT_QUEUE_CANDIDATE.json
project_ingestion_receipt.md
```

## 9. Next lawful packet

```yaml
packet_id: PCKT-ION-WORKPACKETS-DIFFS-INGEST-001
status: candidate
authority: sandbox_read_write_to_derived_reports_only
objective: Convert indexed workpacket/diff surfaces into inspectable registries and a settlement plan without applying patches or promoting state.
allowed_outputs:
  - MOUNT_AND_SOURCE_PROOF.json
  - WORKPACKET_REGISTRY_CANDIDATE.json
  - DIFF_REGISTRY_CANDIDATE.json
  - WORKPACKET_DIFF_LINKS_CANDIDATE.json
  - DOMAIN_CANDIDATE_MAP.json
  - RISK_LEDGER_CANDIDATE.json
  - SETTLEMENT_QUEUE_CANDIDATE.json
  - project_ingestion_receipt.md
forbidden_actions:
  - apply diffs
  - mutate source archive
  - claim accepted state
  - claim full content inspection while full archive is unavailable
  - invoke live connector/local hub/GitHub/Codex worker without explicit connector-lane request
proof_required:
  - counts
  - source artifact sha
  - index paths
  - mount command results
  - non-claims
next_route:
  - actual_full_archive_content_inspection_when_available
  - parse .diff affected paths
  - unpack context-package ZIPs into quarantine
  - compare each candidate against hot authority files and receipts
```

