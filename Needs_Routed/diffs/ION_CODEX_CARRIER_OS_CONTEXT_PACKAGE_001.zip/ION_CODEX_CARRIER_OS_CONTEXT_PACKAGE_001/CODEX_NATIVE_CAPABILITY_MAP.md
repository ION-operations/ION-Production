# Codex Native Capability Map for ION

Status: candidate external capability map. Validate locally with `codex --help`, `codex resume --help`, `codex mcp --help`, `codex remote-control --help`, and local config inspection.

## Native capability families ION should use

### 1. Interactive Codex sessions

Codex can operate as a persistent local session, not merely a one-shot command. ION should treat each significant Codex session as a carrier session with a durable ION session record.

ION mapping:
- Codex session/thread -> `CODEX_SESSION.json`
- Codex transcript/resume ID -> branch capsule field
- Current packet -> branch status
- visible commands/tools -> automation timeline
- final report -> task return / settlement input

### 2. Resume and session continuity

Codex supports resuming prior sessions. ION should not force every Codex worker to start from scratch when a long-lived specialist terminal is appropriate.

ION mapping:
- `codex resume` -> reopen carrier session
- ION branch capsule -> durable state that survives if Codex memory/session is lost
- rolling context sync -> bridge between session continuity and ION continuity

### 3. Codex memories

Codex memories can provide useful recall from prior threads. They should be used as working memory, never as accepted ION state.

ION rule:
- Memory may orient.
- Branch capsule governs.
- Receipts inherit.
- Settlement accepts.

### 4. AGENTS.md / project instructions

Codex can load global and project instructions through AGENTS files and project config. ION should use this as the stable instruction layer for Codex Carrier Domain guidance.

ION mapping:
- global Codex guidance -> broad carrier behavior
- project `.codex/config.toml` and hooks -> active ION root behavior
- nested AGENTS files -> domain/local overrides
- ION branch capsule -> current packet and write scope

### 5. Config profiles / custom agents / subagents

Codex supports specialized agents/subagents and task-specific configuration. ION should map these to ION domains and branch capsules.

ION mapping:
- Codex custom agent -> ION domain carrier profile
- Codex subagent -> child branch capsule
- parent Codex session -> relay/orchestrator branch
- subagent return -> settlement proposal

### 6. Hooks

Codex hooks are the right mechanism for deterministic ION enforcement around Codex. They should enforce mount proof, identity card, write-scope checks, pre/post material-work sync, and exit/handoff records.

ION mapping:
- SessionStart -> mount Codex carrier context and branch identity
- before material operation -> check write scope / protected paths
- after material operation -> record touched paths
- before exit -> sync rolling context and receipt candidate

### 7. Slash commands / custom commands

Codex slash commands should be turned into ION commands where possible:

- `/ion-mount`
- `/ion-identity`
- `/ion-packet`
- `/ion-branch`
- `/ion-sync`
- `/ion-proof`
- `/ion-git-plan`
- `/ion-receipt`
- `/ion-settlement`
- `/ion-handoff`

These should be deterministic wrappers or templates where possible, not only freeform prompts.

### 8. MCP integration

Codex can use MCP. ION should decide which MCP servers/tools are exposed to which Codex specialists. Codex MCP must obey the same authority ceilings as ChatGPT MCP.

### 9. Codex app / app server / remote-control

Codex app/server capabilities are central to the future ION Codex Cockpit. ION should explore whether the app-server can expose threads, tool calls, approvals, summaries, and worktrees in a way the ION cockpit can consume.

## Capability-to-ION state mapping

| Codex native concept | ION carrier-domain mapping |
| --- | --- |
| Session/thread | `CODEX_SESSION.json` + branch capsule |
| Resume | reopen existing carrier session |
| Memory | working recall, not accepted state |
| AGENTS.md | stable carrier instruction source |
| Subagent | child branch capsule / domain-local carrier |
| Hook | deterministic ION enforcement point |
| Slash command | operator-facing ION command |
| MCP server | bounded tool authority surface |
| App/server | cockpit data source |
| Worktree/Git | Git orchestration lane with receipts |
| Approval | ION authority boundary / human gate |

## Immediate research needed locally

The uploaded repo snapshot cannot reveal hidden `~/.codex` memories/sessions or installed Codex app-server capabilities. A local Codex audit must inventory these without printing secrets:

- `~/.codex/config.toml`
- `~/.codex/AGENTS.md` or `AGENTS.override.md`
- `~/.codex/memories/` file names and policy only
- session/transcript store presence
- custom commands/plugins/subagents/skills if present
- local Codex CLI version and help output
- app-server/remote-control support
