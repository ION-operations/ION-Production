# ACTION_SURFACE_CONTEXT_PACKAGE_001

## Goal

Materialize the ION Actions + MCP Connector Context Package v0.1 into the local repo as candidate documentation and machine-readable cartography.

## Required writes

- ION/05_context/current/action_surface_cartography/ION_ACTIONS_CONNECTOR_CONTEXT_PACKAGE_V0_1.md
- ION/05_context/current/action_surface_cartography/ACTION_SURFACE_TEST_LOG_V0_1.json
- ION/05_context/current/action_surface_cartography/ACTION_SURFACE_LIMITS_AND_VARIABLES_V0_1.json
- ION/05_context/current/action_surface_cartography/ACTION_SURFACE_ROADMAP_V0_1.md
- ION/05_context/current/context_settlement/inbox/SETTLE_ACTION_SURFACE_CONTEXT_PACKAGE_001_20260511.json

## Boundaries

No production authority.
No live execution authority.
No secrets.
No git push.
No broad shell.
No shared Capsule/Mini/HOT_CONTEXT/STATUS mutation.
No C-number assignment.

## Return sections

CONTEXT PROOF
TEMPLATE ACTION PROOF
VALIDATION
RESULT
WORKLOAD DIFF
BLOCKERS
RECOMMENDED NEXT PACKET
