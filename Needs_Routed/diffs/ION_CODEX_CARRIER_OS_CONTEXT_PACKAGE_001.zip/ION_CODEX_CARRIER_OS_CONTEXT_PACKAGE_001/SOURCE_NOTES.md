# Source Notes

## Uploaded / ION evidence

- `ION_CODEX FULL2.zip` was extracted read-only in sandbox.
- `ION_LEAD_DEV_INTAKE_20260512.md` and related branch-return docs were treated as candidate evidence, not accepted state.
- `ION_Continuity_Substrate_Explainer_v7.md` and `context_engineering_white_paper_v_0_1.md` provide governing doctrine around candidate/accepted state, multi-carrier routing, branch settlement, and context engineering.
- Recent live MCP smoke results from this conversation show MCP health, bounded patch preview/apply, and port routing are now operational, but those live facts are not embedded as accepted state in this package.

## External Codex references checked

Official OpenAI Codex documentation was used for current capability references:
- Codex CLI features: https://developers.openai.com/codex/cli/features
- Codex memories: https://developers.openai.com/codex/memories
- AGENTS.md custom instructions: https://developers.openai.com/codex/guides/agents-md
- Codex subagents: https://developers.openai.com/codex/subagents
- Codex hooks: https://developers.openai.com/codex/hooks
- Codex CLI slash commands: https://developers.openai.com/codex/cli/slash-commands
- Codex app: https://developers.openai.com/codex/app
- Codex changelog: https://developers.openai.com/codex/changelog

## Non-claims

This package does not include local `~/.codex` memory/session contents because those are user-local and may contain sensitive material. The next local Codex audit should inventory them without printing secrets.
