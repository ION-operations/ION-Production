# ION Codex Carrier Domain Model

Status: candidate domain model.

## Summary

Codex should be a first-class ION carrier, not a generic worker. The Codex Carrier Domain should bind native Codex capabilities to ION continuity, branch capsules, proof, receipts, settlement, and UI visibility.

## Core law

```text
Codex memory/session = working continuity.
ION branch capsule = durable governed continuity.
ION settlement = accepted inheritance.
```

## Domain objects

### Codex Carrier Session

A record of one Codex session/thread under an ION agent identity.

Recommended path:

```text
ION/05_context/current/codex_carrier/sessions/<session_id>.json
```

Recommended schema:

```json
{
  "schema_id": "ion.codex_carrier_session.v0_1",
  "session_id": "...",
  "agent_tag": "codex_local_ion_mason",
  "codex_thread_title": "...",
  "model_lane": "gpt-5.5-xhigh",
  "repo_root": "/home/sev/ION - Production/ION_CODEX FULL",
  "branch_id": "branch_codex_local_ion_mason",
  "ion_branch_capsule": "ION/05_context/current/agent_context_branches/codex_local_ion_mason/",
  "current_packet": "...",
  "memory_policy": {
    "use_codex_memories": true,
    "generate_codex_memories": true,
    "secrets_redaction_required": true
  },
  "write_scope": [],
  "settlement_required": true,
  "accepted_state_authority": false
}
```

### Codex Carrier Agent

A named Codex domain specialist with a profile, write scope, memory policy, and branch capsule.

Initial proposed agents:

- `codex_local_ion_mason`
- `codex_runtime_cartographer`
- `codex_git_orchestration_steward`
- `codex_branch_capsule_architect`
- `codex_ui_joc_opus_canonist`
- `codex_daimon_bridge_specialist`
- `codex_proof_nemesis`

These must be reconciled with existing ION registries before landing.

### Codex Branch Capsule

Each significant Codex agent/session should have a durable branch capsule:

```text
ION/05_context/current/agent_context_branches/<agent_tag>/
  CAPSULE.md
  MINI.md
  STATUS.json
  ROLLING_CONTEXT.md
  CODEX_SESSION.json
  RECEIPTS/
  TASK_RETURNS/
  PATCHES/
  BLOCKERS.md
```

### Codex Memory Bridge

A policy and sync mechanism that records what Codex memory may influence and what ION state governs.

Rules:
- Do not print or export raw memory contents without review.
- Memory summaries may be referenced as orientation.
- Durable facts must be written to branch capsule/receipt.
- Any state-bearing memory claim requires file/receipt support.

### Codex Hook Layer

Hooks should enforce:
- mount proof,
- identity card,
- current packet,
- authority boundary,
- write scope,
- protected path checks,
- rolling context sync,
- receipt candidate generation.

### Codex Cockpit Data Model

The cockpit should consume:
- session registry,
- branch capsule registry,
- Git orchestration manifests,
- connector queue/receipt state,
- Codex run packets and logs,
- settlement inbox,
- drift/consistency checks,
- active service health,
- UI/JOC proof gates.

## State transitions

### Start/resume Codex agent

```text
operator intent
→ select Codex agent/domain
→ resolve or create Codex session
→ mount branch capsule
→ render identity card
→ validate write scope
→ begin packet
```

### Material work

```text
packet
→ context package
→ Codex session
→ local edits/tests
→ diff/proof
→ branch capsule sync
→ receipt candidate
→ settlement request
```

### Fan-out/fan-in

```text
relay Codex session
→ spawn Codex subagents or parallel sessions
→ each writes branch return
→ parent performs settlement analysis
→ human/Steward accepts/defer/rejects
```

## Non-goals

- Do not replace ION settlement with Codex memory.
- Do not allow Codex sessions to accept state directly.
- Do not use one global Codex session for all domains.
- Do not expose secrets or hidden memories in the cockpit.
- Do not show private model chain-of-thought; show visible actions, context, tool calls, diffs, logs, and receipts.
